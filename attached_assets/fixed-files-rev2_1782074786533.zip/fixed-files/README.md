# Fixed files (Rev. 2) — drop-in replacements

Each file here is the complete, corrected version. Copy each one over its counterpart at the matching path in the repo. See `Litigant-AI_Fix-Handoff_Rev2.md` for the full reasoning behind every change.

| File in this folder | Replace this file in the repo |
|---|---|
| `firestore.rules` | `/firestore.rules` |
| `squareEventHandler.ts` | `/artifacts/api-server/src/lib/squareEventHandler.ts` |
| `brain.ts` | `/artifacts/api-server/src/routes/brain.ts` |
| `lib/providers/gemini.ts` | `/artifacts/api-server/src/lib/providers/gemini.ts` |
| `lib/providers/grok.ts` | `/artifacts/api-server/src/lib/providers/grok.ts` |
| `lib/providers/custom.ts` | `/artifacts/api-server/src/lib/providers/custom.ts` |
| `pages/app/Session.tsx` | `/artifacts/gh-brain/src/pages/app/Session.tsx` |
| `pages/app/Billing.tsx` | `/artifacts/gh-brain/src/pages/app/Billing.tsx` |
| `services/firestoreService.ts` | `/artifacts/gh-brain/src/services/firestoreService.ts` |

## Before deploying

1. **Set `SQUARE_WEBHOOK_SIGNATURE_KEY`** in your production environment FIRST. If you deploy `squareEventHandler.ts` before this is set, Square purchases will stop granting credits until the key is in place. See Fix #3 in the handoff doc.
2. Deploy `firestore.rules` separately via `firebase deploy --only firestore:rules`, and test in a sandbox project before production if you can.
3. This bundle supersedes the Rev. 1 `firestore.rules` — if you already deployed Rev. 1, deploy this corrected version on top of it. Rev. 1's rule would have broken the auto-refill redirect flow in `Billing.tsx`; this version fixes that while keeping the same security protections.

See the handoff doc's Section C for the full post-deploy checklist.
