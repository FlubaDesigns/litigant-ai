# Fixed files — drop-in replacements

Each file here is the complete, corrected version. Copy each one over its counterpart at the matching path in the repo. See `Litigant-AI_Fix-Handoff_Rev1.md` for the reasoning behind each change.

| File in this folder | Replace this file in the repo |
|---|---|
| `firestore.rules` | `/firestore.rules` |
| `squareEventHandler.ts` | `/artifacts/api-server/src/lib/squareEventHandler.ts` |
| `brain.ts` | `/artifacts/api-server/src/routes/brain.ts` |
| `lib/providers/gemini.ts` | `/artifacts/api-server/src/lib/providers/gemini.ts` |
| `lib/providers/grok.ts` | `/artifacts/api-server/src/lib/providers/grok.ts` |
| `lib/providers/custom.ts` | `/artifacts/api-server/src/lib/providers/custom.ts` |

**Before deploying:** set `SQUARE_WEBHOOK_SIGNATURE_KEY` in your production environment first — see Fix #2 in the handoff doc. If you deploy `squareEventHandler.ts` before setting that variable, Square purchases will stop granting credits until it's set.
