# Fixed file — Pass 2 addendum

| File in this folder | Replace this file in the repo |
|---|---|
| `lib/emailService.ts` | `/artifacts/api-server/src/lib/emailService.ts` |

This is the only file changed in this round. Adds an `escapeHtml()` helper and applies it to `displayName` before it's interpolated into the verification and password-reset email templates. See `Litigant-AI_Audit-Pass2.md` (Finding #6) for the full diff, reasoning, and verification.

No other files in this pass were modified — Finding #5 (admin pricing table) is still flagged, not fixed, pending your fill-rate input for the shared estimate correction it needs alongside Pass 1's Finding #2.
