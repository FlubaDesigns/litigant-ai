# Credit Packs Admin Feature — File Manifest

| File in this folder | Replace/add this file in the repo |
|---|---|
| `lib/creditPacksConfig.ts` | **New file** → `/artifacts/api-server/src/lib/creditPacksConfig.ts` |
| `routes/admin.ts` | `/artifacts/api-server/src/routes/admin.ts` |
| `routes/billing.ts` | `/artifacts/api-server/src/routes/billing.ts` |
| `routes/brain.ts` | `/artifacts/api-server/src/routes/brain.ts` |
| `frontend/services/adminService.ts` | `/artifacts/gh-brain/src/services/adminService.ts` |
| `frontend/pages/admin/Admin.tsx` | `/artifacts/gh-brain/src/pages/admin/Admin.tsx` |

No new npm dependencies. No `firestore.rules` change needed — `config/creditPacks` already falls under the existing `config/*` catch-all that denies all client-SDK access (Admin SDK bypasses it, same as every other admin-config document).

See `CreditPacks-Feature-Handoff.md` for the full design rationale, what's verified vs. not, and the testing checklist to run before this goes live.
