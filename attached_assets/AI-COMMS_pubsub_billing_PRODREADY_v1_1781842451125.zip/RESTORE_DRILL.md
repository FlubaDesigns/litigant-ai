# Restore Drill (Step 5)

This project already documents backups and rollback in `BACKUP_AND_ROLLBACK.md`.
This document adds the missing piece: **a repeatable restore drill** you can run on **staging** to prove recovery works.

## Scope

### Critical data (must restore correctly)
- Firestore: `users`, `orgs`, `projects`, `project_intake_packets`, `approvals`, `canon_*`, `audit_*`, `billing_*`, `email_*`, `ops_*`
- Auth: admin claims / roles (or the process to re-apply them)
- Functions deploy state (the exact git tag / zip version)

### Derived data (can be rebuilt after restore)
- rollups / aggregates: `ops_signal_rollups`, metrics rollups, analytics counters

## RTO / RPO (write your targets)
- **RTO (Recovery Time Objective):** ____ minutes/hours (how long you can be down)
- **RPO (Recovery Point Objective):** ____ minutes/hours (how much data loss is acceptable)

> Recommended starting targets for a first revenue beta:
> - RTO: 2–6 hours
> - RPO: 24 hours (daily exports)

## Preconditions
1. You have a **staging Firebase project** separate from production.
2. Firestore scheduled exports are enabled (Console: Firestore → Import/Export → Schedule export).
3. You have a GCS bucket for staging exports, e.g. `gs://YOUR-STAGING-BUCKET/aicomms-firestore-exports/`

## One-time setup (recommended)
- Install **gcloud** (Cloud SDK) on your machine where you run restore drills.
- Authenticate:
  - `gcloud auth login`
  - `gcloud config set project YOUR_STAGING_PROJECT_ID`

## Restore Drill (Staging Only)

### Step A — Take a known-good export
Option 1: Console scheduled export (preferred)
- Confirm the latest scheduled export completed successfully.

Option 2: Manual export via gcloud
- Run:
  - `bash scripts/firestore-export.sh YOUR_STAGING_PROJECT_ID gs://YOUR-STAGING-BUCKET/aicomms-firestore-exports`

This prints the export folder path (you will use it in import).

### Step B — Simulate a failure (choose ONE)
**B1. Data deletion simulation**
- In staging Firestore, delete a small but meaningful set of docs:
  - e.g. 5 docs in `project_intake_packets` and 1 doc in `orgs`
- Record exactly what you deleted.

**B2. Rules outage simulation**
- Deploy a known-bad rules file to staging (only in staging).
- Confirm clients see `permission-denied`.

### Step C — Restore (Import)
- Run:
  - `bash scripts/firestore-import.sh YOUR_STAGING_PROJECT_ID <EXPORT_FOLDER_PATH>`

Example export folder path:
- `gs://YOUR-STAGING-BUCKET/aicomms-firestore-exports/2026-03-02T18:00:00_12345`

### Step D — Post-restore reconciliation (best-effort)
After import, you may need to rebuild derived rollups and re-run safety nets.

Run:
- `node scripts/post-restore-reconcile.mjs --project YOUR_STAGING_PROJECT_ID`

This script is **safe by default** and only:
- validates critical collections exist
- logs counts / sanity checks
- prints instructions to manually trigger scheduled nets (Stripe reconcile, grace sweeps)

### Step E — Verification checklist
Use `RESTORE_CHECKLIST.md` and record results.

## Output you should save after each drill
- Export folder path used
- What failure you simulated
- Import start/end timestamps
- Results of `RESTORE_CHECKLIST.md`
- Any fixes required / follow-ups
