# RESPONSE.md — Packet: AI-COMMS Drift Scan + Explorer Credit (v1)
Date: 2026-02-26

## Summary
- Added a new real-time funnel page: /drift-scan (instant interactive risk score).
- Added Explorer plan ("Governance Credit") to Pricing and Checkout flows.
- Extended Firebase Functions Stripe checkout + webhook to support explorer pricing and crediting users.

## Root Cause / Evidence
- Existing site had Risk Scan only; needed a real-time interactive drift scan entry.
- Pricing/Checkout supported tiered checkout; added explorer as a first-class tier.
- Stripe webhook previously only fulfilled leads; explorer requires credit on users.

## Files Changed
Web
- web/src/routes/DriftScan.tsx (new)
- web/src/routes/App.tsx (route added)
- web/src/routes/Pricing.tsx (Explorer plan card)
- web/src/routes/Checkout.tsx (supports explorer tier)

Functions
- functions/src/tierPolicy.ts (added explorer tier)
- functions/src/createCheckoutSession.ts (explorer price secret + label)
- functions/src/stripeWebhook.ts (credit users on explorer checkout)

Docs
- BUILDER/README_OWNER.md
- CLAUDE/README_CLAUDE.md

## Risk Assessment
- Low/Moderate: Adds new tier and webhook behavior. Existing tiers unchanged.
- Stripe webhook now writes to users/{userId} only when explorer and metadata.userId exists.

## Rollback
- Revert to previous zip or remove explorer tier additions:
  - Remove DriftScan route/page and explorer tier references.
  - Restore tierPolicy/createCheckoutSession/stripeWebhook to prior versions.

## Test Results
- Not executed in this environment (build-only). Manual verification steps in BUILDER/README_OWNER.md.

END

---

## Packet v3 — Auth-gated Explorer + Purchase Emails (Resend Outbox)

### What changed
- Explorer (Governance Credit) checkout now requires sign-in so Stripe metadata.userId is always present.
- Stripe checkout metadata now includes: userId + email (when provided).
- Stripe webhook now enqueues a purchase/activation email for ALL tiers (explorer/audit/pro/enterprise) into /email_outbox.
- Email outbox processor fixed + hardened (reads queued docs, sends via Resend, updates status, logs ops errors).
- Login supports returnTo redirect; checkout sends unauthenticated Explorer users to /login?returnTo=...

### Files changed
- web/src/routes/Checkout.tsx
- web/src/routes/Login.tsx
- functions/src/createCheckoutSession.ts
- functions/src/stripeWebhook.ts
- functions/src/emailResend.ts
- functions/src/emailOutboxProcessor.ts
- functions/src/emailQueue.ts (new)
- functions/src/emailTemplates.ts (new)
- BUILDER/README_OWNER.md
- CLAUDE/README_CLAUDE.md

### Secrets required
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- PUBLIC_SITE_BASE_URL
- RESEND_API_KEY
- AICOMMS_FROM_EMAIL
- AICOMMS_ADMIN_EMAIL
