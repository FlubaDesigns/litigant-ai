# AI-COMMS Retail vs AI Socket Brain

This package is the AI-COMMS retail/product layer. It does **not** execute builds locally.

Execution is delegated to the AI Socket Brain service (Cloud Run / separate runtime) via `functions/src/socketEndpoints.ts`.

Required env for functions:
- `SOCKET_BASE_URL`
Optional:
- `SOCKET_API_KEY` (simple header auth placeholder)

---

## Canon Kernel vs AI Cortex (how governance stays universal but adapts per client)

AI‑COMMS is designed to plug into **AI‑Guardrails** as an external “court” that returns a deterministic verdict.
To keep the product *sellable to any AI stack* while still supporting per‑client/per‑project needs, governance is layered:

### 1) Canon Kernel (Constitution)
- Universal law / invariants (rarely changed)
- Defines verdict semantics (PASS / REVISE / REFUSE / ESCALATE)
- Defines non‑negotiables (e.g., governance can’t self‑edit)
- **Never** contains client repo paths, tool allowlists, or project settings

### 2) AI Cortex (Project Profile)
- A *project‑specific* mapping layer: “how Canon applies here”
- Contains things like:
  - what directories count as GOVERNANCE vs SANDBOX vs SECRETS vs DEPLOY
  - which action classes require escalation/owner approval
  - project thresholds (if you choose to tune them per project)
- **Mutable only by Owner approval**, and **version‑pinned** per project (hash + version)

### 3) Brain (Execution)
- The socket “brain” proposes actions and enforces the verdict
- Brain does not invent policy; it obeys **Canon Kernel + Cortex** evaluation output

### Where Cortex should live in AI‑COMMS
Recommended: store Cortex profiles in Firestore so AI‑COMMS can bind a project to a specific Cortex version:

- `cortex_profiles/{projectId}/versions/{cortexHash}` (profile JSON + metadata)
- `projects/{projectId}` includes `canonHash` and `cortexHash` pins

This keeps Kernel universal and Cortex client/project‑scoped.
