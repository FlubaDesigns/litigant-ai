# AI-COMMS ↔ Brain Pub/Sub Bridge

This repo contains AI-COMMS (control plane). Brain runs as a separate runtime/project.

## Flow
1. Client calls `submitBrainJob` (Firebase callable).
2. AI-COMMS writes `brain_jobs/{jobId}` (portal-visible record).
3. AI-COMMS publishes message to Brain Pub/Sub topic.
4. Brain processes job, then POSTs result to AI-COMMS `ingestBrainResult` with HMAC signature.
5. AI-COMMS writes `brain_results/{jobId}` and updates job status.

## Required configuration

### Functions params
Set these (staging/prod):
- `BRAIN_PUBSUB_PROJECT`
- `BRAIN_PUBSUB_TOPIC`

### Secrets
Set:
- `BRAIN_CALLBACK_SECRET`

## Brain expected callback
POST JSON to:
`https://<region>-<aicomms-project>.cloudfunctions.net/ingestBrainResult`

Headers:
- `x-aicomms-signature: <hex hmac sha256 of raw body>`

Body:
```json
{
  "jobId":"...",
  "status":"done|failed|blocked",
  "result":{ "any":"json" },
  "usage":{ "minutesUsed": 3, "durationMs": 1200 },
  "error": null
}
```
