# AI Cortex Overview

Generated: 2026-02-28T08:18:20.145683Z

## Purpose
**AI Cortex** is the mission/project profile layer that sits *outside* the Canon Kernel.

- **Canon Kernel** = constitutional invariants (universal, rarely changed)
- **AI Cortex** = project mapping + constraints (changeable only by Owner approval; version‑pinned per project)

The goal is to keep AI‑Guardrails marketable as a universal governance kernel, while still supporting client‑specific needs without rewriting the kernel.

## What belongs in Cortex
Cortex should contain **declarative** project data such as:
- Path mappings (GOVERNANCE / SANDBOX / SECRETS / DEPLOY)
- Action class permissions and escalation requirements
- Project thresholds (if tuning is allowed)
- Role mapping for approvals (Owner/Operator)
- Any client‑specific integration constraints

## What does NOT belong in Cortex
Cortex should NOT contain:
- Kernel verdict semantics
- Immutable invariants (“no governance self‑edit”, etc.)
- Any reasoning/agent logic (no “mini brain”)
- Anything that weakens Kernel invariants (unless Sovereign Override is explicitly enabled at the product layer)

## Recommended storage
Store Cortex profiles in Firestore so they can be versioned, pinned, and audited:

- `cortex_profiles/{projectId}/versions/{cortexHash}`
  - `profile_json`
  - `created_at`
  - `created_by`
  - `notes`
- `projects/{projectId}`
  - `canon_hash`
  - `cortex_hash`

## Relationship to existing Scoped Canon
Legacy `scoped_canon` seeding can be repurposed to seed Cortex profiles.
Prefer new naming:
- `scoped_canon` → `cortex_profiles`
- `seedScopedCanon()` → `seedCortexProfile()`

