import { admin, db } from "./firebaseAdmin";
import * as crypto from "crypto";

function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input, "utf8").digest("hex");
}

export function getScopeFromReq(req: any): string {
  const bodyScope = String(req.body?.scope_name || "").trim();
  if (bodyScope) return bodyScope;

  const headerScope = String(req.headers?.["x-aicomms-scope"] || "").trim();
  if (headerScope) return headerScope;

  const origin = String(req.headers?.origin || req.headers?.referer || "").toLowerCase();
  if (origin.includes("qrgear")) return "QRGEAR";
  if (origin.includes("kingdom")) return "KINGDOMCONNECTS";
  if (origin.includes("pollsit")) return "POLLSIT";

  return "AICOMMS";
}

export async function requireScopeApiKey(req: any) {
      const scope = getScopeFromReq(req);
  const rawKey = String(req.headers?.["x-aicomms-api-key"] || "").trim();

  if (!rawKey) {
    return { ok: false as const, status: 401, message: "Missing header: x-aicomms-api-key", scope };
  }

  const scopeRef = db.collection("scopes").doc(scope);
  const snap = await scopeRef.get();
  if (!snap.exists) {
    return { ok: false as const, status: 403, message: `Unknown scope: ${scope}`, scope };
  }

  const data = snap.data() as any;
  const storedHash = String(data?.api_key_hash || "").trim();
  if (!storedHash) {
    return { ok: false as const, status: 403, message: `Scope has no api_key_hash set: ${scope}`, scope };
  }

  const incomingHash = sha256Hex(rawKey);
  if (incomingHash !== storedHash) {
    return { ok: false as const, status: 403, message: "Invalid API key for scope", scope };
  }

  return { ok: true as const, scope, scopeDoc: data };
}