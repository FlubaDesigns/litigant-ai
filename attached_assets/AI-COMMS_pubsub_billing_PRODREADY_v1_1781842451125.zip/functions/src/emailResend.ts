import { defineSecret } from "firebase-functions/params";
import { Resend } from "resend";

const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

export async function sendAdminEmail(args: { subject: string; html: string }) {
  const resend = new Resend(RESEND_API_KEY.value());
  const from = AICOMMS_FROM_EMAIL.value();
  const to = AICOMMS_ADMIN_EMAIL.value();

  if (!from || !to) throw new Error("missing_from_or_admin_email");

  return resend.emails.send({
    from,
    to,
    subject: args.subject,
    html: args.html,
  });
}


export async function sendEmail(args: { to: string; subject: string; html: string }) {
  const resend = new Resend(RESEND_API_KEY.value());
  const from = AICOMMS_FROM_EMAIL.value();
  if (!from) throw new Error("missing_from_email");
  if (!args.to) throw new Error("missing_to_email");

  return resend.emails.send({
    from,
    to: args.to,
    subject: args.subject,
    html: args.html,
  });
}

export async function sendCustomerEmail(args: { to: string; subject: string; html: string }) {
  return sendEmail(args);
}
