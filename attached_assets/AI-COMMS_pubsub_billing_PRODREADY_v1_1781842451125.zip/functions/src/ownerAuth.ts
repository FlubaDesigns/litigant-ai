import { defineSecret } from "firebase-functions/params";
import { admin } from "./firebaseAdmin";

// Owner UID must be set as a Firebase Secret (Functions > Secrets) named OWNER_UID
export const OWNER_UID = defineSecret("OWNER_UID");
// Store sha256 hex of your owner PIN (e.g., sha256("123456")) as secret OWNER_PIN_HASH
export const OWNER_PIN_HASH = defineSecret("OWNER_PIN_HASH");


export async function requireOwner(req: any): Promise<{ ok: boolean; status: number; message?: string; uid?: string }> {
  try {
    const authHeader = String(req.headers?.authorization || "");
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return { ok: false, status: 401, message: "missing_bearer_token" };

    const decoded = await admin.auth().verifyIdToken(token);
    const ownerUid = OWNER_UID.value();
    if (!ownerUid) return { ok: false, status: 500, message: "owner_uid_secret_missing" };

    if (decoded.uid !== ownerUid) return { ok: false, status: 403, message: "owner_only" };
    return { ok: true, status: 200, uid: decoded.uid };
  } catch (e: any) {
    return { ok: false, status: 401, message: e?.message || "invalid_token" };
  }
}


function sha256Hex(input: string): string {
  return require("crypto").createHash("sha256").update(input, "utf8").digest("hex");
}

export function requireOwnerPin(body: any): { ok: boolean; status: number; message?: string } {
  const pin = String(body?.owner_pin || body?.pin || "").trim();
  const expected = String(OWNER_PIN_HASH.value() || "").trim();
  if (!expected) return { ok: false, status: 500, message: "owner_pin_hash_secret_missing" };
  if (!pin) return { ok: false, status: 401, message: "missing_owner_pin" };
  const got = sha256Hex(pin);
  // constant-time compare
  const a = Buffer.from(got, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length) return { ok: false, status: 403, message: "invalid_owner_pin" };
  const equal = require("crypto").timingSafeEqual(a, b);
  if (!equal) return { ok: false, status: 403, message: "invalid_owner_pin" };
  return { ok: true, status: 200 };
}
