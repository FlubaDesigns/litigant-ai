import * as functions from "firebase-functions";
import { admin, db } from "./firebaseAdmin";
import { logProtectionEvent } from "./logProtectionEvent";

/**
 * sweepGraceDowngrades
 * Daily job to downgrade users whose grace period expired.
 */
export const sweepGraceDowngrades = functions.pubsub
  .schedule("every day 03:15")
  .timeZone("UTC")
  .onRun(async () => {
    const now = admin.firestore.Timestamp.now();
    const qs = await db
      .collection("users")
      .where("billing_status", "==", "grace")
      .where("grace_expires_at", "<", now)
      .limit(500)
      .get();

    for (const doc of qs.docs) {
      const uid = doc.id;
      await db.collection("users").doc(uid).set(
        {
          billing_status: "canceled",
          tier: "audit",
          plan: "free",
          grace_expires_at: admin.firestore.FieldValue.delete(),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      await logProtectionEvent({
        userId: uid,
        severity: "critical",
        type: "billing",
        message: "Grace period expired. Coverage downgraded.",
        metadata: { source: "sweepGraceDowngrades" },
      });
    }

    console.log(`sweepGraceDowngrades: processed ${qs.size}`);
    return null;
  });
