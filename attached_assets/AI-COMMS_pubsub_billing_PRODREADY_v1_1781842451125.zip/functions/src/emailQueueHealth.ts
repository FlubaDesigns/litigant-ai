import { onSchedule } from "firebase-functions/v2/scheduler";
import { db } from "./firebaseAdmin";
import { sendAlert } from "./alerting";
import { logEvent } from "./lib/logEvent";
import { recordOpsSignal } from "./lib/opsSignals";

export const emailQueueHealth = onSchedule(
  { schedule: "every 15 minutes", region: "us-central1" },
  async () => {
    const queued = await db.collection("email_outbox").where("status", "==", "queued").count().get();
    const q = queued.data().count || 0;

    if (q > 200) {
      await sendAlert("warn", "Email queue backlog", `email_outbox queued count is high: ${q}`, { queued: q });
      await recordOpsSignal("email_queue_backlog", false, q, { queued: q });
    } else {
      await recordOpsSignal("email_queue_heartbeat", true, 1, { queued: q });
      await logEvent("email_queue_heartbeat", "INFO", "Email queue heartbeat.", { queued: q });
    }
  }
);
