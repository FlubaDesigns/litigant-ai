import { onCall, HttpsError } from "firebase-functions/v2/https";
import { admin, db } from "./firebaseAdmin";
import { defineSecret } from "firebase-functions/params";
import { sendAdminEmail } from "./emailResend";
import { logOpsError } from "./opsLog";
import { logEvent } from "./lib/logEvent";
import { bumpDailyIpCounter } from "./lib/rateLimit";
import { logProtectionEvent } from "./logProtectionEvent";
import { scoreRiskScan } from "./lib/riskScanScoring";

// Secrets (used by Resend sender)
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

function normalizeEmail(v: any) {
  return String(v || "").trim().toLowerCase();
}

function getClientIp(req: any) {
  const raw = String(req?.rawRequest?.ip || req?.rawRequest?.headers?.["x-forwarded-for"] || "unknown");
  return raw.split(",")[0].trim() || "unknown";
}

function requireString(field: string, v: any, maxLen = 300) {
  const s = String(v ?? "").trim();
  if (!s) throw new HttpsError("invalid-argument", `${field} is required.`);
  if (s.length > maxLen) throw new HttpsError("invalid-argument", `${field} is too long.`);
  return s;
}

function sanitizeGovernanceProfile(raw: any) {
  if (!raw || typeof raw !== "object") return null;
  const tier = String(raw.tier || "").trim();
  const autonomyLevel = Number(raw.autonomyLevel);
  const loggingDepth = String(raw.loggingDepth || "").trim();
  const patchMode = String(raw.patchMode || "").trim();
  const escalationSla = String(raw.escalationSla || "").trim();

  const allowedTier = ["SMB", "MID_MARKET", "REGULATED"].includes(tier);
  const allowedLogging = ["basic", "extended", "immutable"].includes(loggingDepth);
  const allowedPatch = ["proposal_only", "approval_required", "restricted_auto_minor"].includes(patchMode);
  const allowedSla = ["24h", "4h", "1h"].includes(escalationSla);
  const allowedAutonomy = Number.isFinite(autonomyLevel) && autonomyLevel >= 0 && autonomyLevel <= 4;

  if (!allowedTier || !allowedLogging || !allowedPatch || !allowedSla || !allowedAutonomy) return null;

  const reasons = Array.isArray(raw.reasons) ? raw.reasons.map((r: any) => String(r).slice(0, 200)) : [];
  return {
    tier,
    autonomyLevel,
    loggingDepth,
    patchMode,
    escalationSla,
    reasons,
  };
}

export const submitRiskScan = onCall(
  { region: "us-central1", enforceAppCheck: true, secrets: [AICOMMS_ADMIN_EMAIL] },
  async (req) => {
    try {
      const ip = getClientIp(req);

      // Minimal abuse control (IP-based daily cap)
      const { count, limited, limit } = await bumpDailyIpCounter(ip, 120);
      if (limited) {
        await logEvent("risk_scan_rate_limited", "WARN", "RiskScan blocked by rate limit", { ip, count, limit });
        throw new HttpsError("resource-exhausted", "Rate limit exceeded.");
      }

      const email = normalizeEmail(requireString("email", req.data?.email, 254));
      if (!email.includes("@")) throw new HttpsError("invalid-argument", "Valid email required.");

      const name = String(req.data?.name || "").trim();
      const company = String(req.data?.company || "").trim();

      // Require answers presence (deterministic server-side scoring)
      const answersPayload = req.data?.answers ?? req.data?.answersPayload ?? null;
      if (!answersPayload) throw new HttpsError("invalid-argument", "answers is required.");

      const scoring = scoreRiskScan({ answers: answersPayload });

      // Optional: governance profile from AI-COMMS (website layer). This is the formal "tree split" artifact.
      const governanceProfile = sanitizeGovernanceProfile(req.data?.governance_profile || req.data?.governanceProfile);

      // Upsert lead by normalized email
      const existing = await db.collection("leads").where("email_norm", "==", email).limit(1).get();
      const leadId = existing.empty ? db.collection("leads").doc().id : existing.docs[0].id;

      const now = admin.firestore.FieldValue.serverTimestamp();

      await db.collection("leads").doc(leadId).set(
        {
          email,
          email_norm: email,
          name: name || null,
          company: company || null,
          status: "risk_scan_submitted",
          updated_at: now,
          created_at: existing.empty ? now : (existing.docs[0].data() as any)?.created_at || now,
          last_risk_score: scoring.score,
          last_risk_band: scoring.band,

          // Governance profile (latest)
          last_governance_profile: governanceProfile,
          last_governance_tier: governanceProfile?.tier || null,
          last_autonomy_level: governanceProfile?.autonomyLevel ?? null,
          last_logging_depth: governanceProfile?.loggingDepth || null,
          last_patch_mode: governanceProfile?.patchMode || null,
        },
        { merge: true }
      );

      const scanRef = db.collection("risk_scans").doc();
      await scanRef.set({
        created_at: now,
        lead_id: leadId,
        email,
        name: name || null,
        company: company || null,
        score: scoring.score,
        band: scoring.band,
        findings: scoring.findings,
        recommended_next: scoring.recommended_next,
        governance_profile: governanceProfile,
        ip,
      });

      // Mirror into canonical riskScans collection (scalable domain naming)
      await db.collection("riskScans").doc(scanRef.id).set(
        {
          leadId: leadId,
          email,
          name: name || null,
          company: company || null,
          riskScore: scoring.score,
          segment: scoring.band === "high" ? "high" : scoring.band === "medium" ? "medium" : "low",
          createdAt: now,

          governanceProfile,
        },
        { merge: true }
      );

      // Persist a "locked" governance profile shell for downstream (Brain) enforcement.
      // This does NOT grant autonomy by itself; it is an enforceable envelope reference.
      if (governanceProfile) {
        await db
          .collection("governance_profiles")
          .doc(leadId)
          .set(
            {
              kind: "lead",
              leadId,
              email,
              company: company || null,
              profile: governanceProfile,
              version: admin.firestore.FieldValue.increment(1),
              lockedAt: now,
              lockedByUid: req.auth?.uid || null,
              source: String(req.data?.source || "risk_scan"),
              updatedAt: now,
              createdAt: now,
            },
            { merge: true }
          );
      }

      const subject = `AICOMMS Risk Scan: ${scoring.band} (${scoring.score}) — ${email}`;
      const text =
        `New Risk Scan\n\n` +
        `Email: ${email}\n` +
        `Name: ${name || "-"}\n` +
        `Company: ${company || "-"}\n` +
        `Score: ${scoring.score}\n` +
        `Band: ${scoring.band}\n` +
        `Recommended Next:\n- ${scoring.recommended_next.join("\n- ")}\n\n` +
        `LeadId: ${leadId}\n` +
        `ScanId: ${scanRef.id}\n` +
        `Findings:\n- ${scoring.findings.join("\n- ") || "None"}\n`;

      const outboxRef = await db.collection("email_outbox").add({
        created_at: now,
        status: "queued",
        kind: "admin_notify",
        to: AICOMMS_ADMIN_EMAIL.value(),
        subject,
        text,
        lead_id: leadId,
        scan_id: scanRef.id,
      });

      // Best-effort immediate send (outbox processor can retry)
      try {
        await sendAdminEmail(subject, text);
        await outboxRef.set({ status: "sent", sent_at: now }, { merge: true });
      } catch (e: any) {
        await outboxRef.set({ status: "send_failed", error: String(e?.message || e) }, { merge: true });
        await logEvent("risk_scan_email_send_failed", "ERROR", "Admin email send failed", { leadId, scanId: scanRef.id });
      }

      await logEvent("risk_scan_submitted", "INFO", "Risk scan stored", { leadId, scanId: scanRef.id, band: scoring.band });

      return {
        ok: true,
        leadId,
        scanId: scanRef.id,
        score: scoring.score,
        band: scoring.band,
        findings: scoring.findings,
        recommended_next: scoring.recommended_next,
      };
    } catch (err: any) {
      await logOpsError("submitRiskScan", err, { hasAuth: !!req.auth?.uid });
      if (err instanceof HttpsError) throw err;
      throw new HttpsError("internal", "Risk scan failed.");
    }
  }
);
