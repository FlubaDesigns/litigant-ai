import { onDocumentWritten } from "firebase-functions/v2/firestore";
import { admin, db } from "./firebaseAdmin";
import { defineSecret } from "firebase-functions/params";
import { queueEmail } from "./emailQueue";
import { buildDeliverableReadyEmail } from "./emailTemplates";
import { logEvent } from "./lib/logEvent";

const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

/**
 * When deliverables/{projectId} gains a deliverablesUrl, email the lead/user.
 * This is idempotent via deliverables.emailSentAt.
 */
export const onDeliverableReady = onDocumentWritten(
  { region: "us-central1", document: "deliverables/{projectId}", secrets: [AICOMMS_ADMIN_EMAIL] },
  async (event) => {
    const after = event.data?.after?.data() as any;
    const before = event.data?.before?.data() as any;

    if (!after) return;
    const hadUrl = !!before?.deliverablesUrl;
    const hasUrl = !!after?.deliverablesUrl;
    if (hadUrl || !hasUrl) return;

    if (after.emailSentAt) return;

    const projectId = event.params.projectId as string;
    const now = admin.firestore.FieldValue.serverTimestamp();

    // Determine recipient: prefer user email from users if orgId exists; else lead email on deliverable
    let toEmail = String(after.email || "").trim();
    if (!toEmail && after.orgId) {
      // find an owner user for the org
      const owner = await db.collection("users").where("orgId", "==", after.orgId).where("role", "==", "owner").limit(1).get();
      if (!owner.empty) toEmail = String(owner.docs[0].data().email || "").trim();
    }
    if (!toEmail) {
      // fallback to admin
      toEmail = String(AICOMMS_ADMIN_EMAIL.value() || "").trim();
    }
    if (!toEmail) return;

    const { subject, html, text } = buildDeliverableReadyEmail({
      projectId,
      deliverablesUrl: after.deliverablesUrl,
      verdict: after.verdict || after.status || "ready",
    });

    await queueEmail({
      to: toEmail,
      subject,
      html,
      text,
    });

    await db.collection("deliverables").doc(projectId).set({ emailSentAt: now }, { merge: true });
    await logEvent("deliverable_ready_email_enqueued", "INFO", "Deliverable-ready email enqueued", { projectId, to: toEmail });
  }
);
