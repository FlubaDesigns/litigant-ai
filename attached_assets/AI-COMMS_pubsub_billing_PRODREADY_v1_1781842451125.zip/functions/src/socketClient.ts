/**
 * socketClient.ts
 *
 * AI-COMMS Website/Functions layer -> AI Socket (Brain) client.
 *
 * This layer does NOT execute builds. It requests execution from Socket.
 *
 * Required env:
 *   SOCKET_BASE_URL=https://<socket-host>
 * Auth (one of):
 *   SOCKET_API_TOKEN=<bearer token>      (preferred)
 *   SOCKET_API_KEY=<api key>            (fallback)
 *
 * Optional (only if Socket requires signed jobs):
 *   SOCKET_JOB_SIGNING_SECRET=<hmac secret>
 */

import crypto from "crypto";
import { logger } from "firebase-functions";

function baseUrl(): string {
  const url = process.env.SOCKET_BASE_URL;
  if (!url) throw new Error("Missing env SOCKET_BASE_URL");
  return url.replace(/\/+$/, "");
}

function headers(extra: Record<string, string> = {}): Record<string, string> {
  const h: Record<string, string> = { "content-type": "application/json", ...extra };
  // Prefer bearer token (matches the locked-down Socket builds)
  if (process.env.SOCKET_API_TOKEN) h["authorization"] = `Bearer ${process.env.SOCKET_API_TOKEN}`;
  // Fallback API key header
  else if (process.env.SOCKET_API_KEY) h["x-api-key"] = process.env.SOCKET_API_KEY;
  return h;
}

function maybeSignedJobHeaders(rawBody: string): Record<string, string> {
  const secret = process.env.SOCKET_JOB_SIGNING_SECRET;
  if (!secret) return {};
  const ts = Math.floor(Date.now() / 1000);
  const sig = crypto
    .createHmac("sha256", secret)
    .update(`${ts}.`)
    .update(rawBody, "utf8")
    .digest("hex");
  return {
    "x-ai-socket-timestamp": String(ts),
    "x-ai-socket-signature": sig,
  };
}

export async function socketPost<T>(path: string, body: any): Promise<T> {
  const url = `${baseUrl()}${path}`;
  const raw = JSON.stringify(body);
  const res = await fetch(url, {
    method: "POST",
    headers: headers(maybeSignedJobHeaders(raw)),
    body: raw,
  });
  const txt = await res.text();
  if (!res.ok) {
    logger.error("Socket POST failed", { url, status: res.status, body: txt });
    throw new Error(`Socket POST ${path} failed: ${res.status}`);
  }
  return JSON.parse(txt) as T;
}

export async function socketGet<T>(path: string): Promise<T> {
  const url = `${baseUrl()}${path}`;
  const res = await fetch(url, { method: "GET", headers: headers() });
  const txt = await res.text();
  if (!res.ok) {
    logger.error("Socket GET failed", { url, status: res.status, body: txt });
    throw new Error(`Socket GET ${path} failed: ${res.status}`);
  }
  return JSON.parse(txt) as T;
}

// Binary fetch helper (used to pull artifact zips from the Brain)
export async function socketGetRaw(path: string): Promise<{ bytes: Buffer; contentType: string | null }> {
  const url = `${baseUrl()}${path}`;
  const res = await fetch(url, { method: "GET", headers: headers() });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    logger.error("Socket GET(raw) failed", { url, status: res.status, body: txt });
    throw new Error(`Socket GET(raw) ${path} failed: ${res.status}`);
  }
  const ab = await res.arrayBuffer();
  const contentType = res.headers.get("content-type");
  return { bytes: Buffer.from(ab), contentType };
}


// Compatibility expectations (AI-COMMS <-> Socket <-> Guardrails)
const EXPECTED_JOB_SCHEMA_VERSION = "1.0.0";
const EXPECTED_WEBHOOK_SCHEMA_VERSION = "1.0.0";
const EXPECTED_VERDICT_SCHEMA_VERSION = "1.0.0";

/**
 * Ensure Socket stack is compatible before we submit a job.
 * This prevents silent drift between AI-COMMS, AI-SOCKET, and AI-GUARDRAILS.
 */
export async function ensureSocketCompatible() {
  const status = await socketGet("/status");
  const compat = status?.stack_compat || status?.stackCompat || null;

  // Socket returns 503 with {error:"stack_incompatible"} in hard mismatch scenarios.
  if (!status || status?.ok === false) {
    throw new Error(`Socket incompatible or unavailable: ${JSON.stringify(status)}`);
  }

  const socketContract = compat?.socket || status?.socket || null;
  const guardrailsContract = compat?.guardrails || status?.guardrails || null;

  if (!socketContract) throw new Error("Socket contract missing in /status response.");
  if (!guardrailsContract) throw new Error("Guardrails contract missing in /status response.");

  if (socketContract.job_schema_version && socketContract.job_schema_version !== EXPECTED_JOB_SCHEMA_VERSION) {
    throw new Error(`job_schema_version mismatch: expected ${EXPECTED_JOB_SCHEMA_VERSION} got ${socketContract.job_schema_version}`);
  }
  if (socketContract.webhook_schema_version && socketContract.webhook_schema_version !== EXPECTED_WEBHOOK_SCHEMA_VERSION) {
    throw new Error(`webhook_schema_version mismatch: expected ${EXPECTED_WEBHOOK_SCHEMA_VERSION} got ${socketContract.webhook_schema_version}`);
  }
  if (guardrailsContract.verdict_schema_version && guardrailsContract.verdict_schema_version !== EXPECTED_VERDICT_SCHEMA_VERSION) {
    throw new Error(`verdict_schema_version mismatch: expected ${EXPECTED_VERDICT_SCHEMA_VERSION} got ${guardrailsContract.verdict_schema_version}`);
  }

  return true;
}
