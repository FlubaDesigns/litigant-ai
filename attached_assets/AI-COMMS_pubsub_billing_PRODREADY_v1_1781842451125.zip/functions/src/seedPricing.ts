
import { admin, db } from "./firebaseAdmin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logEvent } from "./lib/logEvent";

export const seedPricing = onCall(
  { enforceAppCheck: true, region: "us-central1" },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");
    const adminSnap = await db.collection("admins").doc(uid).get();
    if (!adminSnap.exists) throw new HttpsError("permission-denied", "Admin required.");

    // Seed version
    await db.collection("pricing_version").doc("config").set({
      current_version: 1,
      published_at: admin.firestore.FieldValue.serverTimestamp(),
      published_by_uid: uid,
    }, { merge: true });

    // Modes
    const modes = [
      { id: "DFY", label: "Done For You", description: "We install and operate with you", display_order: 1 },
      { id: "DYS", label: "Do It Yourself", description: "You install using guided tools", display_order: 2 },
    ];
    for (const m of modes) {
      await db.collection("pricing_modes").doc(m.id).set({
        mode_id: m.id,
        label: m.label,
        description: m.description,
        is_active: true,
        display_order: m.display_order,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
        version: 1,
      }, { merge: true });
    }

    // Tiers (example values; admin edits Stripe price ids after)
    const tiers = [
      { id: "DFY_PROTECT", tier_rank: 10, mode_id: "DFY", name: "Protect", recommended_for: "SMB", display_order: 1, eligibility_min_risk_class: "SMB",
        defaults_autonomy_level: 1, defaults_logging_depth: "basic", defaults_patch_mode: "approval_required", defaults_escalation_sla: "24h",
        monthly_fee_cents: 250000, onboarding_fee_cents: 350000, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },
      { id: "DFY_OPS", tier_rank: 20, mode_id: "DFY", name: "Ops", recommended_for: "MID_MARKET", display_order: 2, eligibility_min_risk_class: "MID_MARKET",
        defaults_autonomy_level: 2, defaults_logging_depth: "extended", defaults_patch_mode: "approval_required", defaults_escalation_sla: "24h",
        monthly_fee_cents: 500000, onboarding_fee_cents: 750000, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },
      { id: "DFY_REGULATED", tier_rank: 30, mode_id: "DFY", name: "Regulated", recommended_for: "REGULATED", display_order: 3, eligibility_min_risk_class: "REGULATED",
        defaults_autonomy_level: 1, defaults_logging_depth: "immutable", defaults_patch_mode: "proposal_only", defaults_escalation_sla: "4h",
        monthly_fee_cents: 900000, onboarding_fee_cents: 1500000, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },

      { id: "DYS_STARTER", tier_rank: 10, mode_id: "DYS", name: "Starter", recommended_for: "SMB", display_order: 1, eligibility_min_risk_class: "SMB",
        defaults_autonomy_level: 0, defaults_logging_depth: "basic", defaults_patch_mode: "proposal_only", defaults_escalation_sla: "48h",
        monthly_fee_cents: 9900, onboarding_fee_cents: 0, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },
      { id: "DYS_PRO", tier_rank: 20, mode_id: "DYS", name: "Pro", recommended_for: "MID_MARKET", display_order: 2, eligibility_min_risk_class: "MID_MARKET",
        defaults_autonomy_level: 1, defaults_logging_depth: "extended", defaults_patch_mode: "approval_required", defaults_escalation_sla: "24h",
        monthly_fee_cents: 49900, onboarding_fee_cents: 0, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },
      { id: "DYS_REGULATED", tier_rank: 30, mode_id: "DYS", name: "Regulated", recommended_for: "REGULATED", display_order: 3, eligibility_min_risk_class: "REGULATED",
        defaults_autonomy_level: 0, defaults_logging_depth: "immutable", defaults_patch_mode: "proposal_only", defaults_escalation_sla: "4h",
        monthly_fee_cents: 149900, onboarding_fee_cents: 0, stripe_price_id_monthly: "", stripe_price_id_onboarding: "" },
    ];
    for (const t of tiers) {
      await db.collection("pricing_tiers").doc(t.id).set({
        tier_id: t.id,
        mode_id: t.mode_id,
        name: t.name,
        recommended_for: t.recommended_for,
        is_active: true,
        display_order: t.display_order,
        monthly_fee_cents: t.monthly_fee_cents,
        onboarding_fee_cents: t.onboarding_fee_cents,
        stripe_price_id_monthly: t.stripe_price_id_monthly,
        stripe_price_id_onboarding: t.stripe_price_id_onboarding,
        defaults_autonomy_level: t.defaults_autonomy_level,
        defaults_logging_depth: t.defaults_logging_depth,
        defaults_patch_mode: t.defaults_patch_mode,
        defaults_escalation_sla: t.defaults_escalation_sla,
        eligibility_min_risk_class: t.eligibility_min_risk_class,
        version: 1,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }

    // Add-ons
    const addons = [
      { id: "AUTO_PATCH_MINOR", name: "Auto-Patch (Minor Only)", monthly_fee_cents: 75000, requires_min_tier_id: "DFY_PROTECT", stripe_price_id_monthly: "" },
      { id: "EXTENDED_LOGGING", name: "Extended Logging", monthly_fee_cents: 25000, requires_min_tier_id: "DYS_PRO", stripe_price_id_monthly: "" },
      { id: "PRIORITY_SLA", name: "Priority SLA", monthly_fee_cents: 50000, requires_min_tier_id: "DFY_OPS", stripe_price_id_monthly: "" },
    ];
    for (const a of addons) {
      await db.collection("pricing_addons").doc(a.id).set({
        addon_id: a.id,
        name: a.name,
        description: "",
        is_active: true,
        monthly_fee_cents: a.monthly_fee_cents,
        stripe_price_id_monthly: a.stripe_price_id_monthly,
        requires_min_tier_id: a.requires_min_tier_id,
        version: 1,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }

    await logEvent("pricing_seeded", { version: 1 }, { uid });
    return { ok: true };
  }
);
