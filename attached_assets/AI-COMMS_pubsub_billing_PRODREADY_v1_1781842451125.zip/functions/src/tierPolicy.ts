// AICOMMS/APPS/aicomms-site/functions/src/tierPolicy.ts

export type Tier = "free" | "explorer" | "audit" | "pro" | "enterprise";
export type Capability =
  | "audit_generate"
  | "proposal_generate"
  | "proposal_send"
  | "contract_generate"
  | "contract_send"
  | "client_portal";

export function normalizeTier(v: any): Tier {
  const s = String(v || "").trim().toLowerCase();
  if (s === "enterprise") return "enterprise";
  if (s === "pro") return "pro";
  if (s === "audit") return "audit";
  if (s === "explorer") return "explorer";
  return "free";
}

const TIER_CAPS: Record<Tier, Set<Capability>> = {
  explorer: new Set<Capability>(["client_portal", "audit_generate"]),
  free: new Set<Capability>(["client_portal"]),
  audit: new Set<Capability>(["client_portal", "audit_generate"]),
  pro: new Set<Capability>([
    "client_portal",
    "audit_generate",
    "proposal_generate",
    "proposal_send",
    "contract_generate",
    "contract_send",
  ]),
  enterprise: new Set<Capability>([
    "client_portal",
    "audit_generate",
    "proposal_generate",
    "proposal_send",
    "contract_generate",
    "contract_send",
  ]),
};

/**
 * Optional admin override:
 * lead.tier_override = "pro" | "enterprise" | "audit" | "free"
 */
export function effectiveTier(lead: any): Tier {
  if (!lead) return "free";
  const override = normalizeTier(lead.tier_override);
  if (override !== "free") return override;
  return normalizeTier(lead.tier);
}

export function hasCapability(lead: any, cap: Capability): boolean {
  const tier = effectiveTier(lead);
  return TIER_CAPS[tier].has(cap);
}

export function assertCapability(lead: any, cap: Capability): { ok: true; tier: Tier } | { ok: false; tier: Tier } {
  const tier = effectiveTier(lead);
  return TIER_CAPS[tier].has(cap) ? { ok: true, tier } : { ok: false, tier };
}