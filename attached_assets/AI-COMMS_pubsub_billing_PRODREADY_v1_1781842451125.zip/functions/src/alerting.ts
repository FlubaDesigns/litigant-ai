import { db } from "./firebaseAdmin";
import { sendAdminEmail } from "./emailResend";

export type AlertLevel = "info" | "warn" | "critical";

export async function sendAlert(level: AlertLevel, subject: string, message: string, meta?: any) {
  try {
    // Try email if configured
    await sendAdminEmail({
      subject: `[AICOMMS ${level.toUpperCase()}] ${subject}`,
      html: `<pre style="white-space:pre-wrap">${escapeHtml(message)}\n\n${escapeHtml(JSON.stringify(meta||{}, null, 2))}</pre>`,
    });
  } catch {
    // ignore email failure
  }
  try {
    await db.collection("alerts").add({
      level,
      subject,
      message,
      meta: meta || null,
      created_at: new Date(),
    });
  } catch {}
}

function escapeHtml(s: string) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
