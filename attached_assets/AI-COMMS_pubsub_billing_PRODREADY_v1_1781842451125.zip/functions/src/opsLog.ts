import { admin, db } from "./firebaseAdmin";

/**
 * Minimal production visibility:
 * Write any critical failures to /ops_errors so the owner can see them in Admin.
 * No secrets should be written here.
 */
export async function logOpsError(kind: string, error: unknown, meta: Record<string, any> = {}) {
  const msg =
    error instanceof Error
      ? { name: error.name, message: error.message, stack: error.stack || null }
      : { name: "UnknownError", message: String(error), stack: null };

  await db.collection("ops_errors").add({
    kind,
    error: msg,
    meta,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });
}
