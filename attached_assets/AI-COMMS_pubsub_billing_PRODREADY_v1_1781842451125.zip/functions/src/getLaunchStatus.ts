import { db } from "./firebaseAdmin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";

// Secrets we can sanity-check without revealing values
const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const STRIPE_WEBHOOK_SECRET = defineSecret("STRIPE_WEBHOOK_SECRET");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");
const SOCKET_APPROVAL_SHARED_SECRET = defineSecret("SOCKET_APPROVAL_SHARED_SECRET");

type Check = { ok: boolean; detail?: string; missing?: string[]; missingStripeIds?: string[]; lastSeenAt?: string };

function truthy(v?: string) {
  return typeof v === "string" && v.trim().length > 0;
}

export const getLaunchStatus = onCall(
  { enforceAppCheck: true, region: "us-central1" },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");

    const checks: Record<string, Check> = {};

    // Admin doc
    const adminSnap = await db.collection("admins").doc(uid).get();
    checks.adminDoc = adminSnap.exists
      ? { ok: true, detail: "Admin bootstrap present." }
      : { ok: false, detail: "Missing /admins/{uid}. Create admin doc for this user." };

    if (!adminSnap.exists) {
      return { ok: false, checks };
    }

    // Pricing version
    const pv = await db.collection("pricing_version").doc("config").get();
    checks.pricingVersion = pv.exists
      ? { ok: true, detail: "pricing_version/config exists." }
      : { ok: false, detail: "Missing pricing_version/config. Run seedPricing or create it manually." };

    // Active tiers and Stripe IDs
    const tiersSnap = await db.collection("pricing_tiers").where("is_active", "==", true).get();
    const missingTierStripe: string[] = [];
    tiersSnap.forEach((d) => {
      const x: any = d.data();
      const monthly = String(x.stripe_price_id_monthly || "").trim();
      const onboardingFee = Number(x.onboarding_fee_cents || 0);
      const onboarding = String(x.stripe_price_id_onboarding || "").trim();
      if (!monthly) missingTierStripe.push(`${d.id}:stripe_price_id_monthly`);
      if (onboardingFee > 0 && !onboarding) missingTierStripe.push(`${d.id}:stripe_price_id_onboarding`);
    });
    checks.activeTiers = tiersSnap.empty
      ? { ok: false, detail: "No active tiers found in pricing_tiers.", missingStripeIds: [] }
      : missingTierStripe.length
        ? { ok: false, detail: "Some active tiers are missing Stripe Price IDs.", missingStripeIds: missingTierStripe }
        : { ok: true, detail: `Active tiers OK (${tiersSnap.size}).` };

    // Active addons and Stripe IDs
    const addonsSnap = await db.collection("pricing_addons").where("is_active", "==", true).get();
    const missingAddonStripe: string[] = [];
    addonsSnap.forEach((d) => {
      const x: any = d.data();
      const monthly = String(x.stripe_price_id_monthly || "").trim();
      if (!monthly) missingAddonStripe.push(`${d.id}:stripe_price_id_monthly`);
    });
    checks.activeAddons = addonsSnap.empty
      ? { ok: true, detail: "No active addons (ok)." }
      : missingAddonStripe.length
        ? { ok: false, detail: "Some active addons are missing Stripe Price IDs.", missingStripeIds: missingAddonStripe }
        : { ok: true, detail: `Active addons OK (${addonsSnap.size}).` };

    // Secrets presence (do not reveal values)
    const missingSecrets: string[] = [];
    try { if (!truthy(STRIPE_SECRET_KEY.value())) missingSecrets.push("STRIPE_SECRET_KEY"); } catch { missingSecrets.push("STRIPE_SECRET_KEY"); }
    try { if (!truthy(STRIPE_WEBHOOK_SECRET.value())) missingSecrets.push("STRIPE_WEBHOOK_SECRET"); } catch { missingSecrets.push("STRIPE_WEBHOOK_SECRET"); }
    // Optional but recommended
    try { if (!truthy(PUBLIC_SITE_BASE_URL.value())) missingSecrets.push("PUBLIC_SITE_BASE_URL"); } catch { missingSecrets.push("PUBLIC_SITE_BASE_URL"); }

    // Socket env vars (process.env)
    const socketBase = String(process.env.SOCKET_BASE_URL || process.env.SOCKET_BASE || "").trim();
    const socketToken = String(process.env.SOCKET_API_TOKEN || "").trim();
    const socketKey = String(process.env.SOCKET_API_KEY || "").trim();
    if (!socketBase) missingSecrets.push("SOCKET_BASE_URL");
    if (!socketToken && !socketKey) missingSecrets.push("SOCKET_API_TOKEN|SOCKET_API_KEY");

    // Approval shared secret (only needed if using server-to-server createApproval)
    try { if (!truthy(SOCKET_APPROVAL_SHARED_SECRET.value())) missingSecrets.push("SOCKET_APPROVAL_SHARED_SECRET"); } catch { missingSecrets.push("SOCKET_APPROVAL_SHARED_SECRET"); }

    checks.secrets = missingSecrets.length
      ? { ok: false, detail: "Missing required secrets/env.", missing: missingSecrets }
      : { ok: true, detail: "Secrets/env appear present." };

    // Webhook last seen (system_events kind=stripe_webhook_received)
    const last = await db.collection("system_events")
      .where("kind", "==", "stripe_webhook_received")
      .orderBy("created_at", "desc")
      .limit(1)
      .get();
    if (last.empty) {
      checks.lastWebhook = { ok: false, detail: "No verified Stripe webhook events logged yet." };
    } else {
      const d: any = last.docs[0].data();
      const ts = d.created_at?.toDate ? d.created_at.toDate().toISOString() : String(d.created_at || "");
      checks.lastWebhook = { ok: true, detail: "Stripe webhook seen.", lastSeenAt: ts };
    }

    const ok = Object.values(checks).every((c) => c.ok);
    return { ok, checks };
  }
);
