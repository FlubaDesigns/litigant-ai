import { admin, db } from "./firebaseAdmin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { normalizeTier, Tier } from "./tierPolicy";
import { bumpDailyIpCounter } from "./lib/rateLimit";
import { logEvent } from "./lib/logEvent";
const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

// Optional pricing knobs (set as secrets if you want)
const STRIPE_CURRENCY = defineSecret("STRIPE_CURRENCY"); // default "usd"
const STRIPE_UNIT_AMOUNT_CENTS = defineSecret("STRIPE_UNIT_AMOUNT_CENTS");
const STRIPE_EXPLORER_UNIT_AMOUNT_CENTS = defineSecret("STRIPE_EXPLORER_UNIT_AMOUNT_CENTS");

function getClientIp(req: any) {
  const raw = String(req?.rawRequest?.ip || req?.rawRequest?.headers?.["x-forwarded-for"] || "unknown");
  return raw.split(",")[0].trim() || "unknown";
}
 // default "2500" // default "9900"

// Optional: different price for pro/enterprise later (leave unset for now)
const STRIPE_PRO_UNIT_AMOUNT_CENTS = defineSecret("STRIPE_PRO_UNIT_AMOUNT_CENTS"); // default "19900"
const STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS = defineSecret("STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS"); // default "49900"

function amountForTier(tier: Tier): number {
  if (tier === "enterprise") return parseInt(STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS.value() || "49900", 10);
  if (tier === "pro") return parseInt(STRIPE_PRO_UNIT_AMOUNT_CENTS.value() || "19900", 10);
  if (tier === "explorer") return parseInt(STRIPE_EXPLORER_UNIT_AMOUNT_CENTS.value() || "2500", 10);
  return parseInt(STRIPE_UNIT_AMOUNT_CENTS.value() || "9900", 10);
}

export const createCheckoutSession = onCall(
  {
    enforceAppCheck: true,
    region: "us-central1",
    secrets: [
      STRIPE_SECRET_KEY,
      PUBLIC_SITE_BASE_URL,
      STRIPE_CURRENCY,
      STRIPE_UNIT_AMOUNT_CENTS,
      STRIPE_EXPLORER_UNIT_AMOUNT_CENTS,
      STRIPE_PRO_UNIT_AMOUNT_CENTS,
      STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS,
    ],
  },
  async (request) => {
    const { leadId, email, tier, acceptedTerms } = (request.data || {}) as {
      leadId?: string | null;
      email?: string | null;
      tier?: string | null;
      acceptedTerms?: boolean | null;
    };

    
if (!acceptedTerms) {
  throw new HttpsError("failed-precondition", "Terms must be accepted.");
}

const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });

    const baseUrl = PUBLIC_SITE_BASE_URL.value();
    const currency = (STRIPE_CURRENCY.value() || "usd").toLowerCase();

    if (!baseUrl) throw new HttpsError("failed-precondition", "Missing PUBLIC_SITE_BASE_URL.");
// Rate limit: block abusive checkout creation
const ip = getClientIp(request);
const limitRes = await bumpDailyIpCounter(ip, 60);
if (limitRes.limited) {
  await logEvent("checkout_rate_limited", { ip, count: limitRes.count, limit: limitRes.limit });
  throw new HttpsError("resource-exhausted", "Too many checkout attempts. Try again later.");
}



    const chosenTier = normalizeTier(tier || "audit");

    const userId = request.auth?.uid || null;
    if (chosenTier === "explorer" && !userId) {
      throw new HttpsError("unauthenticated", "Explorer (Governance Credit) requires sign-in so credits can be applied.");
    }

    const unitAmount = amountForTier(chosenTier);

    if (!Number.isFinite(unitAmount) || unitAmount < 100) {
      throw new HttpsError("failed-precondition", "Invalid Stripe unit amount for tier.");
    }

    // Verify lead exists if leadId provided
    if (leadId) {
      const snap = await db.collection("leads").doc(String(leadId)).get();
      if (!snap.exists) throw new HttpsError("not-found", "Lead not found.");
      // Record legal acceptance on lead (minimal compliance record)
      await snap.ref.set({
        legal_acceptance: {
          version: "v1",
          accepted_at: admin.firestore.FieldValue.serverTimestamp(),
        },
      }, { merge: true });
    }

    const label =
      chosenTier === "enterprise"
        ? "AI‑COMMS Enterprise"
        : chosenTier === "pro"
        ? "AI‑COMMS Pro"
        : chosenTier === "explorer"
        ? "AI‑COMMS Governance Credit"
        : "AI‑COMMS Audit";

    const desc =
      chosenTier === "enterprise"
        ? "Enterprise governance build + multi‑agent arbitration"
        : chosenTier === "pro"
        ? "Audit + proposal + contract automation (tier gated)"
        : chosenTier === "explorer"
        ? "One‑time governance credit. Credits never expire and apply to upgrades."
        : "AI drift + failure audit + governance recommendations";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: email || undefined,
      success_url: `${baseUrl}/checkout/success?leadId=${encodeURIComponent(leadId || "")}&tier=${encodeURIComponent(chosenTier)}`,
      cancel_url: `${baseUrl}/checkout/cancel?leadId=${encodeURIComponent(leadId || "")}&tier=${encodeURIComponent(chosenTier)}`,
      line_items: [
        {
          price_data: {
            currency,
            unit_amount: unitAmount,
            product_data: { name: label, description: desc },
          },
          quantity: 1,
        },
      ],
      metadata: {
        protection_model: "AI_SECURITY_BLANKET",
        plan: chosenTier,
        leadId: leadId || "",
        tier: chosenTier,
        userId: userId || "",
        email: email || "",
      },
    });

    return { url: session.url };
  }
);