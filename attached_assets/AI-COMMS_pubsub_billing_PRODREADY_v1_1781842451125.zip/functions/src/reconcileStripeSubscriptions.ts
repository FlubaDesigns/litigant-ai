import * as functions from "firebase-functions";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { admin, db } from "./firebaseAdmin";
import { logProtectionEvent } from "./logProtectionEvent";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");

/**
 * reconcileStripeSubscriptions
 * Daily best-effort reconciliation for customers with stripe_customer_id.
 * If no subscriptions exist, it leaves the user unchanged (supports one-time payments too).
 */
export const reconcileStripeSubscriptions = functions.pubsub
  .schedule("every day 02:40")
  .timeZone("UTC")
  .onRun(async () => {
    const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });

    const users = await db.collection("users").where("stripe_customer_id", "!=", "").limit(200).get();
    for (const doc of users.docs) {
      const uid = doc.id;
      const u = doc.data() as any;
      const customerId = String(u.stripe_customer_id || "").trim();
      if (!customerId) continue;

      // Pull the most recent subscription (if any)
      const subs = await stripe.subscriptions.list({ customer: customerId, limit: 1 });
      if (!subs.data.length) continue;

      const sub = subs.data[0];
      const status = String(sub.status || "");
      const update: any = { updated_at: admin.firestore.FieldValue.serverTimestamp() };

      if (status === "active" || status === "trialing") {
        update.billing_status = "active";
        update.grace_expires_at = admin.firestore.FieldValue.delete();
      } else if (status === "past_due" || status === "unpaid") {
        update.billing_status = "grace";
        update.grace_expires_at = admin.firestore.Timestamp.fromMillis(Date.now() + 7 * 24 * 60 * 60 * 1000);
      } else if (status === "canceled") {
        update.billing_status = "canceled";
      }

      await db.collection("users").doc(uid).set(update, { merge: true });

      await logProtectionEvent({
        userId: uid,
        severity: "calm",
        type: "billing",
        message: `Reconciled subscription status: ${status}`,
        metadata: { subscriptionId: sub.id },
      });
    }

    console.log("reconcileStripeSubscriptions: done");
    return null;
  });
