import { onRequest } from "firebase-functions/v2/https";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";

function sha256(buf: Buffer) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

function safeReadJson(p: string) {
  try {
    const raw = fs.readFileSync(p);
    return { ok: true as const, json: JSON.parse(raw.toString("utf8")), hash: sha256(raw) };
  } catch (e: any) {
    return { ok: false as const, error: e?.message || String(e) };
  }
}

export const health = onRequest(
  { region: "us-central1" },
  async (req, res) => {
    const harnessEnabled = String(process.env.HARNESS_ENABLED || "").toLowerCase() === "true";

    // Attempt to read toolbox manifest from sibling governance folder.
    // If not present, health still returns OK, just reports "missing".
    const toolboxPath = path.resolve(__dirname, "../../governance/toolbox.manifest.json");
    const toolbox = safeReadJson(toolboxPath);

    res.status(200).json({
      ok: true,
      service: "aicomms-site-functions",
      harness: {
        enabled: harnessEnabled,
        toolbox_manifest: toolbox.ok
          ? { present: true, sha256: toolbox.hash, tiers: Object.keys(toolbox.json?.toolbox?.tiers || {}) }
          : { present: false, error: toolbox.error }
      },
      time_utc: new Date().toISOString()
    });
  }
);