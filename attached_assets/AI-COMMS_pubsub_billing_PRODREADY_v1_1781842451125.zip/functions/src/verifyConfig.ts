import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import { db } from "./firebaseAdmin";

// Keep aligned with what your deployed stack uses.
// IMPORTANT: Do NOT add new required secrets here unless you've actually set them in Firebase.
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");
const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const STRIPE_WEBHOOK_SECRET = defineSecret("STRIPE_WEBHOOK_SECRET");

async function isAdmin(uid: string): Promise<boolean> {
  const snap = await db.collection("admins").doc(uid).get();
  return snap.exists;
}

function check(name: string, ok: boolean, detail?: any) {
  return { name, ok, detail: detail ?? null };
}

export const verifyConfig = onCall(
  {
    region: "us-central1",
    secrets: [PUBLIC_SITE_BASE_URL, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET],
  },
  async (req) => {
    if (!req.auth?.uid) throw new HttpsError("unauthenticated", "Login required.");
    if (!(await isAdmin(req.auth.uid))) throw new HttpsError("permission-denied", "Admin required.");

    const appId = String(req.data?.appId || "").trim() || "aicomms_site";

    // Core docs expected by governance flow
    const runtimeSnap = await db.collection("runtime_config").doc(appId).get();
    const securitySnap = await db.collection("system_state").doc("security_config").get();
    const providerCtlSnap = await db.collection("provider_controls").doc("current").get();

    const checks: any[] = [];

    checks.push(check("runtime_config.exists", runtimeSnap.exists, runtimeSnap.exists ? "ok" : "missing runtime_config/{appId}"));
    checks.push(check("system_state.security_config.exists", securitySnap.exists, securitySnap.exists ? "ok" : "missing system_state/security_config"));
    checks.push(check("provider_controls.current.exists", providerCtlSnap.exists, providerCtlSnap.exists ? "ok" : "missing provider_controls/current"));

    // Secrets: we can only confirm that they were injected as non-empty strings.
    checks.push(check("secret.PUBLIC_SITE_BASE_URL.present", Boolean(PUBLIC_SITE_BASE_URL.value()), null));
    checks.push(check("secret.STRIPE_SECRET_KEY.present", Boolean(STRIPE_SECRET_KEY.value()), null));
    checks.push(check("secret.STRIPE_WEBHOOK_SECRET.present", Boolean(STRIPE_WEBHOOK_SECRET.value()), null));

    // Owner-gate readiness (stored in Firestore, not secrets)
    const sec = securitySnap.exists ? securitySnap.data() : null;
    checks.push(check("owner.owner_uid.present", Boolean(sec?.owner_uid), sec?.owner_uid ? "ok" : "owner_uid missing"));
    checks.push(check("owner.owner_pin_hash.present", Boolean(sec?.owner_pin_hash), sec?.owner_pin_hash ? "ok" : "owner_pin_hash missing"));

    const ok = checks.every((c) => c.ok === true);

    return {
      ok,
      appId,
      checked_at: new Date().toISOString(),
      checks,
    };
  }
);
