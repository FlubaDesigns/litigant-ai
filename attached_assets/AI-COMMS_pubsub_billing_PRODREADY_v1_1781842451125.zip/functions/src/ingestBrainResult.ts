import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import { admin, db } from "./firebaseAdmin";
import Stripe from "stripe";
import crypto from "crypto";
import { logEvent } from "./lib/logEvent";

const BRAIN_CALLBACK_SECRET = defineSecret("BRAIN_CALLBACK_SECRET");
const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");

/**
 * ingestBrainResult
 * Brain -> AI-COMMS callback endpoint.
 * Validates HMAC signature over raw body, then stores result + updates job status.
 *
 * Brain must send header:
 *   x-aicomms-signature: <hex hmac sha256>
 */
export const ingestBrainResult = onRequest(
  { timeoutSeconds: 60, cors: false, secrets: [BRAIN_CALLBACK_SECRET, STRIPE_SECRET_KEY] },
  async (req, res) => {
    try {
      if (req.method !== "POST") return res.status(405).send("Method Not Allowed");
      const sig = String(req.header("x-aicomms-signature") || "");
      const raw = (req as any).rawBody ? Buffer.from((req as any).rawBody) : Buffer.from(JSON.stringify(req.body || {}));
      const expected = crypto
        .createHmac("sha256", BRAIN_CALLBACK_SECRET.value())
        .update(raw)
        .digest("hex");

      if (!sig) {
        await logEvent({ kind: "brain_result_sig_fail", severity: "warn", meta: { reason: "missing" } });
        return res.status(401).send("Invalid signature");
      }

      // timingSafeEqual requires equal-length buffers
      const sigBuf = Buffer.from(sig);
      const expBuf = Buffer.from(expected);
      if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
        await logEvent({ kind: "brain_result_sig_fail", severity: "warn" });
        return res.status(401).send("Invalid signature");
      }

      const body = req.body || {};
      const jobId = String(body.jobId || "");
      if (!jobId) return res.status(400).send("Missing jobId");

      const status = String(body.status || "done");
      const result = body.result ?? {};
      const usage = body.usage ?? {};

      await db.collection("brain_results").doc(jobId).set(
        {
          jobId,
          status,
          result,
          usage,
          receivedAt: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      await db.collection("brain_jobs").doc(jobId).set(
        {
          status,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          lastError: body.error || null,
        },
        { merge: true }
      );

      
      // ---- Billing reconciliation (AI-COMMS is source of truth) ----
      // Idempotency: one ledger entry per jobId
      const jobSnap = await db.collection("brain_jobs").doc(jobId).get();
      const jobData = (jobSnap.exists ? (jobSnap.data() as any) : {}) || {};
      const uid = String(jobData.uid || jobData.userId || "");
      const minutesBudget = Number(jobData.minutesBudget || 0);

      const minutesUsedRaw = Number(usage.minutesUsed ?? usage.minutes_used ?? 0);
      const minutesUsed = Math.max(0, Math.ceil(minutesUsedRaw));

      if (uid && minutesUsed > 0) {
        // If we've already billed this job, do nothing (prevents double charge on retries)
        const already = await db.collection("usage_ledger").where("jobId", "==", jobId).limit(1).get();
        if (already.empty) {
          const userRef = db.collection("users").doc(uid);
          const uSnap = await userRef.get();
          const u = (uSnap.exists ? (uSnap.data() as any) : {}) || {};

          const plan = String(u.plan || u.tier || "").toLowerCase();
          const included = Number(u.included_minutes_per_month || 60);
          const usedBefore = Number(u.minutes_used_current_period || 0);

          // Billable minutes are capped by the budget we assigned at submit time (if any)
          const billableMinutes = minutesBudget > 0 ? Math.min(minutesUsed, minutesBudget) : minutesUsed;

          const usedAfter = usedBefore + billableMinutes;
          const overageNow = Math.max(0, usedAfter - included);
          const overageBefore = Math.max(0, usedBefore - included);
          const overageDelta = Math.max(0, overageNow - overageBefore);

          // Append-only ledger entry
          await db.collection("usage_ledger").add({
            jobId,
            userId: uid,
            orgId: String(jobData.orgId || ""),
            planTier: plan || String(jobData.planTier || ""),
            minutesBudget,
            minutesUsed,
            billableMinutes,
            overageMinutes: overageDelta,
            source: "brain_job",
            detail: String(jobData.intent || ""),
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
          });

          // Update user running counters
          await userRef.set(
            {
              minutes_used_current_period: usedAfter,
              lifetime_minutes_used: admin.firestore.FieldValue.increment(billableMinutes),
              updated_at: admin.firestore.FieldValue.serverTimestamp(),
            },
            { merge: true }
          );

          // Optional metered overage reporting to Stripe (only if user is on minutes plan and has a subscription item id)
          const subItem = String(u.overage_subscription_item_id || "").trim();
          if (subItem && overageDelta > 0) {
            const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });
            await stripe.subscriptionItems.createUsageRecord(subItem, {
              quantity: overageDelta,
              timestamp: Math.floor(Date.now() / 1000),
              action: "increment",
            });
          }
        }
      }
      // ---- end billing reconciliation ----

await logEvent({ kind: "brain_result_ingested", severity: "info", jobId, status });

      return res.status(200).json({ ok: true });
    } catch (e: any) {
      await logEvent({ kind: "brain_result_ingest_fail", severity: "error", message: String(e?.message || e) });
      return res.status(500).send("Server error");
    }
  }
);
