
import { admin, db } from "./firebaseAdmin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { logEvent } from "./lib/logEvent";
import { socketPost } from "./socketClient";
import { logOpsError } from "./opsLog";

export const resolveApproval = onCall(
  { enforceAppCheck: true, region: "us-central1" },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");

    const approvalId = String(req.data?.approvalId || "").trim();
    const decision = String(req.data?.decision || "").trim(); // approve|reject
    const comment = String(req.data?.comment || "").trim();

    if (!approvalId) throw new HttpsError("invalid-argument", "approvalId required.");
    if (!["approve","reject"].includes(decision)) throw new HttpsError("invalid-argument", "decision must be approve|reject.");

    const ref = db.collection("approvals").doc(approvalId);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpsError("not-found", "Approval not found.");

    const data = snap.data() as any;
    const ownerUid = String(data.owner_uid || "");
    // MVP: owner or admin only. Admin detection: /admins/{uid}
    const adminSnap = await db.collection("admins").doc(uid).get();
    const isAdmin = adminSnap.exists;

    if (uid !== ownerUid && !isAdmin) throw new HttpsError("permission-denied", "Not allowed.");

    if (String(data.status || "") !== "pending") throw new HttpsError("failed-precondition", "Approval already decided.");

    await ref.set({
      status: decision === "approve" ? "approved" : "rejected",
      decision: {
        decided_at: admin.firestore.FieldValue.serverTimestamp(),
        decided_by_uid: uid,
        decision,
        comment,
      },
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    
    // Optional: resume job in Brain/Socket if this approval carries a resume payload
    try {
      if (decision === "approve" && data.resume_on_approve && data.job_id) {
        const payload = data.resume_payload || {};
        await socketPost(`/jobs/${encodeURIComponent(String(data.job_id))}/resume`, {
          approvalId,
          orgId: String(data.org_id || ""),
          decision,
          payload,
        });
        await logEvent("approval_resumed_job", { approvalId, jobId: data.job_id }, { uid });
      }
    } catch (e: any) {
      await logOpsError("approval_resume_failed", e, { approvalId, jobId: data.job_id });
    }
await logEvent("approval_decided", { approvalId, decision }, { uid });

    return { ok: true };
  }
);
