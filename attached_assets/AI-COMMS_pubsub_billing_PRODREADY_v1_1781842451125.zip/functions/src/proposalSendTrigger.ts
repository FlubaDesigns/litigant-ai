import { admin, db } from "./firebaseAdmin";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
import { Resend } from "resend";
import { logger } from "firebase-functions";
import { assertCapability } from "./tierPolicy";
const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");

function safeText(v: any, fb = "") {
  if (v === null || v === undefined) return fb;
  const s = String(v).trim();
  return s.length ? s : fb;
}

/**
 * 3) Idempotency: email_outbox doc prevents duplicate sends.
 * Deterministic messageId: proposal:{leadId}
 */
async function reserveOutboxOnce(messageId: string, payload: any) {
  const ref = db.collection("email_outbox").doc(messageId);
  return await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (snap.exists && (snap.data() as any)?.status === "sent") {
      return { ok: false, reason: "already_sent" as const };
    }
    if (snap.exists && (snap.data() as any)?.status === "sending") {
      return { ok: false, reason: "already_sending" as const };
    }
    tx.set(
      ref,
      {
        status: "sending",
        created_at: admin.firestore.FieldValue.serverTimestamp(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
        payload,
      },
      { merge: true }
    );
    return { ok: true };
  });
}

export const sendProposalOnApproval = onDocumentUpdated(
  {
    document: "leads/{leadId}",
    secrets: [RESEND_API_KEY, AICOMMS_FROM_EMAIL],
    region: "us-central1",
  },
  async (event) => {
    const leadId = event.params.leadId as string;
    const before = event.data?.before?.data() as any;
    const after = event.data?.after?.data() as any;

    if (!before || !after) return;
    if (!(before.status !== "proposal_approved" && after.status === "proposal_approved")) return;

    // Tier gating
    const gate = assertCapability(after, "proposal_send");
    if (!gate.ok) {
      logger.warn("Proposal send blocked by tier.", { leadId, tier: gate.tier });
      await db.collection("leads").doc(leadId).set(
        { status: "tier_blocked_proposal_send", tier_effective: gate.tier, updated_at: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );
      return;
    }

    const to = safeText(after.email);
    if (!to) {
      logger.error("No client email on lead. Cannot send proposal.", { leadId });
      return;
    }

    const proposal = safeText(after.proposal_final) || safeText(after.proposal_draft);
    if (!proposal) {
      logger.error("No proposal text found. Cannot send.", { leadId });
      return;
    }

    // 3) Idempotency reserve
    const messageId = `proposal:${leadId}`;
    const reserve = await reserveOutboxOnce(messageId, {
      kind: "proposal",
      leadId,
      to,
      subject: "Your AI Guardrail Proposal (Intuitive / AIComms)",
    });

    if (!reserve.ok) {
      logger.info("Proposal send skipped due to outbox idempotency.", { leadId, reason: reserve.reason });
      return;
    }

    const resend = new Resend(RESEND_API_KEY.value());

    const html = `
      <div style="font-family: Arial, sans-serif; line-height: 1.5">
        <h2>Your Proposal</h2>
        <p>Below is your AI Guardrail implementation proposal.</p>
        <hr/>
        <pre style="white-space: pre-wrap; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${proposal
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")}</pre>
        <hr/>
        <p>Reply to this email to approve and schedule the next step.</p>
        <p>— Intuitive (Powered by AIComms)</p>
      </div>
    `;

    try {
      const sent = await resend.emails.send({
        from: AICOMMS_FROM_EMAIL.value(),
        to,
        subject: "Your AI Guardrail Proposal (Intuitive / AIComms)",
        html,
      });

      await db.collection("email_outbox").doc(messageId).set(
        {
          status: "sent",
          provider: "resend",
          provider_id: (sent as any)?.data?.id || null,
          sent_at: admin.firestore.FieldValue.serverTimestamp(),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      await db.collection("leads").doc(leadId).set(
        {
          status: "proposal_sent",
          proposal_sent_at: admin.firestore.FieldValue.serverTimestamp(),
          tier_effective: gate.tier,
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      logger.info("Proposal sent.", { leadId, tier: gate.tier });
    } catch (err: any) {
      await db.collection("email_outbox").doc(messageId).set(
        {
          status: "error",
          error: err?.message || String(err),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
      throw err;
    }
  }
);