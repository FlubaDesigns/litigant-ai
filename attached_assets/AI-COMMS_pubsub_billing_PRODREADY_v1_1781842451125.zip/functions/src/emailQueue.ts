import { admin, db } from "./firebaseAdmin";

export async function queueEmail(args: {
  to: string;
  subject: string;
  html: string;
  kind?: string;
  userId?: string | null;
  leadId?: string | null;
  tier?: string | null;
  stripeEventId?: string | null;
  stripeSessionId?: string | null;
}) {
  if (!args.to) throw new Error("missing_to");
  const toNorm = String(args.to).trim().toLowerCase();
  // Suppression (bounce/unsubscribe/etc.)
  try {
    const supSnap = await db.collection("email_suppressions").doc(toNorm).get();
    if (supSnap.exists) {
      await db.collection("email_suppressions_log").add({
        to: toNorm,
        reason: supSnap.data()?.reason || "suppressed",
        kind: args.kind || "transactional",
        created_at: admin.firestore.FieldValue.serverTimestamp(),
      });
      return; // do not enqueue suppressed email
    }
  } catch {
    // fail-open: if suppression lookup fails, still enqueue
  }

  await db.collection("email_outbox").add({
    to: args.to,
    subject: args.subject,
    html: args.html,
    kind: args.kind || "transactional",
    user_id: args.userId || null,
    lead_id: args.leadId || null,
    tier: args.tier || null,
    stripe_event_id: args.stripeEventId || null,
    stripe_session_id: args.stripeSessionId || null,
    status: "queued",
    attempts: 0,
    last_error: null,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });
}
