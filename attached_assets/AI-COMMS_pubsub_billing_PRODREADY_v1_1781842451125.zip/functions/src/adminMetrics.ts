import { onCall, HttpsError } from "firebase-functions/v2/https";
import { db } from "./firebaseAdmin";

/**
 * adminMetrics
 * Returns system-wide revenue + health stats.
 * Requires admin custom claim: decoded.admin === true
 */
export const adminMetrics = onCall(
  { enforceAppCheck: true, region: "us-central1" },
  async (req) => {
    if (!req.auth?.token?.admin) {
      throw new HttpsError("permission-denied", "Admin access required.");
    }

    const usersSnap = await db.collection("users").get();
    const eventsSnap = await db.collection("protection_events").get();

    let active = 0;
    let grace = 0;
    let canceled = 0;

    usersSnap.forEach((doc) => {
      const d = doc.data();
      const status = String(d.billing_status || "");
      if (status === "active") active++;
      if (status === "grace") grace++;
      if (status === "canceled") canceled++;
    });

    const totalUsers = usersSnap.size;
    const totalEvents = eventsSnap.size;

    return {
      totalUsers,
      activeSubscriptions: active,
      graceSubscriptions: grace,
      canceledSubscriptions: canceled,
      totalProtectionEvents: totalEvents,
    };
  }
);
