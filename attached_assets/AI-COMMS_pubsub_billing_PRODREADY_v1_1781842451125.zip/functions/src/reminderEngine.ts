import { admin, db } from "./firebaseAdmin";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { defineSecret } from "firebase-functions/params";
import { Resend } from "resend";
const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

/**
 * Daily admin reminder:
 * - scans leads in proposal_review or contract_review
 * - emails admin a short digest
 */
export const lifecycleReminder = onSchedule(
  {
    schedule: "every day 09:00",
    timeZone: "America/New_York",
    region: "us-central1",
    secrets: [RESEND_API_KEY, AICOMMS_FROM_EMAIL, AICOMMS_ADMIN_EMAIL],
  },
  async () => {
    const resend = new Resend(RESEND_API_KEY.value());

    const proposalReviewSnap = await db.collection("leads").where("status", "==", "proposal_review").limit(25).get();
    const contractReviewSnap = await db.collection("leads").where("status", "==", "contract_review").limit(25).get();

    const lines: string[] = [];

    if (!proposalReviewSnap.empty) {
      lines.push("PROPOSAL_REVIEW:");
      proposalReviewSnap.docs.forEach((d) => {
        const x: any = d.data();
        lines.push(`- ${d.id} | ${x.company || "—"} | ${x.email || "—"}`);
      });
      lines.push("");
    }

    if (!contractReviewSnap.empty) {
      lines.push("CONTRACT_REVIEW:");
      contractReviewSnap.docs.forEach((d) => {
        const x: any = d.data();
        lines.push(`- ${d.id} | ${x.company || "—"} | ${x.email || "—"}`);
      });
      lines.push("");
    }

    if (lines.length === 0) return;

    await resend.emails.send({
      from: AICOMMS_FROM_EMAIL.value(),
      to: AICOMMS_ADMIN_EMAIL.value(),
      subject: "AIComms Admin Digest — Reviews Waiting",
      html: `<pre style="white-space:pre-wrap;font-family:ui-monospace,monospace;">${lines.join("\n")}</pre>`,
    });
  }
);