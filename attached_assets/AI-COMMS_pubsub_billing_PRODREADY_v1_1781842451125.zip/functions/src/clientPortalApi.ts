import { admin, db } from "./firebaseAdmin";
import { onRequest } from "firebase-functions/v2/https";
if (!admin.apps.length) /**
 * Minimal token check for v0:
 * - expects leads.client_token to exist
 * - request must supply token=...
 *
 * URL:
 * /clientStatus?leadId=...&token=...
 */
export const clientStatus = onRequest({ region: "us-central1" }, async (req, res) => {
  try {
    const leadId = String(req.query.leadId || "").trim();
    const token = String(req.query.token || "").trim();

    if (!leadId || !token) {
      res.status(400).json({ ok: false, error: "Missing leadId or token." });
      return;
    }

    const snap = await db.collection("leads").doc(leadId).get();
    if (!snap.exists) {
      res.status(404).json({ ok: false, error: "Lead not found." });
      return;
    }

    const lead = snap.data() as any;
    const stored = String(lead.client_token || "").trim();

    if (!stored || stored !== token) {
      res.status(403).json({ ok: false, error: "Invalid token." });
      return;
    }

    // Sanitized output only (no internal notes)
    res.json({
      ok: true,
      company: lead.company || null,
      status: lead.status || "new",
      audit: {
        started: !!lead.ai_audit?.generated_at,
        completed: !!lead.audit_completed_at || lead.status === "audit_completed",
      },
      proposal: {
        sent: lead.status === "proposal_sent" || !!lead.proposal_sent_at,
      },
      contract: {
        sent: lead.status === "contract_sent" || !!lead.contract_sent_at,
      },
    });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "Server error." });
  }
});