import { admin } from "./firebaseAdmin";

export type ProtectionSeverity = "calm" | "medium" | "critical";
export type ProtectionType = "drift" | "config" | "billing" | "policy" | "system";

export async function logProtectionEvent(params: {
  userId: string;
  severity: ProtectionSeverity;
  type: ProtectionType;
  message: string;
  metadata?: Record<string, any>;
}) {
  const { userId, severity, type, message, metadata = {} } = params;

  if (!userId) return;

  await admin.firestore().collection("protection_events").add({
    userId,
    severity,
    type,
    message,
    metadata,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
}
