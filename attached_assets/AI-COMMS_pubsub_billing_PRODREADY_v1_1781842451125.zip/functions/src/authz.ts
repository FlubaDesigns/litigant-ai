import { admin, db } from "./firebaseAdmin";

export async function requireUser(req: any) {
    const hdr = String(req.headers?.authorization || "");
  const m = hdr.match(/^Bearer\s+(.+)$/i);
  if (!m) return { ok: false as const, status: 401, message: "Missing Authorization: Bearer <token>" };

  try {
    const decoded = await admin.auth().verifyIdToken(m[1]);
    return { ok: true as const, decoded };
  } catch {
    return { ok: false as const, status: 401, message: "Invalid token" };
  }
}

export async function requireAdmin(decoded: any) {
  const uid = String(decoded?.uid || decoded?.user_id || "");
  if (!uid) return { ok: false as const, status: 403, message: "Admin only" };
  const snap = await db.collection("admins").doc(uid).get();
  if (!snap.exists) return { ok: false as const, status: 403, message: "Admin only" };
  return { ok: true as const };
}

export async function requireAppCheck(req: any) {
  const tok = String(req.headers?.["x-firebase-appcheck"] || req.headers?.["X-Firebase-AppCheck"] || "").trim();
  if (!tok) return { ok: false as const, status: 412, message: "Missing App Check token (X-Firebase-AppCheck)" };
  try {
    // @ts-ignore - appCheck exists on admin SDK v11+
    const decoded = await (admin as any).appCheck().verifyToken(tok);
    return { ok: true as const, decoded };
  } catch {
    return { ok: false as const, status: 412, message: "Invalid App Check token" };
  }
}
