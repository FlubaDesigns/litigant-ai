export const TASK_TYPES = [
  "RISKSCAN_LEAD_CAPTURE",
  "STRIPE_WEBHOOK_FULFILLMENT",
  "COPY_PAGE_GENERATION",
  "PATCH_SMALL",
  "PATCH_MULTI_FILE",
  "REFACTOR",
  "SPIDER_SCAN",
  "DRIFT_CHECK",
  "SECURITY_RULES_AUDIT",
  "DEPLOY_CHECK",
  "UNKNOWN",
] as const;

export type TaskType = (typeof TASK_TYPES)[number];

export function normalizeTaskType(input: any): TaskType {
  const raw = String(input || "").trim().toUpperCase();
  if (!raw) return "PATCH_SMALL";
  const match = TASK_TYPES.find((t) => t === raw);
  return (match || "UNKNOWN") as TaskType;
}
