import * as functions from "firebase-functions";
import { defineSecret } from "firebase-functions/params";
import { admin, db } from "./firebaseAdmin";
import { queueEmail } from "./emailQueue";
import { recordOpsSignal } from "./lib/opsSignals";
import { logEvent } from "./lib/logEvent";

const ADMIN_ALERT_EMAIL = defineSecret("ADMIN_ALERT_EMAIL");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

/**
 * systemAlerts
 * Hourly health alerting: webhook failures / DLQ growth / elevated ops errors.
 */
export const systemAlerts = functions.pubsub
  .schedule("every 60 minutes")
  .timeZone("UTC")
  .onRun(async () => {
    const to = (ADMIN_ALERT_EMAIL.value() || "").trim();
    if (!to) {
      console.log("systemAlerts: ADMIN_ALERT_EMAIL not set; skipping.");
      return null;
    }

    const since = admin.firestore.Timestamp.fromMillis(Date.now() - 60 * 60 * 1000);

    const opsErrSnap = await db
      .collection("ops_errors")
      .where("created_at", ">", since)
      .limit(1000)
      .get();

    const dlqSnap = await db.collection("email_dead_letter").limit(1000).get();

    // Stripe webhook failures are logged as ops_errors with type containing "stripe" in v13+; do a simple scan.
    let stripeFail = 0;
    opsErrSnap.forEach((d) => {
      const t = String((d.data() as any)?.kind || (d.data() as any)?.type || "");
      if (t.toLowerCase().includes("stripe")) stripeFail++;
    });

    const opsErrCount = opsErrSnap.size;
    const dlqCount = dlqSnap.size;

    const shouldAlert = stripeFail >= 1 || opsErrCount >= 10 || dlqCount >= 5;
    if (!shouldAlert) {
      console.log("systemAlerts: healthy (no alert).");
      return null;
    }

    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
    const adminUrl = baseUrl ? `${baseUrl}/admin` : "(set PUBLIC_SITE_BASE_URL)";

    const subject = `AI‑COMMS Alerts: ops=${opsErrCount} stripe=${stripeFail} dlq=${dlqCount}`;
    await recordOpsSignal("function_error", false, opsErrCount, { opsErrCount, stripeFail, dlqCount }, "systemAlerts triggered");
    await logEvent("system_alert_triggered", "WARN", "System alert triggered.", { opsErrCount, stripeFail, dlqCount });
    const html = `
      <h2>AI‑COMMS System Alert</h2>
      <p><b>Ops errors (last hour):</b> ${opsErrCount}</p>
      <p><b>Stripe-related errors (last hour):</b> ${stripeFail}</p>
      <p><b>Email DLQ count:</b> ${dlqCount}</p>
      <p><b>Admin console:</b> <a href="${adminUrl}">${adminUrl}</a></p>
      <p>Recommended action: open /admin, then inspect logs in Firebase Functions.</p>
    `;

    await queueEmail({
      to,
      subject,
      html,
      kind: "system_alert",
      userId: null,
      leadId: null,
      tier: null,
    });

    console.log("systemAlerts: alert queued.");
    return null;
  });
