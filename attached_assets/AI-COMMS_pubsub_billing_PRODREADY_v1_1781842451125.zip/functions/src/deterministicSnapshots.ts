import * as crypto from "crypto";
import { admin, db } from "./firebaseAdmin";

export type DeterministicSnapshot = {
  taskId: string;
  runId: string;
  canon_hash: string;
  taskType: string;
  scopeName: string;
  routing_snapshot?: any;
  inputs_hash: string;
  outputs_hash: string;
  created_at: FirebaseFirestore.FieldValue;
};

function sha256Hex(s: string) {
  return crypto.createHash("sha256").update(String(s || "")).digest("hex");
}

export function computeInputsHash(task: any) {
  const stable = {
    taskType: String(task.taskType || ""),
    scope_name: String(task.scope_name || ""),
    goal: String(task.goal || ""),
    canon_hash: String(task.canon_hash || ""),
    routing_snapshot: task.routing_snapshot || null,
    requested_agents: task.requested_agents || null,
  };
  return sha256Hex(JSON.stringify(stable));
}

export function computeOutputsHash(task: any) {
  const stable = {
    governance_state: String(task.governance_state || ""),
    plan: task.plan || null,
    build_result: task.build_result || null,
    verification: task.verification || null,
    last_error: task.last_error || null,
  };
  return sha256Hex(JSON.stringify(stable));
}

export async function writeSnapshot(taskId: string, runId: string) {
  const snap = await db.collection("tasks").doc(taskId).get();
  if (!snap.exists) throw new Error("task_not_found");
  const task = snap.data() as any;

  const inputs_hash = computeInputsHash(task);
  const outputs_hash = computeOutputsHash(task);

  await db.collection("tasks").doc(taskId).collection("deterministic_snapshots").add({
    taskId,
    runId,
    canon_hash: String(task.canon_hash || ""),
    taskType: String(task.taskType || ""),
    scopeName: String(task.scope_name || "AICOMMS"),
    routing_snapshot: task.routing_snapshot || null,
    inputs_hash,
    outputs_hash,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { inputs_hash, outputs_hash };
}

export async function verifyReplay(taskId: string, runId: string, expected_outputs_hash: string) {
  const snap = await db.collection("tasks").doc(taskId).get();
  if (!snap.exists) throw new Error("task_not_found");
  const task = snap.data() as any;
  const outputs_hash = computeOutputsHash(task);
  const ok = outputs_hash === expected_outputs_hash;

  await db.collection("tasks").doc(taskId).collection("replay_verifications").add({
    taskId,
    runId,
    expected_outputs_hash,
    actual_outputs_hash: outputs_hash,
    ok,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });

  return { ok, expected_outputs_hash, outputs_hash };
}


export async function compareSnapshots(taskId: string, snapshotAId: string, snapshotBId: string) {
  const col = db.collection("tasks").doc(taskId).collection("deterministic_snapshots");
  const a = await col.doc(snapshotAId).get();
  const b = await col.doc(snapshotBId).get();
  if (!a.exists) throw new Error("snapshotA_not_found");
  if (!b.exists) throw new Error("snapshotB_not_found");
  const A = a.data() as any;
  const B = b.data() as any;

  const sameInputs = String(A.inputs_hash || "") === String(B.inputs_hash || "");
  const sameOutputs = String(A.outputs_hash || "") === String(B.outputs_hash || "");
  const sameCanon = String(A.canon_hash || "") === String(B.canon_hash || "");

  return {
    ok: true,
    taskId,
    snapshotAId,
    snapshotBId,
    sameInputs,
    sameOutputs,
    sameCanon,
    A: { runId: A.runId, inputs_hash: A.inputs_hash, outputs_hash: A.outputs_hash, canon_hash: A.canon_hash, taskType: A.taskType, scopeName: A.scopeName },
    B: { runId: B.runId, inputs_hash: B.inputs_hash, outputs_hash: B.outputs_hash, canon_hash: B.canon_hash, taskType: B.taskType, scopeName: B.scopeName },
  };
}
