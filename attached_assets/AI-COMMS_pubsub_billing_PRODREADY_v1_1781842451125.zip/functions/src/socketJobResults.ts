/**
 * socketJobResults.ts
 *
 * Return-path wiring: store Brain job results back into AI-COMMS.
 *
 * Two modes:
 *  1) socketJobCompletedWebhook: Brain (Socket) POSTs { jobId, evidenceId } with shared secret.
 *  2) ownerSyncEvidenceJob: Owner can manually sync via bearer Firebase auth.
 */

import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import { logger } from "firebase-functions";
import { admin, db } from "./firebaseAdmin";
import { socketGet, socketGetRaw } from "./socketClient";
import { requireOwner } from "./ownerAuth";
import { logEvent } from "./lib/logEvent";

const SOCKET_WEBHOOK_SECRET = defineSecret("SOCKET_WEBHOOK_SECRET");

function safeId(v: any): string {
  return String(v || "").trim();
}

function findArtifactUrl(job: any): string | null {
  if (!job || typeof job !== "object") return null;
  const candidates = [
    job?.result?.artifactZipUrl,
    job?.result?.artifactsZipUrl,
    job?.result?.artifact_url,
    job?.result?.artifacts_url,
    job?.artifactZipUrl,
    job?.artifactsZipUrl,
    job?.artifacts_url,
    job?.artifact_url,
  ].filter(Boolean);
  for (const c of candidates) {
    const s = String(c);
    if (s.startsWith("http")) return s;
    if (s.startsWith("/")) return s;
  }
  return null;
}

async function pullAndStore(jobId: string, evidenceId: string) {
  // Pull job snapshot
  const job: any = await socketGet(`/jobs/${encodeURIComponent(jobId)}`);

  // Write snapshot + status into Firestore
  const deliverableRef = db.collection("deliverables").doc(evidenceId);
  await deliverableRef.set(
    {
      evidenceId,
      jobId,
      updatedAt: Date.now(),
      status: job?.status || job?.state || null,
      verdict: job?.verdict || job?.result?.verdict || null,
      guardrails: job?.guardrails || job?.result?.guardrails || null,
      socketJobSnapshot: job,
    },
    { merge: true }
  );
  // Attach org/project context if available
  let orgId: string | null = null;
  try {
    const pSnap = await db.collection("projects").doc(evidenceId).get();
    if (pSnap.exists) {
      const p = pSnap.data() as any;
      orgId = (p?.orgId || null) as string | null;
      await deliverableRef.set({ orgId, projectId: evidenceId }, { merge: true });
    }
  } catch {}


  // Attempt to pull artifact zip (best-effort)
  const artifactPathOrUrl = findArtifactUrl(job);
  let storedZipPath: string | null = null;

  const tryPaths = [
    artifactPathOrUrl,
    // Common Brain endpoints (best-effort)
    `/jobs/${encodeURIComponent(jobId)}/result`,
    `/jobs/${encodeURIComponent(jobId)}/artifacts.zip`,
    `/jobs/${encodeURIComponent(jobId)}/artifact.zip`,
  ].filter(Boolean) as string[];

  for (const candidate of tryPaths) {
    try {
      // If Brain returned absolute URL, fetch it directly
      if (candidate.startsWith("http")) {
        const res = await fetch(candidate);
        if (!res.ok) throw new Error(`artifact url fetch failed: ${res.status}`);
        const ab = await res.arrayBuffer();
        const bytes = Buffer.from(ab);
        const bucket = admin.storage().bucket();
        storedZipPath = `deliverables/${evidenceId}/${jobId}/artifacts.zip`;
        await bucket.file(storedZipPath).save(bytes, {
          contentType: res.headers.get("content-type") || "application/zip",
          resumable: false,
        });
        break;
      }

      // Otherwise treat as Brain relative path
      const { bytes, contentType } = await socketGetRaw(candidate);
      // Heuristic: if it looks like JSON, skip (we’re looking for zip)
      const ct = (contentType || "").toLowerCase();
      if (ct.includes("application/json")) continue;

      const bucket = admin.storage().bucket();
      storedZipPath = `deliverables/${evidenceId}/${jobId}/artifacts.zip`;
      await bucket.file(storedZipPath).save(bytes, {
        contentType: contentType || "application/zip",
        resumable: false,
      });
      break;
    } catch (e: any) {
      logger.warn("artifact pull failed", { candidate, jobId, evidenceId, error: String(e?.message || e) });
    }
  }

  if (storedZipPath) {
    await deliverableRef.set(
      {
        artifactZipStoragePath: storedZipPath,
        artifactZipUpdatedAt: Date.now(),
      },
      { merge: true }
    );
  }


  // If we stored artifacts, mark project delivered and create a case study draft (anonymized stub).
  if (storedZipPath) {
    try {
      const deliverablesUrl = await admin.storage().bucket().file(storedZipPath).getSignedUrl({
        action: "read",
        expires: Date.now() + 1000 * 60 * 60 * 24 * 7, // 7 days
      }).then(v => v[0]);

      await deliverableRef.set(
        { deliverablesUrl, deliveredAt: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );

      // Update project lifecycle if exists
      const pRef = db.collection("projects").doc(evidenceId);
      await pRef.set(
        { status: "delivered", updatedAt: admin.firestore.FieldValue.serverTimestamp(), deliverablesUrl },
        { merge: true }
      );

      // Case study draft (safe placeholder; owner edits before publish)
      const csId = `${evidenceId}_${jobId}`;
      await db.collection("caseStudies").doc(csId).set(
        {
          orgId: orgId || null,
          projectId: evidenceId,
          jobId,
          status: "draft",
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          summary: {
            headline: "Automation governance deliverable completed",
            notes: [
              "Replace this draft with an anonymized case study summary before publishing.",
              "Include: problem → approach → outcome → timeline."
            ],
          },
        },
        { merge: true }
      );
    } catch (e) {
      logger.warn("post-store updates failed", { jobId, evidenceId, error: String((e as any)?.message || e) });
    }
  }

  return { job, storedZipPath };
}

export const socketJobCompletedWebhook = onRequest(
  { region: "us-central1", secrets: [SOCKET_WEBHOOK_SECRET] },
  async (req, res) => {
    if (req.method !== "POST") return res.status(405).send("Method not allowed");

    const got = String(req.headers["x-socket-webhook-secret"] || "").trim();
    const expected = String(SOCKET_WEBHOOK_SECRET.value() || "").trim();
    if (!expected) return res.status(500).json({ ok: false, error: "socket_webhook_secret_missing" });
    if (!got || got !== expected) return res.status(403).json({ ok: false, error: "forbidden" });

    const jobId = safeId(req.body?.jobId);
    const evidenceId = safeId(req.body?.evidenceId);
    if (!jobId || !evidenceId) return res.status(400).json({ ok: false, error: "missing_jobId_or_evidenceId" });

    try {
      const out = await pullAndStore(jobId, evidenceId);
      await logEvent("socket_job_webhook_ingested", "INFO", "Socket job webhook ingested", { jobId, evidenceId });
      return res.status(200).json({ ok: true, evidenceId, jobId, artifactZipStoragePath: out.storedZipPath || null });
    } catch (e: any) {
      await logEvent("socket_job_webhook_failed", "WARN", "Socket job webhook failed", { jobId, evidenceId, error: String(e?.message || e) });
      return res.status(500).json({ ok: false, error: String(e?.message || e) });
    }
  }
);

// Owner-only manual sync (useful if Brain webhook isn’t wired yet)
export const ownerSyncEvidenceJob = onRequest({ region: "us-central1" }, async (req, res) => {
  const owner = await requireOwner(req);
  if (!owner.ok) return res.status(owner.status).json({ ok: false, error: owner.message });
  if (req.method !== "POST") return res.status(405).send("Method not allowed");

  const jobId = safeId(req.body?.jobId);
  const evidenceId = safeId(req.body?.evidenceId);
  if (!jobId || !evidenceId) return res.status(400).json({ ok: false, error: "missing_jobId_or_evidenceId" });

  try {
    const out = await pullAndStore(jobId, evidenceId);
    await logEvent("socket_job_owner_sync", "INFO", "Owner synced Socket job", { jobId, evidenceId, uid: owner.uid });
    return res.status(200).json({ ok: true, evidenceId, jobId, artifactZipStoragePath: out.storedZipPath || null });
  } catch (e: any) {
    await logEvent("socket_job_owner_sync_failed", "WARN", "Owner sync failed", { jobId, evidenceId, error: String(e?.message || e) });
    return res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
});
