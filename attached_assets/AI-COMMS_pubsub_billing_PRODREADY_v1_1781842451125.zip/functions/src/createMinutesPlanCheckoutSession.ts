import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { admin, db } from "./firebaseAdmin";
import { logProtectionEvent } from "./logProtectionEvent";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

// Stripe Price IDs (set as function config or secrets)
const PRICE_MINUTES_BASE_ID = defineSecret("PRICE_MINUTES_BASE_ID"); // $25/mo recurring
const PRICE_MINUTES_OVERAGE_ID = defineSecret("PRICE_MINUTES_OVERAGE_ID"); // metered per-minute

export const createMinutesPlanCheckoutSession = onCall(
  {
    enforceAppCheck: true,
    region: "us-central1",
    secrets: [STRIPE_SECRET_KEY, PUBLIC_SITE_BASE_URL, PRICE_MINUTES_BASE_ID, PRICE_MINUTES_OVERAGE_ID],
  },
  async (req) => {
    if (!req.auth?.uid) throw new HttpsError("unauthenticated", "Sign in required.");
    const uid = req.auth.uid;

    const acceptedTerms = Boolean((req.data || {}).acceptedTerms);
    if (!acceptedTerms) throw new HttpsError("failed-precondition", "Terms must be accepted.");

    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
    if (!baseUrl) throw new HttpsError("failed-precondition", "Missing PUBLIC_SITE_BASE_URL.");

    const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });

    // Create/reuse Stripe customer
    const userRef = db.collection("users").doc(uid);
    const snap = await userRef.get();
    const u = snap.exists ? (snap.data() as any) : {};
    let customerId = String(u.stripe_customer_id || "").trim();

    if (!customerId) {
      const customer = await stripe.customers.create({
        metadata: { userId: uid },
      });
      customerId = customer.id;
      await userRef.set(
        { stripe_customer_id: customerId, updated_at: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );
    }

    const successUrl = `${baseUrl}/checkout/success?plan=minutes`;
    const cancelUrl = `${baseUrl}/pricing?canceled=1`;

    // Checkout creates a subscription with:
    // - base recurring price ($25/mo)
    // - metered overage price (per minute)
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [
        { price: PRICE_MINUTES_BASE_ID.value(), quantity: 1 },
        { price: PRICE_MINUTES_OVERAGE_ID.value(), quantity: 1 },
      ],
      subscription_data: {
        metadata: { userId: uid, plan: "minutes_hybrid" },
      },
      allow_promotion_codes: true,
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: { userId: uid, plan: "minutes_hybrid" },
    });

    await logProtectionEvent({
      userId: uid,
      severity: "calm",
      type: "billing",
      message: "Minutes plan checkout created.",
      metadata: { sessionId: session.id },
    });

    return { url: session.url };
  }
);
