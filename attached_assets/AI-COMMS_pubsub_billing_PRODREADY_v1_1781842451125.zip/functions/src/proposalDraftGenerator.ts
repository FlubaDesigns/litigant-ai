import { admin, db } from "./firebaseAdmin";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
import OpenAI from "openai";
import { logger } from "firebase-functions";
import { assertCapability } from "./tierPolicy";
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");

function safeText(v: any, fb = "") {
  if (v === null || v === undefined) return fb;
  const s = String(v).trim();
  return s.length ? s : fb;
}

function clamp(s: string, max = 18000) {
  if (!s) return "";
  return s.length <= max ? s : s.slice(0, max) + "\n\n[TRUNCATED]";
}

export const generateProposalDraft = onDocumentUpdated(
  {
    document: "leads/{leadId}",
    secrets: [OPENAI_API_KEY],
    region: "us-central1",
  },
  async (event) => {
    const leadId = event.params.leadId as string;
    const before = event.data?.before?.data() as any;
    const after = event.data?.after?.data() as any;

    if (!before || !after) return;

    if (!(before.status !== "audit_completed" && after.status === "audit_completed")) return;

    // Tier gating
    const gate = assertCapability(after, "proposal_generate");
    if (!gate.ok) {
      logger.warn("Proposal generation blocked by tier.", { leadId, tier: gate.tier });
      await db.collection("leads").doc(leadId).set(
        { status: "tier_blocked_proposal", tier_effective: gate.tier, updated_at: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );
      return;
    }

    if (after.proposal_draft || after.status === "proposal_review" || after.status === "proposal_sent") {
      logger.info("Proposal already exists or already in proposal flow. Skipping.", { leadId });
      return;
    }

    const openai = new OpenAI({ apiKey: OPENAI_API_KEY.value() });

    const company = safeText(after.company, "Unknown");
    const email = safeText(after.email, "Unknown");
    const goal = safeText(after.ai_goal, "(not provided)");

    const auditFinal = safeText(after.audit_final);
    const auditFallback = safeText(after?.ai_audit?.final_draft);
    const auditSource = auditFinal || auditFallback || "(No audit text found)";

    const userPrompt = `
You are writing a client proposal for "Intuitive (Powered by AIComms)".

Use the audit content below to produce a proposal that is:
- professional
- not hype
- easy for a non-technical client
- clearly scoped

OUTPUT FORMAT (exact headings):

1) EXECUTIVE SUMMARY (5-7 lines)
2) WHAT WE FOUND (bullets)
3) WHAT WE WILL IMPLEMENT (bullets)
4) WHAT YOU GET (deliverables list)
5) TIMELINE (simple)
6) PRICING (recommended tier and price range)
7) NEXT STEP (one CTA line)

CLIENT:
- Company: ${company}
- Email: ${email}
- AI Goal: ${goal}

AUDIT CONTENT:
${auditSource}
`.trim();

    const resp = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.25,
      messages: [
        { role: "system", content: "You are a proposal writer for an AI governance consultancy. Be clear, scoped, and realistic." },
        { role: "user", content: userPrompt },
      ],
    });

    const proposalDraft = clamp(resp.choices?.[0]?.message?.content || "");

    await db.collection("leads").doc(leadId).set(
      {
        proposal_draft: proposalDraft,
        proposal_generated_at: admin.firestore.FieldValue.serverTimestamp(),
        proposal_meta: {
          generated_by: "gpt-4o-mini",
          source: auditFinal ? "audit_final" : (auditFallback ? "ai_audit.final_draft" : "none"),
        },
        status: "proposal_review",
        tier_effective: gate.tier,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    logger.info("Proposal draft generated.", { leadId, tier: gate.tier });
  }
);