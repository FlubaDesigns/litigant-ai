import { onSchedule } from "firebase-functions/v2/scheduler";
import { admin, db } from "./firebaseAdmin";
import { sendAlert } from "./alerting";

function scoreFromRollup(r: any) {
  const success = Number(r?.success_rate ?? 0);
  const steps = Number(r?.avg_steps ?? 0);
  const dur = Number(r?.avg_duration_ms ?? 0);
  const cost = Number(r?.avg_cost_usd ?? 0);
  return (success * 1000) - steps * 5 - (dur / 1000) - cost * 50;
}

/**
 * Auto-adjusts canary percent per seat based on current rollups.
 * Docs live at canary_seat_config/{role__taskType} with:
 * { role, taskType, incumbent, challenger, canary_percent, min_runs, margin, step }
 */
export const canarySeatAutoAdjust = onSchedule({ schedule: "every 60 minutes", region: "us-central1" }, async () => {
  const cfgSnap = await db.collection("canary_seat_config").get();
  const changes: any[] = [];

  for (const d of cfgSnap.docs) {
    const cfg = d.data() as any;
    const role = String(cfg.role || "");
    const taskType = String(cfg.taskType || "");
    const incumbent = String(cfg.incumbent || "");
    const challenger = String(cfg.challenger || "");
    let canary = Number(cfg.canary_percent ?? 0);
    const minRuns = Number(cfg.min_runs ?? 10);
    const margin = Number(cfg.margin ?? 15); // score margin
    const step = Number(cfg.step ?? 5);

    if (!role || !taskType || !incumbent || !challenger) continue;

    const baseQ = db.collection("provider_metrics_rollup").where("role","==",role).where("taskType","==",taskType);
    const rolls = await baseQ.get();

    const inc = rolls.docs.map(x=>x.data() as any).find(r => String(r.provider||"")===incumbent);
    const cha = rolls.docs.map(x=>x.data() as any).find(r => String(r.provider||"")===challenger);
    if (!inc || !cha) continue;

    const incRuns = Number(inc.runs_total || 0);
    const chaRuns = Number(cha.runs_total || 0);
    if (incRuns < minRuns || chaRuns < minRuns) continue;

    const incScore = scoreFromRollup(inc);
    const chaScore = scoreFromRollup(cha);

    let newCanary = canary;
    if (chaScore > incScore + margin) newCanary = Math.min(50, canary + step);
    if (chaScore < incScore - margin) newCanary = Math.max(0, canary - step);

    if (newCanary !== canary) {
      await d.ref.set({
        canary_percent: newCanary,
        last_adjusted_at: admin.firestore.FieldValue.serverTimestamp(),
        last_scores: { incumbent: incScore, challenger: chaScore },
      }, { merge: true });
      changes.push({ key: d.id, role, taskType, canary_from: canary, canary_to: newCanary, incScore, chaScore });
    }
  }

  if (changes.length) {
    await sendAlert("info", "Canary seat auto-adjustments", `Adjusted: ${changes.length}`, { changes });
  }
  return { ok: true, changes: changes.length };
});
