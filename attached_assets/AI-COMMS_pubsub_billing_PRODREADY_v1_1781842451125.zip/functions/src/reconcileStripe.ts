import { onSchedule } from "firebase-functions/v2/scheduler";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { db } from "./firebaseAdmin";
import { sendAlert } from "./alerting";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");

// Minimal reconciliation: checks active subscriptions and ensures lead/user tier docs are consistent.
// NOTE: This is a safety net. It does not replace webhook processing.
export const reconcileStripe = onSchedule(
  { schedule: "every day 03:15", region: "us-central1", secrets: [STRIPE_SECRET_KEY] },
  async () => {
    const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });

    // TODO: If you implement subscriptions, list subscriptions and reconcile Firestore entitlements here.
    // For now, we emit a heartbeat so you can confirm scheduler is running.
    await db.collection("system_events").add({
      type: "stripe_reconcile_heartbeat",
      created_at: new Date(),
    });

    await sendAlert("info", "Stripe reconcile heartbeat", "reconcileStripe ran successfully (heartbeat).");
  }
);
