import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as functions from "firebase-functions";
import { defineSecret } from "firebase-functions/params";
import { admin, db } from "./firebaseAdmin";
import { normalizeTaskType, TASK_TYPES } from "./taskTypes";

async function requireAdminUid(uid: string) {
  const snap = await db.collection("admins").doc(uid).get();
  if (!snap.exists) throw new HttpsError("permission-denied", "Admin required.");
}

export const setRoleRouting = onCall(
  { region: "us-central1", enforceAppCheck: true },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");
    await requireAdminUid(uid);

    const scope = String((req.data as any)?.scope || "global").toLowerCase(); // global | taskType
    const taskType = normalizeTaskType((req.data as any)?.taskType);
    const config = (req.data as any)?.config || {};

    if (scope === "tasktype") {
      await db
        .collection("runtime_config")
        .doc("role_routing_by_taskType")
        .collection("types")
        .doc(taskType)
        .set(config, { merge: true });
      return { ok: true, scope: "taskType", taskType };
    }

    await db.collection("runtime_config").doc("role_routing_global").set(config, { merge: true });
    return { ok: true, scope: "global" };
  }
);

export const getRoleRouting = onCall(
  { region: "us-central1", enforceAppCheck: true },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");
    await requireAdminUid(uid);

    const taskType = normalizeTaskType((req.data as any)?.taskType);
    const globalSnap = await db.collection("runtime_config").doc("role_routing_global").get();
    const typeSnap = await db
      .collection("runtime_config")
      .doc("role_routing_by_taskType")
      .collection("types")
      .doc(taskType)
      .get();

    return {
      ok: true,
      taskType,
      global: globalSnap.exists ? globalSnap.data() : {},
      byTaskType: typeSnap.exists ? typeSnap.data() : {},
      taskTypes: TASK_TYPES,
    };
  }
);

export const getProviderMetrics = onCall(
  { region: "us-central1", enforceAppCheck: true },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Login required.");
    await requireAdminUid(uid);

    const role = String((req.data as any)?.role || "").trim();
    const taskType = normalizeTaskType((req.data as any)?.taskType);
    const limit = Math.min(Math.max(Number((req.data as any)?.limit || 50), 1), 200);

    let q: FirebaseFirestore.Query = db.collection("provider_metrics_rollup");
    if (role) q = q.where("role", "==", role);
    q = q.where("taskType", "==", taskType).orderBy("success_rate", "desc").limit(limit);

    const snap = await q.get();
    return { ok: true, role, taskType, rows: snap.docs.map((d) => ({ id: d.id, ...d.data() })) };
  }
);

// Heartbeat endpoint for providers (no AppCheck; requires shared key)
export const providerHeartbeat = functions.runWith({ secrets: [PROVIDER_HEARTBEAT_KEY] }).https.onRequest(async (req, res) => {
  try {
    const key = String(PROVIDER_HEARTBEAT_KEY.value() || "");
    const provided = String(req.headers["x-provider-key"] || "");
    if (!key || provided !== key) {
      res.status(401).json({ ok: false, message: "unauthorized" });
      return;
    }

    const providerId = String(req.body?.providerId || req.query?.providerId || "").trim();
    if (!providerId) {
      res.status(400).json({ ok: false, message: "missing providerId" });
      return;
    }

    const status = String(req.body?.status || "online").toLowerCase();

    // Basic rate limit: 60 heartbeats/hour/provider + IP minute bucket
    const ip = String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown").split(",")[0].trim();
    const now = new Date();
    const hourBucket = `${now.getUTCFullYear()}${String(now.getUTCMonth()+1).padStart(2,"0")}${String(now.getUTCDate()).padStart(2,"0")}${String(now.getUTCHours()).padStart(2,"0")}`;
    const minuteBucket = `${hourBucket}${String(now.getUTCMinutes()).padStart(2,"0")}`;
    const rlDoc = `hb__${providerId}__${hourBucket}`;
    const rlMinDoc = `hbip__${providerId}__${ip}__${minuteBucket}`;
    await db.runTransaction(async (tx) => {
      const refH = db.collection("provider_rate_limits").doc(rlDoc);
      const refM = db.collection("provider_rate_limits").doc(rlMinDoc);
      const h = await tx.get(refH);
      const m = await tx.get(refM);
      const hCount = Number((h.exists ? (h.data() as any)?.count : 0) || 0) + 1;
      const mCount = Number((m.exists ? (m.data() as any)?.count : 0) || 0) + 1;
      if (hCount > 60) throw new Error("rate_limited_hour");
      if (mCount > 5) throw new Error("rate_limited_minute");
      tx.set(refH, { kind: "heartbeat_hour", providerId, hourBucket, count: hCount, updated_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      tx.set(refM, { kind: "heartbeat_minute", providerId, ip, minuteBucket, count: mCount, updated_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    });
    await db.collection("provider_registry").doc(providerId).set(
      {
        providerId,
        status,
        capabilities: req.body?.capabilities ?? null,
        roles_supported: req.body?.roles_supported ?? null,
        latency_p50_ms: req.body?.latency_p50_ms ?? null,
        latency_p95_ms: req.body?.latency_p95_ms ?? null,
        error_rate_1h: req.body?.error_rate_1h ?? null,
        success_rate_1h: req.body?.success_rate_1h ?? null,
        cost_per_1k_tokens_est: req.body?.cost_per_1k_tokens_est ?? null,
        last_heartbeat: admin.firestore.FieldValue.serverTimestamp(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ ok: false, message: e?.message || "error" });
  }
});

// Admin: set canary routing config
export const setCanaryConfig = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const canary_percent = Number(req.body?.canary_percent ?? 0);
    await db.collection("runtime_config").doc("canary_routing").set({
      canary_percent,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    res.json({ ok: true, canary_percent });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: set simulation mode
export const setSimulationMode = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const mode = String(req.body?.mode || "REAL").toUpperCase();
    await db.collection("runtime_config").doc("execution").set({
      EXECUTION_MODE: mode,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    res.json({ ok: true, mode });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: unfreeze circuit breaker for role/taskType
export const unfreezeBreaker = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const key = String(req.body?.key || "").trim();
    if (!key) { res.status(400).json({ ok: false, error: "missing_key" }); return; }

    await db.collection("circuit_breakers").doc(key).set({
      isFrozen: false,
      unfrozen_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    res.json({ ok: true, key });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: replay a task run (re-run runTaskCore from stored task doc)
export const replayTask = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const taskId = String(req.body?.taskId || "").trim();
    if (!taskId) { res.status(400).json({ ok: false, error: "missing_taskId" }); return; }
    // Task execution moved to AI Socket. This endpoint is deprecated.
    res.status(410).json({ ok: false, error: "deprecated_moved_to_socket" });
});

// Admin: seat leaderboard for role+taskType (best providers by success/steps/duration/cost)
export const getSeatLeaderboard = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const role = String(req.body?.role || "").trim();
    const taskType = String(req.body?.taskType || "").trim();
    const metric = String(req.body?.metric || "score").trim();

    if (!role || !taskType) { res.status(400).json({ ok: false, error: "missing_role_or_taskType" }); return; }

    const snap = await db.collection("provider_metrics_rollup")
      .where("role", "==", role)
      .where("taskType", "==", taskType)
      .get();

    const rows = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) }));
    // compute score same as router
    const ranked = rows.map(r => {
      const success = Number(r.success_rate ?? 0);
      const steps = Number(r.avg_steps ?? 0);
      const dur = Number(r.avg_duration_ms ?? 0);
      const cost = Number(r.avg_cost_usd ?? 0);
      const score = (success * 1000) - steps * 5 - (dur / 1000) - cost * 50;
      return { ...r, score };
    }).sort((a,b) => (b.score - a.score));

    res.json({ ok: true, role, taskType, ranked });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: compare two deterministic snapshots for a task
export const compareDeterministicSnapshots = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const taskId = String(req.body?.taskId || "").trim();
    const snapshotAId = String(req.body?.snapshotAId || "").trim();
    const snapshotBId = String(req.body?.snapshotBId || "").trim();
    if (!taskId || !snapshotAId || !snapshotBId) {
      res.status(400).json({ ok: false, error: "missing_taskId_or_snapshotIds" }); return;
    }

    const { compareSnapshots } = await import("./deterministicSnapshots");
    const result = await compareSnapshots(taskId, snapshotAId, snapshotBId);
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: set anomaly detector thresholds
export const setAnomalyThresholds = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const MIN_SUCCESS = Number(req.body?.MIN_SUCCESS ?? 0.6);
    const MAX_STEPS = Number(req.body?.MAX_STEPS ?? 150);
    const MAX_DUR_MS = Number(req.body?.MAX_DUR_MS ?? 240000);
    const MAX_COST = Number(req.body?.MAX_COST ?? 2.0);

    await db.collection("runtime_config").doc("anomaly_thresholds").set({
      MIN_SUCCESS, MAX_STEPS, MAX_DUR_MS, MAX_COST,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    res.json({ ok: true, MIN_SUCCESS, MAX_STEPS, MAX_DUR_MS, MAX_COST });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Admin: set per-seat canary config
export const setSeatCanaryConfig = functions.https.onRequest(async (req, res) => {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) { res.status(auth.status).json({ ok: false, message: auth.message }); return; }

    const role = String(req.body?.role || "").trim();
    const taskType = String(req.body?.taskType || "").trim();
    const incumbent = String(req.body?.incumbent || "").trim();
    const challenger = String(req.body?.challenger || "").trim();
    const canary_percent = Number(req.body?.canary_percent ?? 5);
    const min_runs = Number(req.body?.min_runs ?? 10);
    const margin = Number(req.body?.margin ?? 15);
    const step = Number(req.body?.step ?? 5);

    if (!role || !taskType || !incumbent || !challenger) {
      res.status(400).json({ ok: false, error: "missing_fields" }); return;
    }

    const key = `${role}__${taskType}`;
    await db.collection("canary_seat_config").doc(key).set({
      role, taskType, incumbent, challenger, canary_percent, min_runs, margin, step,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    res.json({ ok: true, key, role, taskType, canary_percent });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});
