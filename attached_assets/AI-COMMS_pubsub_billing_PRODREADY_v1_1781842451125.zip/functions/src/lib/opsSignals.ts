import { admin, db } from "../firebaseAdmin";

export type OpsSignalKind =
  | "stripe_webhook_verified"
  | "stripe_webhook_sig_fail"
  | "stripe_webhook_processed_ok"
  | "stripe_webhook_processed_fail"
  | "email_send_ok"
  | "email_send_fail"
  | "email_queue_heartbeat"
  | "email_queue_backlog"
  | "function_error"
  | "firestore_permission_denied";

export type OpsSignal = {
  kind: OpsSignalKind | string;
  ok: boolean;
  count: number;
  message?: string;
  requestId?: string;
  meta?: Record<string, any>;
  created_at?: FirebaseFirestore.FieldValue;
};

/**
 * recordOpsSignal
 * Lightweight, safe telemetry into Firestore so Admin can render dashboards
 * without relying on external log tooling.
 *
 * Rules:
 * - Never include secrets in meta.
 * - Keep meta small.
 */
export async function recordOpsSignal(kind: OpsSignalKind | string, ok: boolean, count: number = 1, meta: Record<string, any> = {}, message: string = "", requestId: string = "") {
  const doc = {
    kind,
    ok: !!ok,
    count: Number(count || 1),
    message: message || "",
    requestId: requestId || "",
    meta: meta || {},
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  };

  await db.collection("ops_signals").add(doc);

  // Hourly rollup for cheap dashboards: ops_signal_rollups/{YYYYMMDDHH}
  const d = new Date();
  const bucket = `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,"0")}${String(d.getUTCDate()).padStart(2,"0")}${String(d.getUTCHours()).padStart(2,"0")}`;
  const ref = db.collection("ops_signal_rollups").doc(bucket);

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const cur = snap.exists ? (snap.data() as any) : {};
    const byKind = (cur.byKind || {}) as Record<string, any>;

    const k = String(kind);
    const prev = byKind[k] || { ok: 0, fail: 0, total: 0 };
    const incOk = ok ? Number(count || 1) : 0;
    const incFail = ok ? 0 : Number(count || 1);

    byKind[k] = {
      ok: Number(prev.ok || 0) + incOk,
      fail: Number(prev.fail || 0) + incFail,
      total: Number(prev.total || 0) + Number(count || 1),
    };

    tx.set(ref, {
      bucket,
      byKind,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });
  });
}
