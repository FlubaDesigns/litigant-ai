export type RiskBand = "LOW" | "MEDIUM" | "HIGH";

export type RiskScanScore = {
  score: number;
  band: RiskBand;
  findings: string[];
  recommended_next: string[]; // ordered action list
};

function uniqSorted(xs: string[]) {
  return Array.from(new Set(xs)).sort();
}

export function scoreRiskScan(payload: any): RiskScanScore {
  const answers: string[] = Array.isArray(payload?.answers)
    ? payload.answers.map((x: any) => String(x ?? "").trim())
    : Object.keys(payload || {})
        .filter((k) => /^q\d+$/i.test(k))
        .sort((a, b) => Number(a.slice(1)) - Number(b.slice(1)))
        .map((k) => String(payload[k] ?? "").trim());

  let score = 0;
  const findings: string[] = [];

  // Deterministic, explainable heuristics (server-side only)
  for (const raw of answers) {
    const s = raw.toLowerCase();
    if (!s) continue;

    if (s.includes("no")) score += 2;
    if (s.includes("maybe")) score += 5;
    if (s.includes("unknown")) score += 8;

    if (s.includes("breach") || s.includes("incident")) {
      score += 18;
      findings.push("Prior breach/incident mentioned.");
    }
    if (s.includes("no mfa") || s.includes("without mfa") || s.includes("no 2fa") || s.includes("no 2-factor")) {
      score += 14;
      findings.push("MFA/2FA appears missing for at least one system.");
    }
    if (s.includes("public") && s.includes("write")) {
      score += 20;
      findings.push("Public write access indicated on a data path.");
    }
    if (s.includes("test rules") || s.includes("allow read, write")) {
      score += 20;
      findings.push("Permissive test rules indicated (allow read/write).");
    }
  }

  if (score > 100) score = 100;

  const band: RiskBand = score >= 70 ? "HIGH" : score >= 35 ? "MEDIUM" : "LOW";

  const recommended_next =
    band === "HIGH"
      ? ["book_call", "purchase_audit", "lockdown_rules", "enable_app_check"]
      : band === "MEDIUM"
      ? ["purchase_audit", "tighten_rules", "enable_app_check"]
      : ["self_checklist", "tighten_rules_optional"];

  return { score, band, findings: uniqSorted(findings), recommended_next };
}
