import { admin, db } from "../firebaseAdmin";

export async function bumpDailyIpCounter(ip: string, limit: number) {
  const day = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const id = `${day}__${ip}`;
  const ref = db.collection("ip_daily_counters").doc(id);

  const count = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const current = Number((snap.exists ? (snap.data() as any)?.count : 0) || 0);
    const next = current + 1;
    tx.set(
      ref,
      { day, ip, count: next, updated_at: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );
    return next;
  });

  return { count, limited: count > limit, limit };
}
