import { admin, db } from "../firebaseAdmin";

export type EventSeverity = "DEBUG" | "INFO" | "WARN" | "ERROR" | "CRITICAL";

export async function logEvent(
  kind: string,
  severity: EventSeverity,
  message: string,
  meta: Record<string, any> = {}
) {
  // Never write secrets in meta.
  await db.collection("system_events").add({
    kind,
    severity,
    message,
    meta,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });
}
