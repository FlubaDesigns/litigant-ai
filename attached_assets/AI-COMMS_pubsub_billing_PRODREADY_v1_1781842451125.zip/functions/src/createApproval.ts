import { admin, db } from "./firebaseAdmin";
import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import { logEvent } from "./lib/logEvent";

const SOCKET_APPROVAL_SHARED_SECRET = defineSecret("SOCKET_APPROVAL_SHARED_SECRET");

/**
 * createApproval
 * Secure endpoint intended for Brain/Socket (or other server-side agents) to request a human approval.
 *
 * Auth: Bearer token via SOCKET_APPROVAL_SHARED_SECRET (not user auth).
 * This avoids requiring Firebase Auth for the Brain layer, while keeping access locked.
 */
export const createApproval = onRequest(
  { region: "us-central1", secrets: [SOCKET_APPROVAL_SHARED_SECRET] },
  async (req, res) => {
    if (req.method !== "POST") return res.status(405).send("Method not allowed");

    const auth = String(req.headers["authorization"] || "");
    const expected = SOCKET_APPROVAL_SHARED_SECRET.value();
    const ok = auth.startsWith("Bearer ") && auth.slice(7).trim() === expected;
    if (!ok) return res.status(401).send("Unauthorized");

    const orgId = String((req.body || {}).orgId || "").trim();
    const ownerUid = String((req.body || {}).ownerUid || "").trim();
    const jobId = String((req.body || {}).jobId || "").trim();
    const actionSummary = String((req.body || {}).actionSummary || "").trim();
    const policyTrigger = String((req.body || {}).policyTrigger || "").trim();
    const expiresInMinutes = Number((req.body || {}).expiresInMinutes || 0);
    const resumePayload = (req.body || {}).resumePayload || null; // optional payload to resume job if approved

    if (!orgId) return res.status(400).send("Missing orgId");
    if (!ownerUid) return res.status(400).send("Missing ownerUid");
    if (!actionSummary) return res.status(400).send("Missing actionSummary");

    const approvalRef = db.collection("approvals").doc();
    const now = admin.firestore.Timestamp.now();
    const expires_at = expiresInMinutes > 0
      ? admin.firestore.Timestamp.fromMillis(now.toMillis() + expiresInMinutes * 60 * 1000)
      : null;

    await approvalRef.set({
      org_id: orgId,
      owner_uid: ownerUid,
      status: "pending",
      requested_by: "brain",
      job_id: jobId || "",
      action_summary: actionSummary,
      policy_trigger: policyTrigger || "",
      resume_payload: resumePayload || null,
      resume_on_approve: !!resumePayload,
      created_at: admin.firestore.FieldValue.serverTimestamp(),
      expires_at: expires_at || admin.firestore.FieldValue.delete(),
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: false });

    await logEvent("approval_created", { approvalId: approvalRef.id, orgId, jobId }, { uid: "system" });

    return res.status(200).json({ ok: true, approvalId: approvalRef.id });
  }
);
