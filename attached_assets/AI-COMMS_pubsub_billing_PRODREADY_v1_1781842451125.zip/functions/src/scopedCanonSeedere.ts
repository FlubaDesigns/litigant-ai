import { admin, db } from "./firebaseAdmin";
/**
 * Seed scoped canon JSON into Firestore:
 *   scoped_canon/{scopeName} { json: <object>, updated_at }
 *
 * You run this ONCE locally (or via an admin-only callable you can add later),
 * because Cloud Functions runtime cannot read your repo filesystem.
 */
export async function seedScopedCanon(scopeName: string, json: any) {
  if (admin.apps.length === 0)     await db.collection("scoped_canon").doc(scopeName).set({
    json,
    updated_at: admin.firestore.Timestamp.now(),
    version: json?.meta?.version || 0,
    pack_name: json?.meta?.pack_name || null,
  }, { merge: true });
}