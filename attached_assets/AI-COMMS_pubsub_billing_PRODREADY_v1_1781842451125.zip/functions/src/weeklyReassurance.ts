
import * as admin from "firebase-admin";
import * as functions from "firebase-functions";
import { weeklyReassuranceEmail } from "./emailTemplates";
import { enqueueEmail } from "./emailQueue";
import { logProtectionEvent } from "./logProtectionEvent";

export const weeklyReassurance = functions.pubsub
  .schedule("every sunday 09:00")
  .timeZone("UTC")
  .onRun(async () => {
    const users = await admin.firestore().collection("users").get();

    for (const doc of users.docs) {
      const data = doc.data();
      if (data.email) {
        const template = weeklyReassuranceEmail();
        await enqueueEmail({
          to: data.email,
          subject: template.subject,
          html: template.html,
        });

        await logProtectionEvent({
          userId: doc.id,
          severity: "calm",
          type: "system",
          message: "Weekly protection scan completed. No critical risks detected.",
          metadata: { source: "weeklyReassurance" },
        });
      }
    }

    console.log("Weekly reassurance emails queued.");
  });
