import { Tier } from "./tierPolicy";

export function purchaseSubject(tier: Tier): string {
  if (tier === "explorer") return "Your AI‑COMMS Governance Credit is active";
  if (tier === "pro") return "Welcome to AI‑COMMS Pro";
  if (tier === "enterprise") return "Welcome to AI‑COMMS Enterprise";
  return "Your AI‑COMMS purchase is confirmed";
}

export function purchaseHtml(args: {
  tier: Tier;
  portalUrl: string;
  creditsGranted?: number;
}): string {
  const { tier, portalUrl, creditsGranted } = args;

  const tierLabel =
    tier === "explorer" ? "Governance Credit" :
    tier === "pro" ? "Pro" :
    tier === "enterprise" ? "Enterprise" :
    "Audit";

  const creditLine =
    tier === "explorer"
      ? `<p><strong>Credits:</strong> ${creditsGranted ?? 25} governance credits have been added to your account. They never expire and can be applied toward upgrades.</p>`
      : "";

  return `
  <div style="font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; line-height:1.5">
    <h2 style="margin:0 0 8px 0;">Payment confirmed</h2>
    <p style="margin:0 0 12px 0;">Thanks — your <strong>${tierLabel}</strong> access is now active.</p>
    ${creditLine}
    <p style="margin:16px 0 8px 0;">
      <a href="${portalUrl}" style="display:inline-block;padding:10px 14px;border-radius:10px;background:#1e3a8a;color:white;text-decoration:none;">
        ${tier === "explorer" ? "Open your AI‑COMMS dashboard" : "Open your AI‑COMMS client portal"}
      </a>
    </p>
    <p style="opacity:0.8;margin:12px 0 0 0;">If you didn’t make this purchase, reply to this email immediately.</p>
  </div>
  `;
}


export function creditNudgeSubject(stage: number): string {
  if (stage <= 0) return "You still have unused AI‑COMMS governance credit";
  if (stage === 1) return "Reminder: your AI‑COMMS credit never expires";
  return "Last reminder: use your AI‑COMMS governance credit any time";
}

export function creditNudgeHtml(args: { stage: number; credits: number; dashboardUrl: string }): string {
  const { stage, credits, dashboardUrl } = args;
  const headline =
    stage <= 0 ? "You have unused governance credit" : stage === 1 ? "Your credit is still waiting" : "Final reminder";

  return `
  <div style="font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; line-height:1.5">
    <h2 style="margin:0 0 8px 0;">${headline}</h2>
    <p style="margin:0 0 12px 0;">
      You currently have <strong>$${Math.max(0, Number(credits || 0))}</strong> in AI‑COMMS governance credit available.
      It never expires.
    </p>
    <p style="margin:16px 0 8px 0;">
      <a href="${dashboardUrl}" style="display:inline-block;padding:10px 14px;border-radius:10px;background:#1e3a8a;color:white;text-decoration:none;">
        Open dashboard and use credit
      </a>
    </p>
    <p style="opacity:0.8;margin:12px 0 0 0;">
      If you no longer want reminders, reply to this email with “stop”.
    </p>
  </div>
  `;
}


export function buildDeliverableReadyEmail(args: { projectId: string; deliverablesUrl: string; verdict: string }) {
  const { projectId, deliverablesUrl, verdict } = args;
  const subject = `Your AI‑COMMS deliverables are ready (${verdict})`;
  const text = `Your AI‑COMMS deliverables are ready.\n\nProject: ${projectId}\nVerdict: ${verdict}\nDownload: ${deliverablesUrl}\n`;
  const html = `
  <div style="font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; line-height:1.5">
    <h2 style="margin:0 0 8px 0;">Deliverables ready</h2>
    <p style="margin:0 0 12px 0;">Your packet has completed validation and your deliverables are ready to download.</p>
    <p style="margin:0 0 12px 0;"><strong>Verdict:</strong> ${verdict}</p>
    <p style="margin:16px 0 8px 0;">
      <a href="${deliverablesUrl}" style="display:inline-block;padding:10px 14px;border-radius:10px;background:#1e3a8a;color:white;text-decoration:none;">
        Download deliverables
      </a>
    </p>
    <p style="opacity:0.8;margin:12px 0 0 0;">Project ID: ${projectId}</p>
  </div>`;
  return { subject, html, text };
}
