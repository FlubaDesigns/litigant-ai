import { admin, db } from "./firebaseAdmin";

export type TraceEvent = {
  taskId: string;
  runId: string;
  scopeName: string;
  taskType?: string;
  role?: string;
  provider?: string;
  state?: string;
  level: "info" | "warn" | "error";
  code?: string;
  message: string;
  data?: any;
  createdAt?: FirebaseFirestore.Timestamp;
};

export function newRunId() {
  return `run_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

export async function trace(ev: TraceEvent): Promise<void> {
  const doc = {
    ...ev,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  };
  // per-task trace stream
  await db.collection("tasks").doc(ev.taskId).collection("trace_events").add(doc);
  // global stream for dashboards
  await db.collection("trace_events").add(doc);
}

export async function setTaskRun(taskId: string, runId: string) {
  await db.collection("tasks").doc(taskId).set({ active_run_id: runId, last_run_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
}
