import { onCall, HttpsError } from "firebase-functions/v2/https";
import { db } from "./firebaseAdmin";
import { defineSecret } from "firebase-functions/params";
import { logEvent } from "./lib/logEvent";
import { bumpDailyIpCounter } from "./lib/rateLimit";
import { socketPost, ensureSocketCompatible } from "./socketClient";

// Optional: notify admin later (kept as secret placeholder, but not required to run)
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

function normalizeEmail(v: any) {
  return String(v || "").trim().toLowerCase();
}

function getClientIp(req: any) {
  const raw = String(req?.rawRequest?.ip || req?.rawRequest?.headers?.["x-forwarded-for"] || "unknown");
  return raw.split(",")[0].trim() || "unknown";
}

function requireString(field: string, v: any, maxLen = 2000) {
  const s = String(v ?? "").trim();
  if (!s) throw new HttpsError("invalid-argument", `${field} is required.`);
  if (s.length > maxLen) throw new HttpsError("invalid-argument", `${field} is too long.`);
  return s;
}

function sanitizeGovernanceProfile(raw: any) {
  if (!raw || typeof raw !== "object") return null;
  const tier = String(raw.tier || "").trim();
  const autonomyLevel = Number(raw.autonomyLevel);
  const loggingDepth = String(raw.loggingDepth || "").trim();
  const patchMode = String(raw.patchMode || "").trim();
  const escalationSla = String(raw.escalationSla || "").trim();

  const allowedTier = ["SMB", "MID_MARKET", "REGULATED"].includes(tier);
  const allowedLogging = ["basic", "extended", "immutable"].includes(loggingDepth);
  const allowedPatch = ["proposal_only", "approval_required", "restricted_auto_minor"].includes(patchMode);
  const allowedSla = ["24h", "4h", "1h"].includes(escalationSla);
  const allowedAutonomy = Number.isFinite(autonomyLevel) && autonomyLevel >= 0 && autonomyLevel <= 4;
  if (!allowedTier || !allowedLogging || !allowedPatch || !allowedSla || !allowedAutonomy) return null;

  const reasons = Array.isArray(raw.reasons) ? raw.reasons.map((r: any) => String(r).slice(0, 200)) : [];
  return { tier, autonomyLevel, loggingDepth, patchMode, escalationSla, reasons };
}

export const submitEvidencePack = onCall(
  { region: "us-central1", enforceAppCheck: true, secrets: [AICOMMS_ADMIN_EMAIL] },
  async (req) => {
    const ip = getClientIp(req);

    // Light abuse control
    const { limited, count, limit } = await bumpDailyIpCounter(ip, 120);
    if (limited) {
      await logEvent("evidence_intake_rate_limited", "WARN", "Evidence intake blocked by rate limit", { ip, count, limit });
      throw new HttpsError("resource-exhausted", "Rate limit exceeded.");
    }

    const email = normalizeEmail(requireString("email", req.data?.email, 254));
    if (!email.includes("@")) throw new HttpsError("invalid-argument", "Valid email required.");

    
    const uid = req.auth?.uid || null;
    let orgId: string | null = null;
    if (uid) {
      try {
        const uSnap = await db.collection("users").doc(uid).get();
        orgId = (uSnap.exists ? (uSnap.data() as any)?.orgId : null) || null;
      } catch {}
    }
const leadIdRaw = String(req.data?.leadId || "").trim();
    const leadId = leadIdRaw || null;

    // Governance profile passed from AI-COMMS website layer. This is the enforceable constraint envelope.
    const governanceProfile = sanitizeGovernanceProfile(req.data?.governance_profile || req.data?.governanceProfile);

    const payload = {
      orgId,
      uid,

      leadId,
      email_norm: email,
      projectName: requireString("projectName", req.data?.projectName, 200),
      repoUrl: String(req.data?.repoUrl || "").trim(),
      stack: String(req.data?.stack || "").trim(),
      envs: String(req.data?.envs || "").trim(),
      deployMode: String(req.data?.deployMode || "ci_cd"),
      deployProvider: String(req.data?.deployProvider || "").trim(),
      sensitivePaths: String(req.data?.sensitivePaths || "").trim(),
      neverTouchPaths: String(req.data?.neverTouchPaths || "").trim(),
      riskTolerance: String(req.data?.riskTolerance || "balanced"),
      unknownPolicy: String(req.data?.unknownPolicy || "escalate"),
      autonomyPref: String(req.data?.autonomyPref || "guided"),
      ownerName: String(req.data?.ownerName || "").trim(),
      approverEmails: String(req.data?.approverEmails || "").trim(),
      notes: String(req.data?.notes || "").trim(),
      plan: String(req.data?.plan || "").trim(),
      packageMode: String(req.data?.packageMode || "dfy").trim().toLowerCase(),
      governanceProfile,
      source: String(req.data?.source || "evidence_intake"),
      createdAt: Date.now(),
      ip,
    };

    // Store under evidence_packs; if leadId known, also back-link on lead.
    const docRef = db.collection("evidence_packs").doc();
    await docRef.set(payload);

    // Create scalable SaaS lifecycle shells (project/packet/job) keyed by evidenceId
    const projectId = docRef.id;
    if (orgId) {
      const nowMs = Date.now();
      await db.collection("projects").doc(projectId).set(
        {
          orgId,
          projectId,
          type: payload.plan || "audit",
          status: payload.packageMode === "diy" ? "awaiting_customer" : "awaiting_intake",
          governanceProfile,
          createdAt: nowMs,
          updatedAt: nowMs,
          sourceEvidenceId: projectId,
        },
        { merge: true }
      );

      await db.collection("packets").doc(projectId).set(
        {
          orgId,
          projectId,
          version: 1,
          status: "submitted",
          governanceProfile,
          createdAt: nowMs,
          updatedAt: nowMs,
        },
        { merge: true }
      );

      await db.collection("jobs").doc(projectId).set(
        {
          orgId,
          projectId,
          status: "queued",
          governanceProfile,
          createdAt: nowMs,
          updatedAt: nowMs,
        },
        { merge: true }
      );
    }

    // Persist governance profile as a locked artifact keyed by projectId.
    if (governanceProfile) {
      await db
        .collection("governance_profiles")
        .doc(projectId)
        .set(
          {
            kind: "project",
            projectId,
            orgId,
            leadId,
            email_norm: email,
            profile: governanceProfile,
            version: 1,
            lockedAt: Date.now(),
            lockedByUid: uid,
            source: String(payload.source || "evidence_intake"),
            updatedAt: Date.now(),
            createdAt: Date.now(),
          },
          { merge: true }
        );
    }

    if (leadId) {
      await db.collection("leads").doc(leadId).set(
        { latestEvidenceId: docRef.id, latestEvidenceAt: Date.now() },
        { merge: true }
      );
    }

    await logEvent("evidence_pack_submitted", "INFO", "Evidence pack submitted", { evidenceId: docRef.id, leadId, email });

    // Optional: automatically create a Socket (Brain) job from this intake.
    // This keeps all Brain auth (token/signing) on the server side.
    // Enable by setting env SOCKET_AUTORUN_EVIDENCE=true and providing SOCKET_BASE_URL + SOCKET_API_TOKEN (or KEY).
    let socketJob: any = null;
    const autorun = String(process.env.SOCKET_AUTORUN_EVIDENCE || "").toLowerCase() === "true";
    const packageMode = String(payload.packageMode || "dfy");
    const repoUrl = String(payload.repoUrl || "").trim();
    if (packageMode === "dfy" && autorun && repoUrl) {
      try {
        const requireOwnerApproval = governanceProfile?.patchMode !== "restricted_auto_minor";
        const autoApply = governanceProfile?.patchMode === "restricted_auto_minor";

        const jobPayload = {
          target_id: `evidence_${docRef.id}`,
          request_text:
            "Generate an AI-COMMS business packet for this intake. Produce a deterministic deliverable packet (RESPONSE.md + artifacts) and include: security audit notes, deployment notes, and recommended next steps. Do not apply changes automatically.",
          ingest: { type: "git", value: repoUrl },
          envelope: {
            autoApply,
            requireOwnerApproval,
            governanceProfile,
            meta: { evidenceId: docRef.id, leadId, email, governanceTier: governanceProfile?.tier || null },
          },
        };

        await ensureSocketCompatible();
        socketJob = await socketPost("/jobs", jobPayload);
        const jid = socketJob?.jobId || socketJob?.id || null;
        if (jid && orgId) {
          await db.collection("jobs").doc(docRef.id).set(
            { brainJobId: jid, status: "processing", updatedAt: Date.now() },
            { merge: true }
          );
          await db.collection("projects").doc(docRef.id).set(
            { status: "processing", updatedAt: Date.now(), brainJobId: jid },
            { merge: true }
          );
        }

        await db.collection("evidence_packs").doc(docRef.id).set(
          {
            socketJobId: socketJob?.jobId || socketJob?.id || null,
            socketJobCreatedAt: Date.now(),
          },
          { merge: true }
        );
        await logEvent("evidence_pack_socket_job_created", "INFO", "Socket job created from evidence pack", {
          evidenceId: docRef.id,
          jobId: socketJob?.jobId || socketJob?.id || null,
        });
      } catch (e: any) {
        await logEvent("evidence_pack_socket_job_failed", "WARN", "Failed to create Socket job from evidence pack", {
          evidenceId: docRef.id,
          error: String(e?.message || e),
        });
        // Do not fail intake submission if Brain is unreachable.
      }
    }

    // DIY package: we do not run the Brain. We store a deterministic link to the self-implement kit.
    // This is intentionally static so it can be cached and shared.
    const diyPacketUrl = packageMode === "diy" ? "/packs/aicomms_diy_packet.zip" : null;
    if (diyPacketUrl) {
      await db.collection("evidence_packs").doc(docRef.id).set(
        {
          diyPacketUrl,
          diyPacketCreatedAt: Date.now(),
        },
        { merge: true }
      );
    }

    // A basic token for client status page can be issued later via a stronger flow.
    // For now we return empty string (client portal token flow already exists elsewhere).
    return {
      ok: true,
      evidenceId: docRef.id,
      clientToken: "",
      socketJobId: socketJob?.jobId || socketJob?.id || null,
      diyPacketUrl,
    };
  }
);
