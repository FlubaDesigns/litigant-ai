
import { db } from "./firebaseAdmin";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { bumpDailyIpCounter } from "./lib/rateLimit";
import { logEvent } from "./lib/logEvent";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

function getClientIp(req: any) {
  const raw = String(req?.rawRequest?.ip || req?.rawRequest?.headers?.["x-forwarded-for"] || "unknown");
  return raw.split(",")[0].trim() || "unknown";
}

type RiskClass = "SMB" | "MID_MARKET" | "REGULATED";

function riskRank(r: RiskClass): number {
  if (r === "REGULATED") return 3;
  if (r === "MID_MARKET") return 2;
  return 1;
}

export const createTieredCheckoutSession = onCall(
  {
    enforceAppCheck: true,
    region: "us-central1",
    secrets: [STRIPE_SECRET_KEY, PUBLIC_SITE_BASE_URL],
  },
  async (req) => {
    const ip = getClientIp(req);
    await bumpDailyIpCounter(ip);

    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "You must be logged in.");

    const orgId = String(req.data?.orgId || uid);
    if (orgId !== uid) {
      // simple safety: users can only create sessions for themselves
      throw new HttpsError("permission-denied", "Org binding mismatch.");
    }

    const tierId = String(req.data?.tierId || "").trim();
    const addonIds = Array.isArray(req.data?.addonIds) ? req.data.addonIds.map((x: any) => String(x)) : [];
    const returnUrl = String(req.data?.returnUrl || "").trim();

    if (!tierId) throw new HttpsError("invalid-argument", "tierId required.");

    // Load org (risk class)
    const orgRef = db.collection("orgs").doc(orgId);
    const orgSnap = await orgRef.get();
    const riskClass: RiskClass = (orgSnap.exists ? (orgSnap.data() as any)?.risk_class : null) || "SMB";

    // Load tier
    const tierRef = db.collection("pricing_tiers").doc(tierId);
    const tierSnap = await tierRef.get();
    if (!tierSnap.exists) throw new HttpsError("not-found", "Tier not found.");
    const tier = tierSnap.data() as any;

    if (tier.is_active !== true) throw new HttpsError("failed-precondition", "Tier not active.");

    const minRisk: RiskClass = (tier.eligibility_min_risk_class || "SMB");
    if (riskRank(riskClass) < riskRank(minRisk)) {
      throw new HttpsError("failed-precondition", `Tier not eligible for your risk class (${riskClass}).`);
    }

    if (!tier.stripe_price_id_monthly) throw new HttpsError("failed-precondition", "Tier missing Stripe monthly price id.");

    // Load addons and validate
    const addons: any[] = [];
    for (const id of addonIds) {
      const aSnap = await db.collection("pricing_addons").doc(id).get();
      if (!aSnap.exists) throw new HttpsError("not-found", `Addon not found: ${id}`);
      const a = aSnap.data() as any;
      if (a.is_active !== true) throw new HttpsError("failed-precondition", `Addon not active: ${id}`);
      if (a.requires_min_tier_id && String(a.requires_min_tier_id).trim()) {
        const reqTierId = String(a.requires_min_tier_id).trim();
        const reqTierSnap = await db.collection("pricing_tiers").doc(reqTierId).get();
        if (!reqTierSnap.exists) throw new HttpsError("failed-precondition", `Addon ${id} requires missing tier ${reqTierId}.`);
        const reqTier = reqTierSnap.data() as any;

        const selectedRank = Number(tier.tier_rank ?? tier.display_order ?? 0);
        const requiredRank = Number(reqTier.tier_rank ?? reqTier.display_order ?? 0);

        // Allow addon if selected tier rank >= required tier rank (ordered eligibility)
        if (selectedRank < requiredRank) {
          throw new HttpsError("failed-precondition", `Addon ${id} requires at least tier ${reqTierId}.`);
        }
      }
      if (!a.stripe_price_id_monthly) throw new HttpsError("failed-precondition", `Addon ${id} missing Stripe price id.`);
      addons.push(a);
    }

    const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2023-10-16" });

    const pricingVersionSnap = await db.collection("pricing_version").doc("config").get();
    const pricingVersion = Number((pricingVersionSnap.data() as any)?.current_version || tier.version || 0);

    const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = [
      { price: String(tier.stripe_price_id_monthly), quantity: 1 },
      ...addons.map(a => ({ price: String(a.stripe_price_id_monthly), quantity: 1 })),
    ];

    // Optional onboarding fee as one-time line item
    const onboardingPriceId = String(tier.stripe_price_id_onboarding || "").trim();
    if (onboardingPriceId) {
      line_items.push({ price: onboardingPriceId, quantity: 1 });
    }

    const successUrl = (returnUrl || (PUBLIC_SITE_BASE_URL.value() + "/checkout/success")) + "?session_id={CHECKOUT_SESSION_ID}";
    const cancelUrl = PUBLIC_SITE_BASE_URL.value() + "/checkout/cancel";

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items,
      success_url: successUrl,
      cancel_url: cancelUrl,
      client_reference_id: orgId,
      metadata: {
        orgId,
        tierId,
        addonIds: addonIds.join(","),
        pricingVersion: String(pricingVersion),
        riskClass: String(riskClass),
      },
    });

    await logEvent("checkout_tiered_created", { orgId, tierId, addonIds, pricingVersion, riskClass }, { ip, uid });

    return { url: session.url };
  }
);
