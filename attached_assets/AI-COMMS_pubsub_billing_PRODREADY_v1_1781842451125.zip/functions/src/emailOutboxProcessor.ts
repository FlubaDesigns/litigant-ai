import { onSchedule } from "firebase-functions/v2/scheduler";
import { defineSecret } from "firebase-functions/params";
import { db } from "./firebaseAdmin";
import { sendEmail } from "./emailResend";
import { logOpsError } from "./opsLog";
import { logEvent } from "./lib/logEvent";
import { recordOpsSignal } from "./lib/opsSignals";

type OutboxDoc = {
  to: string;
  subject: string;
  html: string;
  status: "queued" | "sent" | "error" | "failed_permanent";
  attempts?: number;

  created_at?: any;
  sent_at?: any;
  last_error?: string | null;
};

const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");

export const processEmailOutbox = onSchedule(
  { schedule: "every 5 minutes", region: "us-central1", secrets: [RESEND_API_KEY, AICOMMS_FROM_EMAIL] },
  async () => {
    const snap = await db
      .collection("email_outbox")
      .where("status", "==", "queued")
      .limit(25)
      .get();

    for (const doc of snap.docs) {
      const data = doc.data() as Partial<OutboxDoc>;
      try {
        if (!data.to || !data.subject || !data.html) {
          await doc.ref.update({ status: "error", last_error: "missing_to_subject_or_html" });
          await recordOpsSignal("email_send_fail", false, 1, { outboxId: doc.id, reason: "missing_fields" });
          continue;
        }

        const toNorm = String(data.to).trim().toLowerCase();
        // Re-check suppression at send-time
        const supSnap = await db.collection("email_suppressions").doc(toNorm).get();
        if (supSnap.exists) {
          await doc.ref.update({ status: "failed_permanent", last_error: "suppressed" });
          await recordOpsSignal("email_send_fail", false, 1, { outboxId: doc.id, reason: "suppressed" });
          continue;
        }

        await sendEmail({ to: toNorm, subject: String(data.subject), html: String(data.html) });

        await recordOpsSignal("email_send_ok", true, 1, { outboxId: doc.id });
        await logEvent("email_send_ok", "INFO", "Email sent from outbox.", { outboxId: doc.id });

        await doc.ref.update({
          status: "sent",
          sent_at: new Date(),
          last_error: null,
        });
      } catch (e: any) {
        const attempts = Number((data as any).attempts || 0) + 1;
        if (attempts >= 5) {
          await db.collection("email_dead_letter").add({
            to: String(data.to),
            subject: String(data.subject),
            html: String(data.html),
            attempts,
            last_error: e?.message || "send_failed",
            created_at: new Date(),
          });
          await doc.ref.update({ status: "failed_permanent", attempts, last_error: e?.message || "send_failed" });
        } else {
          await doc.ref.update({ status: "queued", attempts, last_error: e?.message || "send_failed" });
        }
        await logOpsError("email_outbox_send_failed", e, { id: doc.id });
      }
    }
  }
);
