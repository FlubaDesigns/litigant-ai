import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { db } from "./firebaseAdmin";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

/**
 * createBillingPortalSession (callable)
 * Returns a Stripe Billing Portal URL for the authenticated user.
 */
export const createBillingPortalSession = onCall(
  {
    enforceAppCheck: true,
    region: "us-central1",
    secrets: [STRIPE_SECRET_KEY, PUBLIC_SITE_BASE_URL],
  },
  async (req) => {
    if (!req.auth?.uid) {
      throw new HttpsError("unauthenticated", "You must be signed in.");
    }

    const uid = req.auth.uid;
    const userSnap = await db.collection("users").doc(uid).get();
    const user = userSnap.exists ? (userSnap.data() as any) : {};
    const stripeCustomerId = String(user?.stripe_customer_id || "").trim();

    if (!stripeCustomerId) {
      throw new HttpsError("failed-precondition", "No Stripe customer ID on file for this user.");
    }

    const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });
    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
    const returnUrl = baseUrl ? `${baseUrl}/dashboard` : "https://example.com/dashboard";

    const session = await stripe.billingPortal.sessions.create({
      customer: stripeCustomerId,
      return_url: returnUrl,
    });

    return { url: session.url };
  }
);
