import { admin, db } from "./firebaseAdmin";
import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";

type CheckResult = {
  ok: boolean;
  checks: Array<{ name: string; ok: boolean; detail?: any }>;
  missing: {
    secrets: string[];
    firestore: string[];
    storage: string[];
  };
};

function init() {
  if (admin.apps.length === 0) }

// Secrets used across the system (aligns to scoped canon)
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const STRIPE_WEBHOOK_SECRET = defineSecret("STRIPE_WEBHOOK_SECRET");
const STRIPE_AUDIT_PRICE_ID = defineSecret("STRIPE_AUDIT_PRICE_ID");
const STRIPE_PRO_PRICE_ID = defineSecret("STRIPE_PRO_PRICE_ID");
const STRIPE_ENTERPRISE_PRICE_ID = defineSecret("STRIPE_ENTERPRISE_PRICE_ID");
const GRACE_PERIOD_DAYS = defineSecret("GRACE_PERIOD_DAYS");

const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");

// Providers (only required if EXECUTION_MODE becomes REAL)
const EXECUTION_MODE = defineSecret("EXECUTION_MODE");
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");
const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");
const XAI_API_KEY = defineSecret("XAI_API_KEY");

function isSet(v?: string) {
  return !!String(v || "").trim();
}

export const validateConfig = onRequest(
  {
    region: "us-central1",
    secrets: [
      PUBLIC_SITE_BASE_URL,
      STRIPE_SECRET_KEY,
      STRIPE_WEBHOOK_SECRET,
      STRIPE_AUDIT_PRICE_ID,
      STRIPE_PRO_PRICE_ID,
      STRIPE_ENTERPRISE_PRICE_ID,
      GRACE_PERIOD_DAYS,
      RESEND_API_KEY,
      AICOMMS_FROM_EMAIL,
      AICOMMS_ADMIN_EMAIL,
      EXECUTION_MODE,
      OPENAI_API_KEY,
      ANTHROPIC_API_KEY,
      XAI_API_KEY,
    ],
  },
  async (_req, res) => {
    try {
      init();

      const checks: CheckResult["checks"] = [];
      const missingSecrets: string[] = [];
      const missingFirestore: string[] = [];
      const missingStorage: string[] = [];

      // --- Secrets ---
      const baseUrl = PUBLIC_SITE_BASE_URL.value();
      checks.push({ name: "secret:PUBLIC_SITE_BASE_URL", ok: isSet(baseUrl), detail: isSet(baseUrl) ? "set" : "missing" });
      if (!isSet(baseUrl)) missingSecrets.push("PUBLIC_SITE_BASE_URL");

      const stripeOk =
        isSet(STRIPE_SECRET_KEY.value()) &&
        isSet(STRIPE_WEBHOOK_SECRET.value()) &&
        isSet(STRIPE_AUDIT_PRICE_ID.value()) &&
        isSet(STRIPE_PRO_PRICE_ID.value()) &&
        isSet(STRIPE_ENTERPRISE_PRICE_ID.value());

      checks.push({
        name: "secret:STRIPE",
        ok: stripeOk,
        detail: {
          STRIPE_SECRET_KEY: isSet(STRIPE_SECRET_KEY.value()),
          STRIPE_WEBHOOK_SECRET: isSet(STRIPE_WEBHOOK_SECRET.value()),
          STRIPE_AUDIT_PRICE_ID: isSet(STRIPE_AUDIT_PRICE_ID.value()),
          STRIPE_PRO_PRICE_ID: isSet(STRIPE_PRO_PRICE_ID.value()),
          STRIPE_ENTERPRISE_PRICE_ID: isSet(STRIPE_ENTERPRISE_PRICE_ID.value()),
        },
      });

      if (!isSet(STRIPE_SECRET_KEY.value())) missingSecrets.push("STRIPE_SECRET_KEY");
      if (!isSet(STRIPE_WEBHOOK_SECRET.value())) missingSecrets.push("STRIPE_WEBHOOK_SECRET");
      if (!isSet(STRIPE_AUDIT_PRICE_ID.value())) missingSecrets.push("STRIPE_AUDIT_PRICE_ID");
      if (!isSet(STRIPE_PRO_PRICE_ID.value())) missingSecrets.push("STRIPE_PRO_PRICE_ID");
      if (!isSet(STRIPE_ENTERPRISE_PRICE_ID.value())) missingSecrets.push("STRIPE_ENTERPRISE_PRICE_ID");

      const resendOk = isSet(RESEND_API_KEY.value()) && isSet(AICOMMS_FROM_EMAIL.value()) && isSet(AICOMMS_ADMIN_EMAIL.value());
      checks.push({
        name: "secret:RESEND",
        ok: resendOk,
        detail: {
          RESEND_API_KEY: isSet(RESEND_API_KEY.value()),
          AICOMMS_FROM_EMAIL: isSet(AICOMMS_FROM_EMAIL.value()),
          AICOMMS_ADMIN_EMAIL: isSet(AICOMMS_ADMIN_EMAIL.value()),
        },
      });

      if (!isSet(RESEND_API_KEY.value())) missingSecrets.push("RESEND_API_KEY");
      if (!isSet(AICOMMS_FROM_EMAIL.value())) missingSecrets.push("AICOMMS_FROM_EMAIL");
      if (!isSet(AICOMMS_ADMIN_EMAIL.value())) missingSecrets.push("AICOMMS_ADMIN_EMAIL");

      const mode = (EXECUTION_MODE.value() || "SIMULATED").toUpperCase();
      const providersOk =
        mode !== "REAL" || isSet(OPENAI_API_KEY.value()) || isSet(ANTHROPIC_API_KEY.value()) || isSet(XAI_API_KEY.value());

      checks.push({
        name: "secret:PROVIDERS",
        ok: providersOk,
        detail: {
          EXECUTION_MODE: mode,
          OPENAI_API_KEY: isSet(OPENAI_API_KEY.value()),
          ANTHROPIC_API_KEY: isSet(ANTHROPIC_API_KEY.value()),
          XAI_API_KEY: isSet(XAI_API_KEY.value()),
        },
      });

      if (mode === "REAL") {
        if (!isSet(OPENAI_API_KEY.value())) missingSecrets.push("OPENAI_API_KEY");
        if (!isSet(ANTHROPIC_API_KEY.value())) missingSecrets.push("ANTHROPIC_API_KEY");
        if (!isSet(XAI_API_KEY.value())) missingSecrets.push("XAI_API_KEY");
      }

      // --- Firestore pointer doc ---
            const pointerRef = db.collection("system_state").doc("current_source");
      const pointerSnap = await pointerRef.get();

      if (!pointerSnap.exists) {
        missingFirestore.push("system_state/current_source");
        checks.push({ name: "firestore:system_state/current_source", ok: false, detail: "missing doc" });
      } else {
        const data = pointerSnap.data() || {};
        const storage_path = String((data as any).storage_path || "").trim();
        const source_version = (data as any).source_version ?? null;

        const okPointer = !!storage_path;
        if (!okPointer) missingFirestore.push("system_state/current_source.storage_path");

        checks.push({
          name: "firestore:system_state/current_source",
          ok: okPointer,
          detail: { storage_path: storage_path || null, source_version },
        });

        // --- Storage object check ---
        if (storage_path) {
          const bucket = admin.storage().bucket();
          const file = bucket.file(storage_path);
          const [exists] = await file.exists();
          if (!exists) missingStorage.push(storage_path);

          checks.push({
            name: "storage:current_source_file",
            ok: exists,
            detail: exists ? `exists:${storage_path}` : `missing:${storage_path}`,
          });
        }
      }

      const ok = missingSecrets.length === 0 && missingFirestore.length === 0 && missingStorage.length === 0;

      const out: CheckResult = {
        ok,
        checks,
        missing: {
          secrets: Array.from(new Set(missingSecrets)),
          firestore: Array.from(new Set(missingFirestore)),
          storage: Array.from(new Set(missingStorage)),
        },
      };

      res.status(ok ? 200 : 400).json(out);
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e?.message || "Unknown error" });
    }
  }
);