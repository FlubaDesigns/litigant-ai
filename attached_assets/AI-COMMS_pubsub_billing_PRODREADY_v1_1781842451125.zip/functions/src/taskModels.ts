export type AgentProvider = "openai" | "anthropic" | "xai" | "simulated";

export type TaskDoc = {
  created_at: FirebaseFirestore.Timestamp;
  status: "queued" | "running" | "complete" | "failed";
  scope_name: "AICOMMS" | "POLLSIT" | string;
  goal: string;
  taskType?: string;
  canon_hash?: string;
  requested_agents?: {
    architect?: string[];
    builder?: string[];
    auditor?: string[];
  };
  constraints: string[];
  source_ref: "system_state/current_source";
  requested_agents: {
    architect: AgentProvider[];
    builder: AgentProvider[];
    auditor: AgentProvider[];
  };
};

export type TaskRunDoc = {
  taskId: string;
  started_at: FirebaseFirestore.Timestamp;
  finished_at?: FirebaseFirestore.Timestamp;
  status: "running" | "complete" | "failed";
  notes?: string;
  drift_gate?: {
    ok: boolean;
    details?: any;
  };
  winner?: {
    provider: AgentProvider;
    outputId: string;
  };
};

export type AgentOutputDoc = {
  taskId: string;
  role: "architect" | "builder" | "auditor";
  provider: AgentProvider;
  created_at: FirebaseFirestore.Timestamp;
  status: "ok" | "error";
  output_type: "plan" | "zip" | "patch" | "report";
  text?: string;
  storage_path?: string;
  error?: string;
};