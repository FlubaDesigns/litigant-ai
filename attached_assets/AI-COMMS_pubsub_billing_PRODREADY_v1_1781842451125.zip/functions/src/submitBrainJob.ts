import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret, defineString } from "firebase-functions/params";
import { PubSub } from "@google-cloud/pubsub";
import { admin, db } from "./firebaseAdmin";
import { normalizeTier } from "./tierPolicy";
import { logEvent } from "./lib/logEvent";
import crypto from "crypto";

const BRAIN_PUBSUB_PROJECT = defineString("BRAIN_PUBSUB_PROJECT");
const BRAIN_PUBSUB_TOPIC = defineString("BRAIN_PUBSUB_TOPIC");


// Simple per-user rate limit (best-effort): N requests per WINDOW seconds.
const RATE_LIMIT_WINDOW_SEC = Number(process.env.BRAIN_SUBMIT_RATE_WINDOW_SEC || 60);
const RATE_LIMIT_MAX = Number(process.env.BRAIN_SUBMIT_RATE_MAX || 8);

async function enforceRateLimit(uid: string) {
  const ref = db.collection("rate_limits").doc(`brain_submit_${uid}`);
  const now = Date.now();
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const data = (snap.exists ? (snap.data() as any) : {}) || {};
    const windowStart = Number(data.windowStart || 0);
    const count = Number(data.count || 0);

    if (!windowStart || now - windowStart > RATE_LIMIT_WINDOW_SEC * 1000) {
      tx.set(ref, { windowStart: now, count: 1, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      return;
    }
    if (count >= RATE_LIMIT_MAX) {
      throw new HttpsError("resource-exhausted", "Too many requests. Try again in a minute.");
    }
    tx.set(ref, { count: count + 1, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  });
}

/**
 * submitBrainJob
 * Control-plane -> Brain job submitter.
 * - Auth required
 * - App Check required
 * - Enforces tier != free (basic guard; adjust as needed)
 * - Writes an internal job record for portal visibility
 * - Publishes job payload to Brain's Pub/Sub topic
 */
export const submitBrainJob = onCall(
  { enforceAppCheck: true, timeoutSeconds: 60, cors: true },
  async (req) => {
    const uid = req.auth?.uid;
    if (!uid) throw new HttpsError("unauthenticated", "Sign in required.");

    await enforceRateLimit(uid);

    const userSnap = await db.collection("users").doc(uid).get();
    const tier = normalizeTier(userSnap.data()?.tier);
    if (tier === "free") throw new HttpsError("permission-denied", "Upgrade required.");

    const { orgId, intent, inputs, constraints } = (req.data || {}) as any;
    if (!orgId || !intent) throw new HttpsError("invalid-argument", "orgId and intent are required.");

    const jobId = crypto.randomUUID();
    
    // ---- Credit gate (minutes plan) ----
    // Default behavior:
    // - If caller supplies minutesBudget, we treat it as a requested cap.
    // - We cap by remaining included minutes for the current period if present.
    const requestedBudget = Math.max(0, Math.ceil(Number((req.data || {}).minutesBudget ?? 0)));

    // Load user minutes plan counters (best-effort; if missing, allow requestedBudget)
    let minutesBudgetFinal = requestedBudget;
    try {
      const userSnap = await db.collection("users").doc(uid).get();
      if (userSnap.exists) {
        const u = userSnap.data() as any;
        const included = Number(u.included_minutes_per_month || 60);
        const used = Number(u.minutes_used_current_period || 0);
        const remaining = Math.max(0, included - used);

        // If no requested budget, default to remaining (or a safe small cap)
        if (!requestedBudget) minutesBudgetFinal = remaining || 5;

        // Cap to remaining if remaining is > 0
        if (remaining > 0) minutesBudgetFinal = Math.min(minutesBudgetFinal, remaining);

        // If remaining is 0, allow only if you support overage. For now, block.
        if (remaining <= 0) {
          throw new HttpsError("failed-precondition", "No minutes remaining this period.");
        }
      }
    } catch (e) {
      // If we already threw an HttpsError, rethrow; otherwise proceed with requested budget
      if (e instanceof HttpsError) throw e;
    }
    // ---- end credit gate ----

const idempotencyKey =
      String((req.data || {}).idempotencyKey || "").trim() || `${uid}:${orgId}:${intent}:${Date.now()}`;

    const job = {
      jobId,
      sourceApp: "aicomms",
      orgId,
      userId: uid,
      planTier: tier,
      intent: String(intent),
      inputs: inputs ?? {},
      constraints: constraints ?? {},
      minutesBudget: minutesBudgetFinal,
      idempotencyKey,
      status: "queued",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };

    // Portal-visible job record (AI-COMMS owns this)
    await db.collection("brain_jobs").doc(jobId).set(job, { merge: false });

    const pubsub = new PubSub({ projectId: BRAIN_PUBSUB_PROJECT.value() });
    const topic = pubsub.topic(BRAIN_PUBSUB_TOPIC.value());

    await topic.publishMessage({
      json: {
        schemaVersion: "brain_job_v1",
        ...job,
        createdAtISO: new Date().toISOString(),
        publishedAtISO: new Date().toISOString(),
      },
      attributes: {
        source: "aicomms",
        intent: String(intent),
        orgId: String(orgId),
      },
    });

    await logEvent({
      kind: "brain_job_submitted",
      severity: "info",
      uid,
      orgId,
      jobId,
      intent: String(intent),
    });

    return { ok: true, jobId };
  }
);
