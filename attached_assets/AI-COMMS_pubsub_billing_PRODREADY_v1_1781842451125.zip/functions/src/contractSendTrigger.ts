import { admin, db } from "./firebaseAdmin";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
import { Resend } from "resend";
import { logger } from "firebase-functions";
import { assertCapability } from "./tierPolicy";
const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");

function safeText(v: any, fb = "") {
  if (v === null || v === undefined) return fb;
  const s = String(v).trim();
  return s.length ? s : fb;
}

/**
 * 3) Idempotency: email_outbox doc prevents duplicate sends.
 * Deterministic messageId: contract:{leadId}
 */
async function reserveOutboxOnce(messageId: string, payload: any) {
  const ref = db.collection("email_outbox").doc(messageId);
  return await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (snap.exists && (snap.data() as any)?.status === "sent") return { ok: false, reason: "already_sent" as const };
    if (snap.exists && (snap.data() as any)?.status === "sending") return { ok: false, reason: "already_sending" as const };

    tx.set(
      ref,
      {
        status: "sending",
        created_at: admin.firestore.FieldValue.serverTimestamp(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
        payload,
      },
      { merge: true }
    );
    return { ok: true };
  });
}

export const sendContractOnApproval = onDocumentUpdated(
  {
    document: "leads/{leadId}",
    secrets: [RESEND_API_KEY, AICOMMS_FROM_EMAIL],
    region: "us-central1",
  },
  async (event) => {
    const leadId = event.params.leadId as string;
    const before = event.data?.before?.data() as any;
    const after = event.data?.after?.data() as any;

    if (!before || !after) return;
    if (!(before.status !== "contract_approved" && after.status === "contract_approved")) return;

    // Tier gating
    const gate = assertCapability(after, "contract_send");
    if (!gate.ok) {
      logger.warn("Contract send blocked by tier.", { leadId, tier: gate.tier });
      await db.collection("leads").doc(leadId).set(
        { status: "tier_blocked_contract_send", tier_effective: gate.tier, updated_at: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );
      return;
    }

    const to = safeText(after.email);
    if (!to) {
      logger.error("No client email on lead. Cannot send contract.", { leadId });
      return;
    }

    const contract = safeText(after.contract_final) || safeText(after.contract_draft);
    if (!contract) {
      logger.error("No contract text found. Cannot send.", { leadId });
      return;
    }

    // 3) Idempotency reserve
    const messageId = `contract:${leadId}`;
    const reserve = await reserveOutboxOnce(messageId, {
      kind: "contract",
      leadId,
      to,
      subject: "Your AI Guardrail Contract (Intuitive / AIComms)",
    });

    if (!reserve.ok) {
      logger.info("Contract send skipped due to outbox idempotency.", { leadId, reason: reserve.reason });
      return;
    }

    const resend = new Resend(RESEND_API_KEY.value());

    const html = `
      <div style="font-family: Arial, sans-serif; line-height: 1.5">
        <h2>Your Contract</h2>
        <p>Below is your AI Guardrail implementation contract.</p>
        <hr/>
        <pre style="white-space: pre-wrap; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${contract
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")}</pre>
        <hr/>
        <p>Reply to this email to confirm receipt and schedule onboarding.</p>
        <p>— Intuitive (Powered by AIComms)</p>
      </div>
    `;

    try {
      const sent = await resend.emails.send({
        from: AICOMMS_FROM_EMAIL.value(),
        to,
        subject: "Your AI Guardrail Contract (Intuitive / AIComms)",
        html,
      });

      await db.collection("email_outbox").doc(messageId).set(
        {
          status: "sent",
          provider: "resend",
          provider_id: (sent as any)?.data?.id || null,
          sent_at: admin.firestore.FieldValue.serverTimestamp(),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      await db.collection("leads").doc(leadId).set(
        {
          status: "contract_sent",
          contract_sent_at: admin.firestore.FieldValue.serverTimestamp(),
          tier_effective: gate.tier,
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      logger.info("Contract sent.", { leadId, tier: gate.tier });
    } catch (err: any) {
      await db.collection("email_outbox").doc(messageId).set(
        {
          status: "error",
          error: err?.message || String(err),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
      throw err;
    }
  }
);