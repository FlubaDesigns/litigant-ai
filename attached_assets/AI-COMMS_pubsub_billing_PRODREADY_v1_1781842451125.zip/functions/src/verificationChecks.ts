import * as crypto from "crypto";
import * as zlib from "zlib";

/**
 * Basic artifact verification checks for builder outputs.
 * These are deterministic checks that do NOT require external tools.
 */

export type ArtifactCheckResult = { ok: true; warnings: string[]; files: string[]; sha256?: string }
  | { ok: false; error: string; files?: string[]; sha256?: string };

const FORBIDDEN_PATTERNS = [
  /^\.env/i,
  /(^|\/)node_modules(\/|$)/i,
  /(^|\/).*\/\.git(\/|$)/i,
  /(firebase-debug\.log)$/i,
];

const MAX_FILES = 5000;
const MAX_ZIP_BYTES = 12 * 1024 * 1024; // 12MB hard cap for safety

function sha256(buf: Buffer) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

/**
 * Very small zip listing without full unzip to disk:
 * We only validate size and do a basic filename scan by parsing local headers.
 * This is not a full ZIP parser; it's a conservative safety gate.
 */
export function verifyZipBase64(zipBase64?: string): ArtifactCheckResult {
  if (!zipBase64) return { ok: false, error: "Missing zipBase64 from builder." };

  let buf: Buffer;
  try {
    buf = Buffer.from(zipBase64, "base64");
  } catch {
    return { ok: false, error: "zipBase64 is not valid base64." };
  }

  if (buf.length > MAX_ZIP_BYTES) {
    return { ok: false, error: `ZIP too large (${buf.length} bytes).` };
  }

  const digest = sha256(buf);

  // Quick scan for filenames by looking for central directory signature 0x02014b50
  const files: string[] = [];
  const sig = Buffer.from([0x50, 0x4b, 0x01, 0x02]);
  let idx = 0;
  while ((idx = buf.indexOf(sig, idx)) !== -1) {
    // central directory header: filename length at offset 28 (2 bytes little-endian)
    if (idx + 46 > buf.length) break;
    const nameLen = buf.readUInt16LE(idx + 28);
    const extraLen = buf.readUInt16LE(idx + 30);
    const commentLen = buf.readUInt16LE(idx + 32);
    const nameStart = idx + 46;
    const nameEnd = nameStart + nameLen;
    if (nameEnd > buf.length) break;
    const name = buf.slice(nameStart, nameEnd).toString("utf8");
    files.push(name);
    idx = nameEnd + extraLen + commentLen;
    if (files.length > MAX_FILES) return { ok: false, error: "ZIP contains too many files." , files, sha256: digest };
  }

  if (!files.length) {
    return { ok: false, error: "ZIP appears to have no readable file entries.", files, sha256: digest };
  }

  for (const fn of files) {
    // path traversal
    if (fn.includes("..") || fn.startsWith("/") || fn.startsWith("\\")) {
      return { ok: false, error: `Forbidden path in ZIP: ${fn}`, files, sha256: digest };
    }
    for (const pat of FORBIDDEN_PATTERNS) {
      if (pat.test(fn)) return { ok: false, error: `Forbidden file/path in ZIP: ${fn}`, files, sha256: digest };
    }
  }

  const warnings: string[] = [];
  if (files.some(f => /package-lock\.json$/i.test(f))) warnings.push("package-lock.json present (ok).");
  return { ok: true, warnings, files, sha256: digest };
}
