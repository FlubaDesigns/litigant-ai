import * as functions from "firebase-functions";
import { admin, db } from "./firebaseAdmin";
import { requireOwner, requireOwnerPin } from "./ownerAuth";
import { sendAlert } from "./alerting";

// Collections:
// - canon_registry/current : { canon_hash, canon_version, updated_at, updated_by, last_request_id }
// - canon_update_requests/{requestId} : { status, proposed_hash, proposed_version, reason, created_at, created_by, approved_at, approved_by }

function nowTs() {
  return admin.firestore.FieldValue.serverTimestamp();
}

export const requestCanonUpdate = functions.https.onRequest(async (req, res) => {
  try {
    // Any signed-in admin can request; owner approves.
    // We reuse requireAdmin if present, else fall back to owner check only.
    const { requireAdmin } = await import("./adminAuth");
    const a = await requireAdmin(req);
    if (!a.ok) { res.status(a.status).json({ ok: false, message: a.message }); return; }

    const proposed_hash = String(req.body?.proposed_hash || "").trim();
    const proposed_version = String(req.body?.proposed_version || "").trim();
    const reason = String(req.body?.reason || "").trim();

    if (!proposed_hash || !proposed_version) {
      res.status(400).json({ ok: false, error: "missing_proposed_hash_or_version" }); return;
    }

    const ref = db.collection("canon_update_requests").doc();
    await ref.set({
      status: "PENDING_OWNER_APPROVAL",
      proposed_hash,
      proposed_version,
      reason,
      created_at: nowTs(),
      created_by: a.uid || null,
    });

    await sendAlert("info", "Canon update requested", `Request ${ref.id} pending owner approval`, {
      requestId: ref.id,
      proposed_hash,
      proposed_version,
    });

    res.json({ ok: true, requestId: ref.id });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const approveCanonUpdate = functions.https.onRequest(async (req, res) => {
  try {
    const o = await requireOwner(req);
    if (!o.ok) { res.status(o.status).json({ ok: false, message: o.message }); return; }
    const pinCheck = requireOwnerPin(req.body);
    if (!pinCheck.ok) { res.status(pinCheck.status).json({ ok: false, message: pinCheck.message }); return; }

    const requestId = String(req.body?.requestId || "").trim();
    const approve = Boolean(req.body?.approve ?? true);
    if (!requestId) { res.status(400).json({ ok: false, error: "missing_requestId" }); return; }

    const ref = db.collection("canon_update_requests").doc(requestId);
    const snap = await ref.get();
    if (!snap.exists) { res.status(404).json({ ok: false, error: "request_not_found" }); return; }

    const data = snap.data() as any;
    if (data.status !== "PENDING_OWNER_APPROVAL") {
      res.status(409).json({ ok: false, error: "request_not_pending", status: data.status }); return;
    }

    if (!approve) {
      await ref.set({
        status: "REJECTED_BY_OWNER",
        approved_at: nowTs(),
        approved_by: o.uid,
      }, { merge: true });

      await sendAlert("warn", "Canon update rejected", `Owner rejected request ${requestId}`, { requestId });
      res.json({ ok: true, requestId, status: "REJECTED_BY_OWNER" });
      return;
    }

    await ref.set({
      status: "APPROVED_BY_OWNER",
      approved_at: nowTs(),
      approved_by: o.uid,
    }, { merge: true });

    await sendAlert("info", "Canon update approved", `Owner approved request ${requestId}`, { requestId });
    res.json({ ok: true, requestId, status: "APPROVED_BY_OWNER" });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const applyCanonUpdate = functions.https.onRequest(async (req, res) => {
  try {
    const o = await requireOwner(req);
    if (!o.ok) { res.status(o.status).json({ ok: false, message: o.message }); return; }
    const pinCheck = requireOwnerPin(req.body);
    if (!pinCheck.ok) { res.status(pinCheck.status).json({ ok: false, message: pinCheck.message }); return; }

    const requestId = String(req.body?.requestId || "").trim();
    if (!requestId) { res.status(400).json({ ok: false, error: "missing_requestId" }); return; }

    const reqRef = db.collection("canon_update_requests").doc(requestId);
    const reqSnap = await reqRef.get();
    if (!reqSnap.exists) { res.status(404).json({ ok: false, error: "request_not_found" }); return; }

    const data = reqSnap.data() as any;
    if (data.status !== "APPROVED_BY_OWNER") {
      res.status(409).json({ ok: false, error: "request_not_approved", status: data.status }); return;
    }

    const canonRef = db.collection("canon_registry").doc("current");
    await canonRef.set({
      canon_hash: String(data.proposed_hash),
      canon_version: String(data.proposed_version),
      updated_at: nowTs(),
      updated_by: o.uid,
      last_request_id: requestId,
    }, { merge: true });

    await reqRef.set({
      status: "APPLIED",
      applied_at: nowTs(),
      applied_by: o.uid,
    }, { merge: true });

    await sendAlert("info", "Canon updated", `Canon updated to ${data.proposed_version}`, {
      requestId,
      canon_hash: data.proposed_hash,
      canon_version: data.proposed_version,
    });

    res.json({ ok: true, requestId, canon_hash: data.proposed_hash, canon_version: data.proposed_version });
  } catch (e: any) {
    res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

// Guard: detect unexpected canon changes (best-effort audit)
export const canonIntegrityGuard = functions.pubsub.schedule("every 30 minutes").onRun(async () => {
  const canon = await db.collection("canon_registry").doc("current").get();
  if (!canon.exists) return;

  const c = canon.data() as any;
  const lastReq = String(c.last_request_id || "");
  if (!lastReq) {
    await sendAlert("warn", "Canon integrity", "Canon registry has no last_request_id; ensure updates go through owner approval.", { canon: c });
    return;
  }
  const reqSnap = await db.collection("canon_update_requests").doc(lastReq).get();
  if (!reqSnap.exists) {
    await sendAlert("error", "Canon integrity breach", "Canon last_request_id does not exist. Possible manual change.", { last_request_id: lastReq, canon: c });
    return;
  }
  const r = reqSnap.data() as any;
  if (String(r.status) !== "APPLIED" || String(r.proposed_hash) !== String(c.canon_hash)) {
    await sendAlert("error", "Canon integrity breach", "Canon registry mismatch vs approved request.", { request: r, canon: c });
  }
});
