import { admin, db } from "./firebaseAdmin";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
import OpenAI from "openai";
import { logger } from "firebase-functions";
import { assertCapability } from "./tierPolicy";
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");

export const generateAuditDraft = onDocumentUpdated(
  { document: "leads/{leadId}", region: "us-central1", secrets: [OPENAI_API_KEY] },
  async (event) => {
    const leadId = event.params.leadId as string;
    const before = event.data?.before?.data() as any;
    const after = event.data?.after?.data() as any;
    if (!before || !after) return;

    // Trigger only when status transitions to paid
    if (!(before.status !== "paid" && after.status === "paid")) return;

    // Tier gating
    const gate = assertCapability(after, "audit_generate");
    if (!gate.ok) {
      logger.warn("Audit blocked by tier.", { leadId, tier: gate.tier });
      await db.collection("leads").doc(leadId).set(
        { status: "tier_blocked_audit", tier_effective: gate.tier, updated_at: admin.firestore.FieldValue.serverTimestamp() },
        { merge: true }
      );
      return;
    }

    // Idempotency guard
    if (after?.ai_audit?.final_draft) {
      logger.info("Audit already exists. Skipping.", { leadId });
      return;
    }

    const openai = new OpenAI({ apiKey: OPENAI_API_KEY.value() });

    const company = String(after.company || "Unknown").trim();
    const goal = String(after.ai_goal || "").trim();
    const notes = String(after.notes || "").trim();

    const prompt = `
You are an AI governance auditor for "Intuitive (Powered by AIComms)".
Write a practical audit draft for a non-technical client.

OUTPUT FORMAT (exact headings):
1) EXECUTIVE SUMMARY (5-7 lines)
2) TOP FAILURES WE SEE (bullets)
3) ROOT CAUSES (bullets)
4) RECOMMENDED GUARDRAILS (bullets)
5) QUICK WINS (next 7 days)
6) 30-DAY STABILIZATION PLAN
7) RISKS IF IGNORED (short)
8) RECOMMENDED TIER + WHY

CLIENT CONTEXT:
- Company: ${company}
- Goal: ${goal || "(not provided)"}
- Notes: ${notes || "(none)"}

Be clear. No hype. No fake claims.
`.trim();

    const resp = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.25,
      messages: [
        { role: "system", content: "You write scoped, realistic audits for AI workflow failures and governance drift." },
        { role: "user", content: prompt },
      ],
    });

    const draft = resp.choices?.[0]?.message?.content || "";

    await db.collection("leads").doc(leadId).set(
      {
        ai_audit: {
          final_draft: draft,
          generated_at: admin.firestore.FieldValue.serverTimestamp(),
          generated_by: "gpt-4o-mini",
        },
        status: "reviewing",
        tier_effective: gate.tier,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    logger.info("Audit generated.", { leadId, tier: gate.tier });
  }
);