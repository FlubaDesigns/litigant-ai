import { admin, db } from "./firebaseAdmin";
import type { AgentProvider } from "./taskModels";
import type { TaskType } from "./taskTypes";
import type { RoleSeat } from "./roleRouting";

export type MetricsEvent = {
  taskId: string;
  scopeName: string;
  taskType: TaskType;
  role: RoleSeat;
  provider: AgentProvider;
  model?: string;
  startedAt: FirebaseFirestore.Timestamp;
  endedAt: FirebaseFirestore.Timestamp;
  durationMs: number;
  success: boolean;
  stepsCount: number;
  retries: number;
  tokensIn?: number;
  tokensOut?: number;
  totalTokens?: number;
  estimatedCostUsd?: number;
  errorCode?: string;
  errorMessage?: string;
};

function rollupId(provider: AgentProvider, role: RoleSeat, taskType: TaskType) {
  return `${provider}__${role}__${taskType}`;
}

export async function recordMetricsEvent(ev: MetricsEvent): Promise<void> {
  await db.collection("tasks").doc(ev.taskId).collection("metrics_events").add({
    ...ev,
    startedAt: ev.startedAt,
    endedAt: ev.endedAt,
    created_at: admin.firestore.FieldValue.serverTimestamp(),
  });

  const rid = rollupId(ev.provider, ev.role, ev.taskType);
  const ref = db.collection("provider_metrics_rollup").doc(rid);

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const d = (snap.exists ? (snap.data() as any) : {}) || {};
    const runs = Number(d.runs_total || 0) + 1;
    const success = Number(d.success_total || 0) + (ev.success ? 1 : 0);
    const fail = Number(d.fail_total || 0) + (ev.success ? 0 : 1);

    const alpha = 0.2;
    const avgStepsPrev = Number(d.avg_steps ?? ev.stepsCount);
    const avgDurPrev = Number(d.avg_duration_ms ?? ev.durationMs);
    const avgCostPrev = Number(d.avg_cost_usd ?? (ev.estimatedCostUsd ?? 0));

    const avg_steps = avgStepsPrev + alpha * (ev.stepsCount - avgStepsPrev);
    const avg_duration_ms = avgDurPrev + alpha * (ev.durationMs - avgDurPrev);
    const avg_cost_usd = avgCostPrev + alpha * ((ev.estimatedCostUsd ?? 0) - avgCostPrev);

    const success_rate = runs > 0 ? success / runs : 0;

    tx.set(ref, {
      provider: ev.provider,
      role: ev.role,
      taskType: ev.taskType,
      runs_total: runs,
      success_total: success,
      fail_total: fail,
      success_rate,
      avg_steps,
      avg_duration_ms,
      avg_cost_usd,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });
  });
}

export async function getRollup(provider: AgentProvider, role: RoleSeat, taskType: TaskType): Promise<any | null> {
  const ref = db.collection("provider_metrics_rollup").doc(rollupId(provider, role, taskType));
  const snap = await ref.get();
  return snap.exists ? snap.data() : null;
}
