import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { admin, db } from "./firebaseAdmin";
import { logProtectionEvent } from "./logProtectionEvent";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");

/**
 * reportUsageMinutes
 * Records a usage ledger entry and reports overage minutes to Stripe (metered price).
 *
 * Defaults:
 * - Included minutes per month: 60
 * - Overage: $1.00/min (configured in Stripe price, not here)
 */
export const reportUsageMinutes = onCall(
  { enforceAppCheck: true, region: "us-central1", secrets: [STRIPE_SECRET_KEY] },
  async (req) => {
    if (!req.auth?.uid) throw new HttpsError("unauthenticated", "Sign in required.");
    const uid = req.auth.uid;

    const minutesRaw = Number((req.data || {}).minutes || 0);
    const minutes = Math.max(0, Math.ceil(minutesRaw));

    const source = String((req.data || {}).source || "unknown");
    const detail = String((req.data || {}).detail || "");

    if (!minutes) throw new HttpsError("invalid-argument", "Minutes must be > 0.");

    const userRef = db.collection("users").doc(uid);
    const snap = await userRef.get();
    if (!snap.exists) throw new HttpsError("failed-precondition", "User profile missing.");

    const u = snap.data() as any;

    const plan = String(u.plan || u.tier || "").toLowerCase();
    if (plan !== "minutes_hybrid") {
      throw new HttpsError("failed-precondition", "Minutes plan not active for this user.");
    }

    const included = Number(u.included_minutes_per_month || 60);
    const used = Number(u.minutes_used_current_period || 0);
    const newUsed = used + minutes;
    const overageNow = Math.max(0, newUsed - included);
    const overageBefore = Math.max(0, used - included);
    const overageDelta = Math.max(0, overageNow - overageBefore);

    // Ledger entry (append-only)
    await db.collection("usage_ledger").add({
      userId: uid,
      minutes,
      source,
      detail,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Update rolling used minutes for the current period
    await userRef.set(
      {
        minutes_used_current_period: newUsed,
        lifetime_minutes_used: admin.firestore.FieldValue.increment(minutes),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // Report overage delta to Stripe metered subscription item (if present)
    const subItem = String(u.overage_subscription_item_id || "").trim();
    if (subItem && overageDelta > 0) {
      const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });
      await stripe.subscriptionItems.createUsageRecord(subItem, {
        quantity: overageDelta,
        timestamp: Math.floor(Date.now() / 1000),
        action: "increment",
      });

      await logProtectionEvent({
        userId: uid,
        severity: "medium",
        type: "billing",
        message: `Usage overage reported: +${overageDelta} minute(s).`,
        metadata: { source, detail, minutes, overageDelta },
      });
    }

    return {
      ok: true,
      includedMinutes: included,
      usedMinutes: newUsed,
      overageDelta,
    };
  }
);
