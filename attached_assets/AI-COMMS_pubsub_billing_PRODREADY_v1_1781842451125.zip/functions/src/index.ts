// Cloud Functions entrypoint (exports = deployed functions)
// Retail layer: delegates execution to AI Socket Brain.

export { health } from "./health";

// Revenue funnel
export { submitRiskScan } from "./submitRiskScan";
export { submitEvidencePack } from "./submitEvidencePack";
export { createCheckoutSession } from "./createCheckoutSession";
export { createTieredCheckoutSession } from "./createTieredCheckoutSession";
export { resolveApproval } from "./resolveApproval";
export { seedPricing } from "./seedPricing";
export { stripeWebhook } from "./stripeWebhook";

// Config verification utilities (kept for retail app integrity)
export { verifyConfig } from "./verifyConfig";
export { validateConfig } from "./validateConfig";

// Admin helpers
export { setAdminClaim } from "./setAdminClaim";
export { getLaunchStatus } from "./getLaunchStatus";

// Socket Brain proxy endpoints (Retail -> Engine)
export { socketSubmitJob, socketGetJob, socketApplyJob, socketRollbackJob } from "./socketEndpoints";
export { socketJobCompletedWebhook, ownerSyncEvidenceJob } from "./socketJobResults";

// Drafting / comms
export { generateProposalDraft } from "./proposalDraftGenerator";
export { sendProposalOnApproval } from "./proposalSendTrigger";
export { contractDraftGenerator } from "./contractDraftGenerator";
export { sendContractOnApproval } from "./contractSendTrigger";
export { clientStatus } from "./clientPortalApi";
export { lifecycleReminder } from "./reminderEngine";
export { generateAuditDraft } from "./auditGenerator";

// Triggers
export { onLeadCreated } from "./onLeadCreated";

// Admin governance (approval queues, artifact browsing, seat locks, etc.)
export {
  approveOrchestratorRequest,
  denyOrchestratorRequest,
  setSeatLock,
  listArtifacts,
  getGovernanceHealth
} from "./adminGovernanceEndpoints";

// Canon governance (retail can manage canon content; engine enforces it)
export {
  requestCanonUpdate,
  approveCanonUpdate,
  applyCanonUpdate,
  canonIntegrityGuard
} from "./canonGovernance";

// Email processing
export { processEmailOutbox } from "./emailOutboxProcessor";
export { creditReminders } from "./creditReminders";

// Optional admin config endpoints (kept; any execution-style endpoints are deprecated)
export {
  setRoleRouting,
  getRoleRouting,
  setCanaryConfig,
  setSimulationMode,
  unfreezeBreaker,
  replayTask,
  getSeatLeaderboard,
  compareDeterministicSnapshots,
  setAnomalyThresholds,
  setSeatCanaryConfig
} from "./adminConfigEndpoints";

// Canary evaluator (retail signal)
export { canarySeatAutoAdjust } from "./canarySeatEvaluator";


// Scheduled safety nets
export { reconcileStripe } from "./reconcileStripe";
export { emailQueueHealth } from "./emailQueueHealth";
export { processEmailOutbox } from "./emailOutboxProcessor";

export { weeklyReassurance } from "./weeklyReassurance";

export { createBillingPortalSession } from "./createBillingPortalSession";

export { sweepGraceDowngrades } from "./sweepGraceDowngrades";

export { adminMetrics } from "./adminMetrics";

export { systemAlerts } from "./systemAlerts";

export { reconcileStripeSubscriptions } from "./reconcileStripeSubscriptions";

export { createMinutesPlanCheckoutSession } from "./createMinutesPlanCheckoutSession";

export { reportUsageMinutes } from "./reportUsageMinutes";

// Multi-tenant bootstrap
export { onUserCreated } from "./orgBootstrap";

// Portal APIs
export { apiMyProjects, apiProjectDetail } from "./projectPortalApi";

// Lifecycle email automation
export { onDeliverableReady } from "./onDeliverableReady";

export { createApproval } from "./createApproval";

export { approvalsExpirySweep } from "./approvalsExpirySweep";

// Brain bridge (Pub/Sub submit + signed callback)
export { submitBrainJob } from "./submitBrainJob";
export { ingestBrainResult } from "./ingestBrainResult";
