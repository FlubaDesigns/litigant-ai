import { onRequest } from "firebase-functions/v2/https";
import { admin, db } from "./firebaseAdmin";
import { requireUser } from "./authz";

async function getOrgIdForUser(uid: string): Promise<string | null> {
  const snap = await db.collection("users").doc(uid).get();
  if (!snap.exists) return null;
  const data = snap.data() as any;
  return (data?.orgId || null) as string | null;
}

export const apiMyProjects = onRequest({ region: "us-central1" }, async (req, res) => {
  const u = await requireUser(req);
  if (!u.ok) return res.status(u.status).json({ ok: false, error: u.message });

  const uid = u.decoded.uid;
  const orgId = (u.decoded as any)?.orgId || (await getOrgIdForUser(uid));
  if (!orgId) return res.status(403).json({ ok: false, error: "No orgId" });

  const limit = Math.min(parseInt(String(req.query.limit || "50"), 10) || 50, 200);

  const qs = await db.collection("projects")
    .where("orgId", "==", orgId)
    .orderBy("updatedAt", "desc")
    .limit(limit)
    .get();

  const projects = qs.docs.map(d => ({ id: d.id, ...(d.data() as any) }));
  return res.json({ ok: true, orgId, projects });
});

export const apiProjectDetail = onRequest({ region: "us-central1" }, async (req, res) => {
  const u = await requireUser(req);
  if (!u.ok) return res.status(u.status).json({ ok: false, error: u.message });

  const uid = u.decoded.uid;
  const orgId = (u.decoded as any)?.orgId || (await getOrgIdForUser(uid));
  if (!orgId) return res.status(403).json({ ok: false, error: "No orgId" });

  const projectId = String(req.query.projectId || "").trim();
  if (!projectId) return res.status(400).json({ ok: false, error: "Missing projectId" });

  const pSnap = await db.collection("projects").doc(projectId).get();
  if (!pSnap.exists) return res.status(404).json({ ok: false, error: "Not found" });

  const p = pSnap.data() as any;
  if (p?.orgId !== orgId) return res.status(403).json({ ok: false, error: "Forbidden" });

  // Attach deliverables + jobs + packets (best effort)
  const [dSnap, jSnap, pkSnap] = await Promise.all([
    db.collection("deliverables").doc(projectId).get(),
    db.collection("jobs").doc(projectId).get(),
    db.collection("packets").doc(projectId).get(),
  ]);

  return res.json({
    ok: true,
    project: { id: pSnap.id, ...p },
    deliverable: dSnap.exists ? { id: dSnap.id, ...(dSnap.data() as any) } : null,
    job: jSnap.exists ? { id: jSnap.id, ...(jSnap.data() as any) } : null,
    packet: pkSnap.exists ? { id: pkSnap.id, ...(pkSnap.data() as any) } : null,
  });
});
