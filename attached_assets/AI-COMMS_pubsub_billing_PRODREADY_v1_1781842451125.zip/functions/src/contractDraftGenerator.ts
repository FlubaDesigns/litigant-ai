import { admin, db } from "./firebaseAdmin";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
import OpenAI from "openai";
import { logger } from "firebase-functions";
import { assertCapability } from "./tierPolicy";
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");

function safeText(v: any, fb = "") {
  if (v === null || v === undefined) return fb;
  return String(v);
}

function makePrompt(data: any) {
  const projectName = safeText(data?.projectName, "AICOMMS Project");
  const clientName = safeText(data?.clientName, "Client");
  const providerName = safeText(data?.providerName, "Provider");
  const scope = safeText(data?.scope, "");
  const price = safeText(data?.price, "");
  const timeline = safeText(data?.timeline, "");

  return `
You are an expert contract drafter.

Write a short, clear, business-friendly service agreement.

Use this info:
- PROJECT NAME: ${projectName}
- CLIENT: ${clientName}
- PROVIDER: ${providerName}
- SCOPE: ${scope}
- PRICE: ${price}
- TIMELINE: ${timeline}

Requirements:
- Make it concise and readable.
- Include these sections:

1) PARTIES
2) SCOPE OF WORK
3) DELIVERABLES
4) TIMELINE
5) PAYMENT TERMS
6) CHANGE REQUESTS
7) CONFIDENTIALITY
8) IP / OWNERSHIP
9) LIMITATION OF LIABILITY
10) TERMINATION
11) SIGNATURES (placeholders)

Include:
- A "SIGN LINK: [SIGN_LINK_TBD]" line (we will replace later with a real e-sign URL)
- A "PROJECT NAME" line
- A short "NOT LEGAL ADVICE" footer line

Return only the contract text.
`.trim();
}

export const contractDraftGenerator = onDocumentUpdated(
  {
    document: "contracts/{contractId}",
    secrets: [OPENAI_API_KEY],
  },
  async (event) => {
    assertCapability("contract_draft_generator");

    const before = event.data?.before?.data();
    const after = event.data?.after?.data();

    if (!after) return;

    // If already drafted, do nothing
    if (after.draftText) return;

    // If there is no request for draft generation, do nothing
    if (!after.requestDraft) return;

    const prompt = makePrompt(after);

    try {
      const client = new OpenAI({
        apiKey: OPENAI_API_KEY.value(),
      });

      const completion = await client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You draft contracts. Be clear and concise." },
          { role: "user", content: prompt },
        ],
        temperature: 0.2,
      });

      const draft = completion.choices?.[0]?.message?.content?.trim() || "";

      if (!draft) {
        logger.warn("contractDraftGenerator: Empty draft returned.");
        return;
      }

      await db
        .collection("contracts")
        .doc(event.params.contractId)
        .set(
          {
            draftText: draft,
            draftGeneratedAt: admin.firestore.FieldValue.serverTimestamp(),
            requestDraft: false,
          },
          { merge: true }
        );

      logger.info("contractDraftGenerator: Draft saved.", {
        contractId: event.params.contractId,
      });
    } catch (err: any) {
      logger.error("contractDraftGenerator: Failed to generate draft.", {
        contractId: event.params.contractId,
        error: err?.message || err,
      });

      await db
        .collection("contracts")
        .doc(event.params.contractId)
        .set(
          {
            draftError: err?.message || String(err),
            requestDraft: false,
          },
          { merge: true }
        );
    }
  }
);