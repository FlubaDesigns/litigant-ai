/**
 * socketEndpoints.ts
 *
 * PRODUCTION HARDENED
 * These endpoints proxy to the Brain/Socket runtime and MUST NOT be publicly open.
 *
 * Access rules:
 * - Requires Firebase App Check token (web/mobile clients)
 * - Requires Firebase Auth ID token (Authorization: Bearer <idToken>)
 * - Requires admin role via Firestore doc: /admins/{uid}
 *
 * Rationale:
 * This prevents the functions project from becoming an unauthenticated "open proxy" into Socket.
 */
import { onRequest } from "firebase-functions/v2/https";
import { admin, db } from "./firebaseAdmin";
import { requireAppCheck, requireUser } from "./authz";
import { socketPost, socketGet } from "./socketClient";

async function requireAdminDoc(uid: string) {
  const snap = await db.collection("admins").doc(uid).get();
  if (!snap.exists) return { ok: false as const, status: 403, message: "Admin only" };
  return { ok: true as const };
}

async function gate(req: any, res: any) {
  const ac = await requireAppCheck(req);
  if (!ac.ok) { res.status(ac.status).send(ac.message); return null; }

  const u = await requireUser(req);
  if (!u.ok) { res.status(u.status).send(u.message); return null; }

  const adm = await requireAdminDoc(u.decoded.uid);
  if (!adm.ok) { res.status(adm.status).send(adm.message); return null; }

  return { uid: u.decoded.uid };
}

export const socketSubmitJob = onRequest({ region: "us-central1" }, async (req, res) => {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");
  const ctx = await gate(req, res);
  if (!ctx) return;

  const payload = req.body || {};
  const out = await socketPost("/jobs", payload);
  return res.status(200).json(out);
});

export const socketGetJob = onRequest({ region: "us-central1" }, async (req, res) => {
  if (req.method !== "GET") return res.status(405).send("Method not allowed");
  const ctx = await gate(req, res);
  if (!ctx) return;

  const jobId = String(req.query.jobId || "");
  if (!jobId) return res.status(400).send("Missing jobId");
  const out = await socketGet(`/jobs/${encodeURIComponent(jobId)}`);
  return res.status(200).json(out);
});

export const socketApplyJob = onRequest({ region: "us-central1" }, async (req, res) => {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");
  const ctx = await gate(req, res);
  if (!ctx) return;

  const jobId = String(req.query.jobId || "");
  if (!jobId) return res.status(400).send("Missing jobId");
  const out = await socketPost(`/jobs/${encodeURIComponent(jobId)}/apply`, req.body || {});
  return res.status(200).json(out);
});

export const socketRollbackJob = onRequest({ region: "us-central1" }, async (req, res) => {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");
  const ctx = await gate(req, res);
  if (!ctx) return;

  const jobId = String(req.query.jobId || "");
  if (!jobId) return res.status(400).send("Missing jobId");
  const out = await socketPost(`/jobs/${encodeURIComponent(jobId)}/rollback`, req.body || {});
  return res.status(200).json(out);
});
