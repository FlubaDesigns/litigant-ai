// QUEUE_ONLY_HEAVY_WORK: heavy operations must enqueue, not block webhook
import { admin, db } from "./firebaseAdmin";
import { onRequest } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import Stripe from "stripe";
import { normalizeTier } from "./tierPolicy";
import { logProtectionEvent } from "./logProtectionEvent";
import { logOpsError } from "./opsLog";
import { logEvent } from "./lib/logEvent";
import { recordOpsSignal } from "./lib/opsSignals";
import { queueEmail } from "./emailQueue";
import { purchaseHtml, purchaseSubject } from "./emailTemplates";
import crypto from "crypto";

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const STRIPE_WEBHOOK_SECRET = defineSecret("STRIPE_WEBHOOK_SECRET");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");
const PRICE_MINUTES_OVERAGE_ID = defineSecret("PRICE_MINUTES_OVERAGE_ID");

const STRIPE_WEBHOOK_PROCESS_TIMEOUT_MS = Number(process.env.STRIPE_WEBHOOK_PROCESS_TIMEOUT_MS || 25000);

type FulfillmentKind = "audit" | "pro" | "enterprise";
const EXPLORER_CREDIT_AMOUNT = 25;


function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  let t: NodeJS.Timeout;
  const timeout = new Promise<T>((_, reject) => {
    t = setTimeout(() => reject(new Error(`timeout_${label}_${ms}ms`)), ms);
  });
  return Promise.race([p.finally(() => clearTimeout(t!)), timeout]);
}

function makeClientToken(): string {
  // URL-safe token (not a JWT; just a shared secret for status-only portal)
  const buf = Buffer.from(Array.from({ length: 24 }, () => Math.floor(Math.random() * 256)));
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function getOrCreateLeadToken(leadId: string): Promise<string | null> {
  if (!leadId) return null;
  const ref = db.collection("leads").doc(leadId);
  const snap = await ref.get();
  if (!snap.exists) return null;
  const existing = String((snap.data() as any)?.client_token || "").trim();
  if (existing) return existing;
  const token = makeClientToken();
  await ref.set({ client_token: token, updated_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  return token;
}


function sha256Hex(input: string): string {
  const h = crypto.createHash("sha256");
  h.update(input, "utf8");
  return h.digest("hex");
}


async function getLatestGovernanceProfile(orgId: string): Promise<{ version_id: string; profile_hash: string; tier_id: string; addon_ids: string[] } | null> {
  if (!orgId) return null;
  // Fast path: org pointer
  const orgSnap = await db.collection("orgs").doc(orgId).get();
  if (orgSnap.exists) {
    const v = String((orgSnap.data() as any)?.active_governance_profile_version || "");
    if (v) {
      const pSnap = await db.collection("governance_profiles").doc(orgId).collection("versions").doc(v).get();
      if (pSnap.exists) {
        const d = pSnap.data() as any;
        return {
          version_id: String(d.version_id || v || ""),
          profile_hash: String(d.profile_hash || ""),
          tier_id: String(d.tier_id || ""),
          addon_ids: Array.isArray(d.addon_ids) ? d.addon_ids.map(String) : [],
        };
      }
    }
  }
  // Fallback: latest by issued_at
  const q = await db.collection("governance_profiles").doc(orgId).collection("versions").orderBy("issued_at", "desc").limit(1).get();
  if (q.empty) return null;
  const d = q.docs[0].data() as any;
  return {
    version_id: String(d.version_id || q.docs[0].id || ""),
    profile_hash: String(d.profile_hash || ""),
    tier_id: String(d.tier_id || ""),
    addon_ids: Array.isArray(d.addon_ids) ? d.addon_ids.map(String) : [],
  };
}


async function findOrgIdBySubscriptionId(subId: string): Promise<string | null> {
  if (!subId) return null;
  const snap = await db.collection("subscriptions").where("stripe_subscription_id", "==", subId).limit(1).get();
  if (snap.empty) return null;
  return snap.docs[0].id;
}

async function buildStripePriceMaps(): Promise<{ tierByPriceId: Record<string,string>; addonByPriceId: Record<string,string> }> {
  const tierByPriceId: Record<string,string> = {};
  const addonByPriceId: Record<string,string> = {};

  const tiersSnap = await db.collection("pricing_tiers").get();
  tiersSnap.forEach(d => {
    const t: any = d.data();
    const pid = String(t.stripe_price_id_monthly || "").trim();
    if (pid) tierByPriceId[pid] = d.id;
  });

  const addonsSnap = await db.collection("pricing_addons").get();
  addonsSnap.forEach(d => {
    const a: any = d.data();
    const pid = String(a.stripe_price_id_monthly || "").trim();
    if (pid) addonByPriceId[pid] = d.id;
  });

  return { tierByPriceId, addonByPriceId };
}

function extractTierAndAddonsFromSubscription(sub: Stripe.Subscription, maps: { tierByPriceId: Record<string,string>; addonByPriceId: Record<string,string> }) {
  const priceIds = (sub.items?.data || []).map(i => String(i.price?.id || "")).filter(Boolean);
  let tierId = "";
  const addonIds: string[] = [];

  for (const pid of priceIds) {
    if (!tierId && maps.tierByPriceId[pid]) {
      tierId = maps.tierByPriceId[pid];
      continue;
    }
    if (maps.addonByPriceId[pid]) addonIds.push(maps.addonByPriceId[pid]);
  }
  return { tierId, addonIds };
}

async function issueGovernanceProfileFromPricing(opts: {
  orgId: string;
  tierId: string;
  addonIds: string[];
  pricingVersion: number;
  source: "stripe_webhook" | "admin_override" | "migration" | "intake";
}) {
  const { orgId, tierId, addonIds, pricingVersion, source } = opts;

  const tierSnap = await db.collection("pricing_tiers").doc(tierId).get();
  if (!tierSnap.exists) throw new Error("pricing_tier_missing");
  const tier = tierSnap.data() as any;

  // Derive profile from tier defaults. (Addon effects can be layered later; MVP stores addon_ids only)
  const profileBody = {
    tier_id: tierId,
    addon_ids: addonIds,
    autonomy_level: Number(tier.defaults_autonomy_level ?? 0),
    logging_depth: String(tier.defaults_logging_depth || "basic"),
    patch_mode: String(tier.defaults_patch_mode || "approval_required"),
    escalation_sla: String(tier.defaults_escalation_sla || "24h"),
    pricing_version: Number(pricingVersion || tier.version || 0),
  };

  const canonical = JSON.stringify(profileBody, Object.keys(profileBody).sort());
  const profile_hash = sha256Hex(canonical);

  // NOOP_IF_SAME_PROFILE: avoid issuing redundant governance profile versions
  const latest = await getLatestGovernanceProfile(orgId);
  const sameAddons = latest && JSON.stringify((latest.addon_ids||[]).slice().sort()) === JSON.stringify((addonIds||[]).slice().sort());
  if (latest && latest.profile_hash === profile_hash && latest.tier_id === tierId && sameAddons) {
    return { versionId: latest.version_id, profile_hash };
  }

  const versionId = String(Date.now());

  const ref = db.collection("governance_profiles").doc(orgId).collection("versions").doc(versionId);
  await ref.set({
    version_id: versionId,
    issued_at: admin.firestore.FieldValue.serverTimestamp(),
    source,
    locked: true,
    profile_hash,
    ...profileBody,
  }, { merge: false });

  await db.collection("orgs").doc(orgId).set({
    active_governance_profile_version: versionId,
    active_tier_id: tierId,
    active_addon_ids: addonIds,
    pricing_version: Number(profileBody.pricing_version),
    updated_at: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });

  return { versionId, profile_hash };
}


function fulfillmentKindForTier(tier: string): FulfillmentKind {
  const t = normalizeTier(tier);
  if (t === "enterprise") return "enterprise";
  if (t === "pro") return "pro";
  return "audit";
}


async function applyMinutesPlanPeriodReset(uid: string, periodStart?: number, periodEnd?: number) {
  // Reset included usage counters on new billing cycle boundaries.
  const update: any = {
    included_minutes_per_month: 60,
    minutes_used_current_period: 0,
    billing_period_start: periodStart ? admin.firestore.Timestamp.fromMillis(periodStart * 1000) : admin.firestore.FieldValue.delete(),
    billing_period_end: periodEnd ? admin.firestore.Timestamp.fromMillis(periodEnd * 1000) : admin.firestore.FieldValue.delete(),
    updated_at: admin.firestore.FieldValue.serverTimestamp(),
  };
  await db.collection("users").doc(uid).set(update, { merge: true });

  await logProtectionEvent({
    userId: uid,
    severity: "calm",
    type: "billing",
    message: "New billing cycle started. Included minutes reset.",
    metadata: { periodStart, periodEnd },
  });
}

async function resolveUserIdByCustomerOrMetadata(customerId: any, metadataUserId?: string): Promise<string> {
  const metaUid = String(metadataUserId || "").trim();
  if (metaUid) return metaUid;

  const cust = String(customerId || "").trim();
  if (!cust) return "";

  const qs = await db.collection("users").where("stripe_customer_id", "==", cust).limit(1).get();
  if (!qs.empty) return String(qs.docs[0].id);
  return "";
}

function graceExpiryTimestamp() {
  // 7-day grace period
  const ms = Date.now() + 7 * 24 * 60 * 60 * 1000;
  return admin.firestore.Timestamp.fromMillis(ms);
}

/**
 * stripeWebhook
 * - Verifies signature
 * - Processes checkout.session.completed only
 * - Idempotent by Stripe event.id (stripe_events/{eventId})
 * - Writes tier entitlement back to leads/{leadId}
 * - Enqueues fulfillment job to fulfillment_queue/{eventId}
 * - Emits trace to system_events
 */
export const stripeWebhook = onRequest(
  {
    region: "us-central1",
    secrets: [STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, PUBLIC_SITE_BASE_URL],
  },
  async (req, res) => {
    try {
      const stripe = new Stripe(STRIPE_SECRET_KEY.value(), { apiVersion: "2024-06-20" });

      // Verify signature
      let event: Stripe.Event;
      try {
        const sig = req.headers["stripe-signature"];
        if (!sig || typeof sig !== "string") throw new Error("Missing stripe-signature header.");
        const rawBody = (req as any).rawBody;
        if (!rawBody) throw new Error("Missing rawBody (ensure express raw body is enabled for Stripe webhook)");
        event = stripe.webhooks.constructEvent(rawBody, sig, STRIPE_WEBHOOK_SECRET.value());
      } catch (err: any) {
        await recordOpsSignal("stripe_webhook_sig_fail", false, 1, { error: err?.message || "sig_fail" });
        res.status(400).send(`Webhook Error: ${err.message}`);
        return;
      }

      // Log a verified webhook receipt (for Launch Wizard health)
      await recordOpsSignal("stripe_webhook_verified", true, 1, { eventType: event.type, eventId: event.id });
      await logEvent(
        "stripe_webhook_received",
        "INFO",
        `Stripe webhook verified: ${event.type}`,
        { stripe_event_type: event.type, stripe_event_id: event.id }
      );

      
// Supported event types for revenue lifecycle
const supportedTypes = new Set([
  "checkout.session.completed",
  "invoice.paid",
  "invoice.payment_failed",
  "customer.subscription.deleted",
  "customer.subscription.updated",
]);

if (!supportedTypes.has(event.type)) {
  res.json({ received: true, ignored: true, type: event.type });
  return;
}

      // Idempotency: record Stripe event.id once
      const eventId = event.id;
      const eventRef = db.collection("stripe_events").doc(eventId);

      const alreadyProcessed = await db.runTransaction(async (tx) => {
        const snap = await tx.get(eventRef);
        if (snap.exists) return true;

        tx.set(eventRef, {
          id: eventId,
          type: event.type,
          created_at: admin.firestore.FieldValue.serverTimestamp(),
        });

        return false;
      });

      if (alreadyProcessed) {
        res.json({ received: true, duplicate: true });
        return;
      }

      // Branch by event type
if (event.type === "checkout.session.completed") {
  const session = event.data.object as Stripe.Checkout.Session;

  // NEW: Tiered DFY/DYS pricing flow (subscription-based)
  const tierId = String(session.metadata?.tierId || "").trim();
  const orgId = String(session.metadata?.orgId || "").trim();
  if (tierId && orgId) {
    const addonIds = String(session.metadata?.addonIds || "").split(",").map(s => s.trim()).filter(Boolean);
    const pricingVersion = Number(session.metadata?.pricingVersion || 0);

    // Mirror subscription/customer when available
    if (session.customer) {
      await db.collection("subscriptions").doc(orgId).set({
        stripe_customer_id: session.customer,
        stripe_subscription_id: session.subscription || "",
        status: "active",
        tier_id: tierId,
        addon_ids: addonIds,
        pricing_version: pricingVersion,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }

    await issueGovernanceProfileFromPricing({
      orgId,
      tierId,
      addonIds,
      pricingVersion,
      source: "stripe_webhook",
    });

    await logProtectionEvent({
      kind: "purchase",
      status: "ok",
      message: `Tiered plan activated: ${tierId}`,
      tier: tierId,
      leadId: "",
      userId: orgId,
      stripeEventId: event.id,
    });

    res.json({ received: true, tiered: true });
    return;
  }


  const leadId = String(session.metadata?.leadId || "").trim();
  const userId = String(session.metadata?.userId || "").trim();
  const tier = normalizeTier(String(session.metadata?.tier || "audit"));

  // Attach Stripe customer id to user record if present (enables billing portal + lifecycle mapping)
  if (userId && session.customer) {
    await db.collection("users").doc(userId).set(
      {
        stripe_customer_id: session.customer,
        billing_status: "active",
        grace_expires_at: admin.firestore.FieldValue.delete(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  }

  // Protection event: subscription activation (logged once per Stripe event due to idempotency)
  if (userId) {
    await logProtectionEvent({
      userId,
      severity: "calm",
      type: "billing",
      message: "Subscription activated. AI protection enabled.",
      metadata: { tier, leadId, stripeEventId: event.id, sessionId: session.id },
    });
  }

  // Explorer: apply governance credit to user account (no fulfillment_queue)
  if (tier === "explorer" && userId) {
    await db
      .collection("users")
      .doc(userId)
      .set(
        {
          plan: "explorer",
          email:
            (session.customer_details as any)?.email ||
            (session as any).customer_email ||
            String(session.metadata?.email || "").trim() ||
            null,
          creditBalance: admin.firestore.FieldValue.increment(EXPLORER_CREDIT_AMOUNT),
          lifetimeCreditsPurchased: admin.firestore.FieldValue.increment(EXPLORER_CREDIT_AMOUNT),
          stripe_customer_id: session.customer || null,
          billing_status: "active",
          grace_expires_at: admin.firestore.FieldValue.delete(),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
  }

  const fulfillmentKind = fulfillmentKindForTier(tier);

  // Send customer receipt / activation email (all tiers)
  try {
    const customerEmail =
      (session.customer_details as any)?.email ||
      (session as any).customer_email ||
      String(session.metadata?.email || "").trim();

    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
    let portalUrl = baseUrl ? `${baseUrl}/dashboard` : "";
    // Non-explorer purchases are lead-based; use secure status portal link.
    if (tier !== "explorer" && leadId && baseUrl) {
      const token = await getOrCreateLeadToken(leadId);
      if (token) portalUrl = `${baseUrl}/client/${encodeURIComponent(leadId)}?token=${encodeURIComponent(token)}`;
    }

    if (customerEmail) {
      await queueEmail({
        to: customerEmail,
        subject: purchaseSubject(tier),
        html: purchaseHtml({
          tier,
          portalUrl: portalUrl || "https://aicomms.example/",
          creditsGranted: tier === "explorer" ? EXPLORER_CREDIT_AMOUNT : undefined,
        }),
        kind: "purchase_receipt",
        userId: userId || null,
        leadId: leadId || null,
        tier,
        stripeEventId: eventId,
        stripeSessionId: session.id,
      });
    }
  } catch (e) {
    await logOpsError("purchase_email_enqueue_failed", e, { eventId, tier, leadId: leadId || null, userId: userId || null });
  }

  // Write tier entitlement back to lead (server-side fulfillment)
  if (leadId && tier !== "explorer") {
    await db.collection("leads").doc(leadId).set(
      {
        status: "paid",
        tier,
        paid_at: admin.firestore.FieldValue.serverTimestamp(),
        stripe_customer_id: session.customer || null,
        stripe_session_id: session.id,
        amount_total: session.amount_total || null,
        currency: session.currency || null,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );

    // Enqueue fulfillment job (audit/pro/enterprise)
    await db.collection("fulfillment_queue").doc(eventId).set(
      {
        created_at: admin.firestore.FieldValue.serverTimestamp(),
        kind: fulfillmentKind,
        tier,
        lead_id: leadId,
        stripe_event_id: eventId,
        stripe_session_id: session.id,
        stripe_customer_id: session.customer || null,
        status: "queued",
      },
      { merge: true }
    );
  }

  // Always write a trace event
  await db.collection("system_events").add({
    created_at: admin.firestore.FieldValue.serverTimestamp(),
    type: "stripe_checkout_completed",
    lead_id: leadId || null,
    tier,
    fulfillment_kind: fulfillmentKind,
    stripe_event_id: eventId,
    stripe_session_id: session.id,
    amount_total: session.amount_total || null,
    currency: session.currency || null,
  });

  res.json({ received: true, processed: true, leadId: leadId || null, tier });
  return;
}

// Lifecycle events (subscriptions)
// Map to a userId via metadata userId (preferred) or stripe_customer_id on users collection.
if (event.type === "invoice.paid") {
  const invoice = event.data.object as Stripe.Invoice;
  const uid = await resolveUserIdByCustomerOrMetadata(invoice.customer, (invoice as any).metadata?.userId);
  if (uid) {
    await db.collection("users").doc(uid).set(
      {
        billing_status: "active",
        grace_expires_at: admin.firestore.FieldValue.delete(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
    await logProtectionEvent({
      userId: uid,
      severity: "calm",
      type: "billing",
      message: "Payment received. Coverage remains active.",
      metadata: { stripeEventId: event.id, invoiceId: invoice.id },
    });
  }
  res.json({ received: true, processed: true, type: event.type });
  return;
}

if (event.type === "invoice.payment_failed") {
  const invoice = event.data.object as Stripe.Invoice;
  const uid = await resolveUserIdByCustomerOrMetadata(invoice.customer, (invoice as any).metadata?.userId);
  if (uid) {
    await db.collection("users").doc(uid).set(
      {
        billing_status: "grace",
        grace_expires_at: graceExpiryTimestamp(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
    await logProtectionEvent({
      userId: uid,
      severity: "critical",
      type: "billing",
      message: "Payment failed. Coverage is in grace period (7 days).",
      metadata: { stripeEventId: event.id, invoiceId: invoice.id },
    });
  }
  res.json({ received: true, processed: true, type: event.type });
  return;
}

if (event.type === "customer.subscription.deleted") {
  const sub = event.data.object as Stripe.Subscription;
  const uid = await resolveUserIdByCustomerOrMetadata(sub.customer, (sub as any).metadata?.userId);
  if (uid) {
    await db.collection("users").doc(uid).set(
      {
        billing_status: "canceled",
        tier: "audit",
        plan: "free",
        grace_expires_at: admin.firestore.FieldValue.delete(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
    await logProtectionEvent({
      userId: uid,
      severity: "medium",
      type: "billing",
      message: "Subscription canceled. Coverage downgraded.",
      metadata: { stripeEventId: event.id, subscriptionId: sub.id },
    });
  }
  
  // Tiered subscription delete mirror (DFY/DYS)
  try {
    const orgId = await findOrgIdBySubscriptionId(sub.id);
    if (orgId) {
      await db.collection("subscriptions").doc(orgId).set({
        status: String(sub.status || "canceled"),
        canceled_at: admin.firestore.FieldValue.serverTimestamp(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
      await db.collection("orgs").doc(orgId).set({
        active_tier_id: admin.firestore.FieldValue.delete(),
        active_addon_ids: admin.firestore.FieldValue.delete(),
        active_governance_profile_version: admin.firestore.FieldValue.delete(),
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }
  } catch (e: any) {
    await logOpsError("tiered_subscription_deleted_mirror_failed", e, { stripeEventId: event.id, subscriptionId: sub.id });
  }

res.json({ received: true, processed: true, type: event.type });
  return;
}

if (event.type === "customer.subscription.updated") {
  const sub = event.data.object as Stripe.Subscription;
  const uid = await resolveUserIdByCustomerOrMetadata(sub.customer, (sub as any).metadata?.userId);
  if (uid) {
    // If subscription is active, clear grace; if past_due, set grace
    const status = String(sub.status || "");
    const update: any = { updated_at: admin.firestore.FieldValue.serverTimestamp() };
    if (status === "active" || status === "trialing") {
      update.billing_status = "active";
      update.grace_expires_at = admin.firestore.FieldValue.delete();
    } else if (status === "past_due" || status === "unpaid") {
      update.billing_status = "grace";
      update.grace_expires_at = graceExpiryTimestamp();
    }
    await db.collection("users").doc(uid).set(update, { merge: true });

    await logProtectionEvent({
      userId: uid,
      severity: "calm",
      type: "billing",
      message: `Subscription updated (${status}).`,
      metadata: { stripeEventId: event.id, subscriptionId: sub.id, status },
    });
  }
  
  // Tiered subscription mirror update (DFY/DYS) using subscription id mapping
  try {
    const orgId = await findOrgIdBySubscriptionId(sub.id);
    if (orgId) {
      const maps = await buildStripePriceMaps();
      const extracted = extractTierAndAddonsFromSubscription(sub, maps);
      const tierId = String((sub as any).metadata?.tierId || extracted.tierId || "").trim();
      const addonIds = extracted.addonIds;

      // Update subscription mirror
      await db.collection("subscriptions").doc(orgId).set({
        stripe_customer_id: sub.customer,
        stripe_subscription_id: sub.id,
        status: String(sub.status || ""),
        current_period_end: admin.firestore.Timestamp.fromMillis(Number(sub.current_period_end || 0) * 1000),
        tier_id: tierId || admin.firestore.FieldValue.delete(),
        addon_ids: addonIds,
        updated_at: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });

      // If tier known, issue new governance version on meaningful change
      if (tierId) {
        const pricingVersionSnap = await db.collection("pricing_version").doc("config").get();
        const pricingVersion = Number((pricingVersionSnap.data() as any)?.current_version || 0);
        await issueGovernanceProfileFromPricing({ orgId, tierId, addonIds, pricingVersion, source: "stripe_webhook" });
      }
    }
  } catch (e: any) {
    await logOpsError("tiered_subscription_updated_mirror_failed", e, { stripeEventId: event.id, subscriptionId: sub.id });
  }

res.json({ received: true, processed: true, type: event.type });
  return;
}



// Send customer receipt / activation email (all tiers)
try {
  const customerEmail =
    (session.customer_details as any)?.email ||
    (session as any).customer_email ||
    String(session.metadata?.email || "").trim();

  const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
  let portalUrl = baseUrl ? `${baseUrl}/dashboard` : "";
  // Non-explorer purchases are lead-based; use secure status portal link.
  if (tier !== "explorer" && leadId && baseUrl) {
    const token = await getOrCreateLeadToken(leadId);
    if (token) portalUrl = `${baseUrl}/client/${encodeURIComponent(leadId)}?token=${encodeURIComponent(token)}`;
  }

  if (customerEmail) {
    await queueEmail({
      to: customerEmail,
      subject: purchaseSubject(tier),
      html: purchaseHtml({ tier, portalUrl: portalUrl || "https://aicomms.example/", creditsGranted: tier === "explorer" ? EXPLORER_CREDIT_AMOUNT : undefined }),
      kind: "purchase_receipt",
      userId: userId || null,
      leadId: leadId || null,
      tier,
      stripeEventId: eventId,
      stripeSessionId: session.id,
    });
  }
} catch (e) {
  await logOpsError("purchase_email_enqueue_failed", e, { eventId, tier, leadId: leadId || null, userId: userId || null });
}


      // Write tier entitlement back to lead (server-side fulfillment)
      if (leadId && tier !== "explorer") {
        await db.collection("leads").doc(leadId).set(
          {
            status: "paid",
            tier,
            paid_at: admin.firestore.FieldValue.serverTimestamp(),
            stripe_customer_id: session.customer || null,
            stripe_session_id: session.id,
            amount_total: session.amount_total || null,
            currency: session.currency || null,
            updated_at: admin.firestore.FieldValue.serverTimestamp(),
          },
          { merge: true }
        );

        // Enqueue fulfillment job (audit/pro/enterprise)
        await db.collection("fulfillment_queue").doc(eventId).set(
          {
            created_at: admin.firestore.FieldValue.serverTimestamp(),
            kind: fulfillmentKind,
            tier,
            lead_id: leadId,
            stripe_event_id: eventId,
            stripe_session_id: session.id,
            stripe_customer_id: session.customer || null,
            status: "queued",
          },
          { merge: true }
        );
      }

      

      // (checkout + lifecycle handled above)

} catch (err: any) {
      await recordOpsSignal("stripe_webhook_processed_fail", false, 1, { error: err?.message || "internal_error" });
      await logOpsError("stripeWebhook", err);
      res.status(500).send("Internal error");
    }
  }
);