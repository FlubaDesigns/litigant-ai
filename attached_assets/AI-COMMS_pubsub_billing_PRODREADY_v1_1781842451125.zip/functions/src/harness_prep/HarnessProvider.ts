// HarnessProvider (prep, not wired)
export type HarnessMode = "local" | "brain";

export function getHarnessMode(): HarnessMode {
  return (process.env.HARNESS_MODE === "brain" ? "brain" : "local");
}

// In brain mode: submit intent to Brain ingress.
// In local mode: execute current internal implementation.
export async function submitIntentViaHarness(intent: any) {
  const mode = getHarnessMode();
  if (mode === "local") return { mode, routed: false };

  const baseUrl = process.env.BRAIN_BASE_URL;
  if (!baseUrl) throw new Error("BRAIN_BASE_URL is required in HARNESS_MODE=brain");

  const res = await fetch(`${baseUrl}/brain/intents`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(intent),
  });

  if (!res.ok) throw new Error(`Brain ingress failed: ${res.status}`);
  return res.json();
}
