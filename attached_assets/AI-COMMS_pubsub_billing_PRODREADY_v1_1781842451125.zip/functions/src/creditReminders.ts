import { admin, db } from "./firebaseAdmin";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { defineSecret } from "firebase-functions/params";
import { queueEmail } from "./emailQueue";
import { creditNudgeHtml, creditNudgeSubject } from "./emailTemplates";

const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

/**
 * creditReminders
 * - Nudges users who have unused governance credits
 * - Runs daily
 *
 * Rules (v1):
 * - plan == "explorer"
 * - creditBalance > 0
 * - lastActiveAt older than 14 days OR missing
 * - at most 3 nudges (stage 0/1/2)
 */
export const creditReminders = onSchedule(
  {
    schedule: "every day 10:00",
    timeZone: "America/New_York",
    region: "us-central1",
    secrets: [PUBLIC_SITE_BASE_URL],
  },
  async () => {
    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");
    const dashboardUrl = baseUrl ? `${baseUrl}/dashboard` : "https://aicomms.example/dashboard";

    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;

    // Pull a limited batch to avoid runaway costs.
    const snap = await db
      .collection("users")
      .where("plan", "==", "explorer")
      .where("creditBalance", ">", 0)
      .limit(200)
      .get();

    for (const d of snap.docs) {
      const u = d.data() as any;
      const email = String(u.email || "").trim();
      if (!email) continue;

      const stage = Number(u.credit_nudge_stage || 0);
      if (stage >= 3) continue;

      const lastActive =
        u.lastActiveAt?.toDate?.() instanceof Date ? u.lastActiveAt.toDate().getTime() : 0;

      const idleDays = lastActive ? Math.floor((now - lastActive) / dayMs) : 9999;
      if (idleDays < 14) continue;

      const lastNudge =
        u.credit_nudge_last_sent_at?.toDate?.() instanceof Date ? u.credit_nudge_last_sent_at.toDate().getTime() : 0;

      // Space nudges out.
      const minGapDays = stage === 0 ? 14 : stage === 1 ? 30 : 60;
      if (lastNudge && now - lastNudge < minGapDays * dayMs) continue;

      const credits = Math.max(0, Number(u.creditBalance || 0));

      await queueEmail({
        to: email,
        subject: creditNudgeSubject(stage),
        html: creditNudgeHtml({ stage, credits, dashboardUrl }),
        kind: "credit_nudge",
        userId: d.id,
        leadId: null,
        tier: "explorer",
        stripeEventId: null,
        stripeSessionId: null,
      });

      await d.ref.set(
        {
          credit_nudge_stage: stage + 1,
          credit_nudge_last_sent_at: admin.firestore.FieldValue.serverTimestamp(),
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    }
  }
);
