import * as functions from "firebase-functions";
import { admin, db } from "./firebaseAdmin";
import { requireUser, requireAdmin } from "./authz";
import { socketPost } from "./socketClient";

/**
 * Governance admin endpoints (owner/admin only)
 * - Approval queue (orchestrator_requests)
 * - Seat locks
 * - Artifact vault listing
 * - Health checks
 */

export const approveOrchestratorRequest = functions.https.onRequest(async (req, res) => {
  try {
    const u = await requireUser(req);
    if (!u.ok) return res.status(u.status).json({ ok: false, message: u.message });
    const a = await requireAdmin(u.decoded);
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });
    const uid = u.decoded.uid || u.decoded.user_id || "";
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });

    const id = String(req.body?.id || "").trim();
    const note = String(req.body?.note || "").trim();
    if (!id) return res.status(400).json({ ok: false, error: "missing_id" });

    const ref = db.collection("orchestrator_requests").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "not_found" });

    const data = snap.data() || {};
    const socket_job_id = String((data as any).socket_job_id || "").trim();
    // Mechanical owner approval token (placeholder). In prod, this becomes a panel-issued signed token.
    const ownerApprovalToken = require("crypto").randomBytes(16).toString("hex");

    await ref.set({
      status: "approved",
      approved_at: admin.firestore.FieldValue.serverTimestamp(),
      approved_by: uid,
      approved_note: note || null,
      ownerApprovalToken: ownerApprovalToken,
      socket_job_id: socket_job_id || null,
    }, { merge: true });

    await db.collection("decision_log").add({
      kind: "orchestrator_request",
      request_id: id,
      action: "approved",
      by: uid,
      note: note || null,
      at: admin.firestore.FieldValue.serverTimestamp(),
    });

    // If this approval is tied to a Socket job, trigger apply (owner final word enforced by token).
    let socket_apply: any = null;
    if (socket_job_id) {
      try {
        socket_apply = await socketPost(`/jobs/${encodeURIComponent(socket_job_id)}/apply`, { ownerApprovalToken });
        await ref.set({ socket_apply, socket_apply_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      } catch (e: any) {
        await ref.set({ socket_apply_error: String(e?.message || e), socket_apply_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      }
    }

    return res.json({ ok: true, id, status: "approved", socket_job_id: socket_job_id || null, socket_apply });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const denyOrchestratorRequest = functions.https.onRequest(async (req, res) => {
  try {
    const u = await requireUser(req);
    if (!u.ok) return res.status(u.status).json({ ok: false, message: u.message });
    const a = await requireAdmin(u.decoded);
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });
    const uid = u.decoded.uid || u.decoded.user_id || "";
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });

    const id = String(req.body?.id || "").trim();
    const reason = String(req.body?.reason || "").trim();
    if (!id) return res.status(400).json({ ok: false, error: "missing_id" });

    const ref = db.collection("orchestrator_requests").doc(id);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ ok: false, error: "not_found" });

    const data = snap.data() || {};
    const socket_job_id = String((data as any).socket_job_id || "").trim();
    // Mechanical owner approval token (placeholder). In prod, this becomes a panel-issued signed token.
    const ownerApprovalToken = require("crypto").randomBytes(16).toString("hex");

    await ref.set({
      status: "denied",
      denied_at: admin.firestore.FieldValue.serverTimestamp(),
      denied_by: uid,
      denied_reason: reason || null,
    }, { merge: true });

    await db.collection("decision_log").add({
      kind: "orchestrator_request",
      request_id: id,
      action: "denied",
      by: uid,
      reason: reason || null,
      at: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({ ok: true, id, status: "denied" });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const setSeatLock = functions.https.onRequest(async (req, res) => {
  try {
    const u = await requireUser(req);
    if (!u.ok) return res.status(u.status).json({ ok: false, message: u.message });
    const a = await requireAdmin(u.decoded);
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });
    const uid = u.decoded.uid || u.decoded.user_id || "";
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });

    const role = String(req.body?.role || "").trim();
    const taskType = String(req.body?.taskType || "").trim();
    const provider = String(req.body?.provider || "").trim();
    const is_locked = !!req.body?.is_locked;

    if (!role || !taskType) return res.status(400).json({ ok: false, error: "missing_role_or_taskType" });

    const key = `${role}__${taskType}`;
    await db.collection("seat_locks").doc(key).set({
      role, taskType,
      is_locked,
      provider: provider || null,
      updated_at: admin.firestore.FieldValue.serverTimestamp(),
      updated_by: uid,
    }, { merge: true });

    return res.json({ ok: true, key, role, taskType, is_locked, provider: provider || null });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const listArtifacts = functions.https.onRequest(async (req, res) => {
  try {
    const u = await requireUser(req);
    if (!u.ok) return res.status(u.status).json({ ok: false, message: u.message });
    const a = await requireAdmin(u.decoded);
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });
    const uid = u.decoded.uid || u.decoded.user_id || "";
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });

    const scope = String(req.body?.scope || "").trim();
    let q: any = db.collection("spider_runs");
    if (scope) q = q.where("scope_name", "==", scope);
    q = q.orderBy("requested_at", "desc").limit(50);

    const snap = await q.get();
    const runs = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) }));
    return res.json({ ok: true, runs });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});

export const getGovernanceHealth = functions.https.onRequest(async (req, res) => {
  try {
    const u = await requireUser(req);
    if (!u.ok) return res.status(u.status).json({ ok: false, message: u.message });
    const a = await requireAdmin(u.decoded);
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });
    const uid = u.decoded.uid || u.decoded.user_id || "";
    if (!a.ok) return res.status(a.status).json({ ok: false, message: a.message });

    const [providers, locks, security, canary, anomaly] = await Promise.all([
      db.collection("provider_registry").get(),
      db.collection("seat_locks").get(),
      db.collection("system_state").doc("security_config").get(),
      db.collection("runtime_config").doc("canary_routing").get(),
      db.collection("runtime_config").doc("anomaly_thresholds").get(),
    ]);

    const onlineProviders = providers.docs.filter(d => (d.data() as any)?.status === "online").length;
    const degradedProviders = providers.docs.filter(d => (d.data() as any)?.status === "degraded").length;

    const lockedSeats = locks.docs.filter(d => (d.data() as any)?.is_locked).length;

    return res.json({
      ok: true,
      provider_registry: { total: providers.size, online: onlineProviders, degraded: degradedProviders },
      seat_locks: { total: locks.size, locked: lockedSeats },
      security_config: security.exists ? security.data() : null,
      canary_routing: canary.exists ? canary.data() : null,
      anomaly_thresholds: anomaly.exists ? anomaly.data() : null,
      server_time: new Date().toISOString(),
    });
  } catch (e: any) {
    return res.status(500).json({ ok: false, error: e?.message || "unknown" });
  }
});
