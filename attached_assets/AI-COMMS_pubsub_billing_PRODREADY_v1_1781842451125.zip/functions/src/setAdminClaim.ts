import { onCall, HttpsError } from "firebase-functions/v2/https";
import { admin, db } from "./firebaseAdmin";
import crypto from "crypto";

async function isAdmin(uid: string): Promise<boolean> {
  const snap = await db.collection("admins").doc(uid).get();
  return snap.exists;
}

async function getSecurityConfig(): Promise<any | null> {
  const snap = await db.collection("system_state").doc("security_config").get();
  return snap.exists ? snap.data() : null;
}

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

/**
 * Owner/Admin gated admin-claim setter.
 * Callable body: { uid: string, makeAdmin: boolean, ownerPin?: string }
 *
 * Authorization rules:
 * - If caller is already in /admins/{uid}: allowed
 * - Else if caller uid matches system_state/security_config.owner_uid AND sha256(ownerPin) matches owner_pin_hash: allowed
 */
export const setAdminClaim = onCall({ region: "us-central1" }, async (req) => {
  if (!req.auth?.uid) throw new HttpsError("unauthenticated", "Login required.");

  const callerUid = req.auth.uid;
  const targetUid = String(req.data?.uid || "").trim();
  const makeAdmin = !!req.data?.makeAdmin;
  const ownerPin = String(req.data?.ownerPin || "").trim();

  if (!targetUid) throw new HttpsError("invalid-argument", "Missing uid");

  const sec = await getSecurityConfig();
  const ownerUid = String(sec?.owner_uid || "").trim();
  const ownerPinHash = String(sec?.owner_pin_hash || "").trim();

  const callerIsAdmin = await isAdmin(callerUid);
  const callerIsOwner = ownerUid && callerUid === ownerUid;
  const ownerPinOk = callerIsOwner && ownerPinHash && ownerPin && sha256(ownerPin) === ownerPinHash;

  if (!callerIsAdmin && !ownerPinOk) {
    throw new HttpsError("permission-denied", "Admin or Owner PIN required.");
  }

  await admin.auth().setCustomUserClaims(targetUid, { admin: makeAdmin });

  // Keep /admins collection in sync (optional but helpful for rules + dashboard)
  if (makeAdmin) {
    await db.collection("admins").doc(targetUid).set({ granted_at: new Date(), granted_by: callerUid }, { merge: true });
  } else {
    await db.collection("admins").doc(targetUid).delete().catch(() => {});
  }

  await db.collection("system_events").add({
    type: "admin_claim_changed",
    at: new Date(),
    actor_uid: callerUid,
    target_uid: targetUid,
    admin: makeAdmin,
    owner_gate_used: ownerPinOk && !callerIsAdmin,
  });

  return { ok: true, uid: targetUid, admin: makeAdmin };
});
