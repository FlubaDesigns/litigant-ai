import { admin, db } from "./firebaseAdmin";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { defineSecret } from "firebase-functions/params";
const RESEND_API_KEY = defineSecret("RESEND_API_KEY");
const AICOMMS_FROM_EMAIL = defineSecret("AICOMMS_FROM_EMAIL");
const AICOMMS_ADMIN_EMAIL = defineSecret("AICOMMS_ADMIN_EMAIL");
const PUBLIC_SITE_BASE_URL = defineSecret("PUBLIC_SITE_BASE_URL");

async function sendResendEmail(args: { to: string; subject: string; html: string; from: string }) {
  const resp = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY.value()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: args.from,
      to: [args.to],
      subject: args.subject,
      html: args.html,
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Resend error (${resp.status}): ${text}`);
  }

  return resp.json();
}

export const onLeadCreated = onDocumentCreated(
  {
    region: "us-central1",
    document: "leads/{leadId}",
    secrets: [RESEND_API_KEY, AICOMMS_FROM_EMAIL, AICOMMS_ADMIN_EMAIL, PUBLIC_SITE_BASE_URL],
  },
  async (event) => {
    const leadId = event.params.leadId as string;
    const snap = event.data;
    if (!snap) return;

    const lead = snap.data() as any;

    const clientEmail = String(lead?.email || "").trim();
    const clientName = String(lead?.name || "").trim();
    const company = String(lead?.company || "").trim();
    const tier = String(lead?.tier || "audit").trim();

    if (!clientEmail) {
      await db.collection("email_outbox").add({
        kind: "lead_created",
        leadId,
        status: "skipped_missing_client_email",
        created_at: admin.firestore.FieldValue.serverTimestamp(),
      });
      return;
    }

    const fromEmail = AICOMMS_FROM_EMAIL.value();
    const adminEmail = AICOMMS_ADMIN_EMAIL.value();
    const baseUrl = (PUBLIC_SITE_BASE_URL.value() || "").replace(/\/$/, "");

    const checkoutUrl = baseUrl
      ? `${baseUrl}/checkout?leadId=${encodeURIComponent(leadId)}&email=${encodeURIComponent(clientEmail)}`
      : "";

    const adminSubject = `New AI-COMMS lead (${tier}) — ${company || clientEmail}`;
    const adminHtml = `
      <div style="font-family:Arial,sans-serif;line-height:1.5">
        <h2 style="margin:0 0 10px">New Lead Submitted</h2>
        <p style="margin:0 0 6px"><b>Lead ID:</b> ${leadId}</p>
        <p style="margin:0 0 6px"><b>Tier:</b> ${tier}</p>
        <p style="margin:0 0 6px"><b>Name:</b> ${clientName || "(not provided)"}</p>
        <p style="margin:0 0 6px"><b>Company:</b> ${company || "(not provided)"}</p>
        <p style="margin:0 0 6px"><b>Email:</b> ${clientEmail}</p>
        ${lead?.ai_goal ? `<p style="margin:10px 0 0"><b>AI Goal:</b><br/>${String(lead.ai_goal).replace(/</g, "&lt;")}</p>` : ""}
        ${checkoutUrl ? `<p style="margin:12px 0 0"><b>Checkout link:</b> <a href="${checkoutUrl}">${checkoutUrl}</a></p>` : ""}
      </div>
    `;

    const clientSubject = `We received your AI-COMMS request — next step`;
    const clientHtml = `
      <div style="font-family:Arial,sans-serif;line-height:1.6">
        <h2 style="margin:0 0 10px">You’re in.</h2>
        <p style="margin:0 0 10px">
          Thanks${clientName ? `, ${clientName}` : ""}. We received your request for <b>${tier}</b>.
        </p>
        <p style="margin:0 0 10px">
          Next step is checkout so we can begin processing your audit and deliverables.
        </p>

        ${
          checkoutUrl
            ? `<p style="margin:0 0 14px">
                 <a href="${checkoutUrl}" style="display:inline-block;padding:10px 14px;border-radius:10px;text-decoration:none;background:#4f46e5;color:#fff;font-weight:700">
                   Continue to Checkout
                 </a>
               </p>
               <p style="margin:0 0 10px;font-size:12px;opacity:.8">
                 If the button doesn’t work, copy/paste: ${checkoutUrl}
               </p>`
            : `<p style="margin:0 0 10px;font-size:12px;opacity:.8">
                 (Checkout link unavailable — operator will contact you.)
               </p>`
        }

        <hr style="border:none;border-top:1px solid #eee;margin:16px 0" />
        <p style="margin:0;font-size:12px;opacity:.8">AI-COMMS • Intuitive Guardrails</p>
      </div>
    `;

    try {
      const adminSend = adminEmail
        ? await sendResendEmail({ to: adminEmail, subject: adminSubject, html: adminHtml, from: fromEmail })
        : null;

      const clientSend = await sendResendEmail({
        to: clientEmail,
        subject: clientSubject,
        html: clientHtml,
        from: fromEmail,
      });

      await db.collection("email_outbox").add({
        kind: "lead_created",
        leadId,
        status: "sent",
        admin_message_id: adminSend?.id || null,
        client_message_id: clientSend?.id || null,
        to_admin: adminEmail || null,
        to_client: clientEmail,
        created_at: admin.firestore.FieldValue.serverTimestamp(),
      });

      await db.collection("leads").doc(leadId).set(
        {
          email_status: "sent",
          email_sent_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } catch (err: any) {
      await db.collection("email_outbox").add({
        kind: "lead_created",
        leadId,
        status: "error",
        error: err?.message || String(err),
        created_at: admin.firestore.FieldValue.serverTimestamp(),
      });

      await db.collection("leads").doc(leadId).set(
        {
          email_status: "error",
          email_error: err?.message || String(err),
          email_error_at: admin.firestore.FieldValue.serverTimestamp(),
        },
        { merge: true }
      );

      throw err;
    }
  }
);