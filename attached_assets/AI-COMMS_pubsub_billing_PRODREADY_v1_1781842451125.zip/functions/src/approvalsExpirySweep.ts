import { admin, db } from "./firebaseAdmin";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { logEvent } from "./lib/logEvent";

/**
 * Expire pending approvals whose expires_at has passed.
 * Keeps the approval queue clean and enforces safety timeouts.
 */
export const approvalsExpirySweep = onSchedule(
  {
    schedule: "every 15 minutes",
    timeZone: "America/New_York",
    region: "us-central1",
  },
  async () => {
    const now = admin.firestore.Timestamp.now();

    const snap = await db
      .collection("approvals")
      .where("status", "==", "pending")
      .where("expires_at", "<=", now)
      .limit(200)
      .get();

    if (snap.empty) return;

    const batch = db.batch();
    const expiredIds: string[] = [];

    snap.docs.forEach((d) => {
      expiredIds.push(d.id);
      batch.set(
        d.ref,
        {
          status: "expired",
          updated_at: admin.firestore.FieldValue.serverTimestamp(),
          decision: {
            decided_at: admin.firestore.FieldValue.serverTimestamp(),
            decided_by_uid: "system",
            decision: "expired",
            comment: "Expired automatically by approvalsExpirySweep.",
          },
        },
        { merge: true }
      );
    });

    await batch.commit();

    await logEvent(
      "approvals_expired",
      { count: expiredIds.length, approvalIds: expiredIds.slice(0, 50) },
      { uid: "system" }
    );
  }
);
