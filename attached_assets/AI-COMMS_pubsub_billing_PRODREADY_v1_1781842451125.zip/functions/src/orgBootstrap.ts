import { onUserCreated as onUserCreatedAuth } from "firebase-functions/v2/auth";
import { admin, db } from "./firebaseAdmin";

/**
 * Multi-tenant bootstrap:
 * - Creates an organization for each new user by default.
 * - Creates users/{uid} profile with orgId + role.
 *
 * This is the scalable SaaS baseline. You can later add invites/team membership.
 */
export const onUserCreated = onUserCreatedAuth({ region: "us-central1" }, async (event) => {
  const user = event.data;
  if (!user?.uid) return;

  const uid = user.uid;
  const userRef = db.collection("users").doc(uid);
  const existing = await userRef.get();
  if (existing.exists) return; // don't clobber

  const orgRef = db.collection("organizations").doc();
  const now = admin.firestore.FieldValue.serverTimestamp();

  const name = (user.displayName || user.email || "New Organization").toString();

  await orgRef.set({
    name,
    plan: "free",
    canonVersion: "v1",
    createdAt: now,
    updatedAt: now,
  });

  await userRef.set({
    orgId: orgRef.id,
    role: "owner",
    email: user.email || null,
    createdAt: now,
    updatedAt: now,
    lastActiveAt: now,
  });

  // Optional custom claim (orgId) for faster authz later
  try {
    await admin.auth().setCustomUserClaims(uid, { orgId: orgRef.id });
  } catch {
    // ignore
  }
});
