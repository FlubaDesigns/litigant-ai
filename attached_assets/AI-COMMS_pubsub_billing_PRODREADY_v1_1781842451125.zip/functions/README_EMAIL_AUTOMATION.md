STATUS: IMPLEMENTATION NOTE
VERSION: 1
PURPOSE: How to configure lead email automation (Resend) for aicomms-site functions.

# Lead Email Automation (Resend)

This app sends two emails automatically when a new lead is created:

1) Confirmation email → lead email
2) Notification email → admin email

Trigger:
- Firestore onCreate: leads/{leadId}

Function:
- onLeadCreated (functions/src/index.ts)

---

## Required Configuration

### 1) Set the Resend API key as a Firebase Functions v2 secret
Command:

firebase functions:secrets:set RESEND_API_KEY

---

### 2) Set runtime parameters for sender + admin destination

Set these in your deployment environment:

AICOMMS_FROM_EMAIL="Intuitive <noreply@YOURDOMAIN.COM>"
AICOMMS_ADMIN_EMAIL="you@YOURDOMAIN.COM"

---

## Firestore Writeback

After sending, the function writes to the lead doc:

# AI-COMMS — Email Automation (Resend)

This app uses Resend for deterministic, auditable email sends.

## What exists (authoritative)

### 1) Lead-created automation (Firestore trigger)
- Function: `onLeadCreated`
- Trigger: `leads/{leadId}` document created
- Sends:
  - Admin notification (AICOMMS_ADMIN_EMAIL)
  - Client confirmation email with checkout link
- Logs:
  - Writes a doc to `email_outbox` for evidence
  - Adds `leads/{leadId}.email_automation.lead_created_sent_at`

### 2) Proposal / Contract send triggers
- Functions:
  - `sendProposalOnApproval`
  - `sendContractOnApproval`
- These send documents when your admin approval workflow triggers them.

### 3) Reminder engine
- Function: `lifecycleReminder`
- Uses Resend for reminders (where configured).

## Required Secrets (Firebase Functions)
You must set these in Firebase Functions Secrets:

- `RESEND_API_KEY`
- `AICOMMS_FROM_EMAIL`
- `AICOMMS_ADMIN_EMAIL`
- `PUBLIC_SITE_BASE_URL`

Optional:
- additional template/tier knobs as you expand.

## Evidence-first
All email sends must log to:
- `email_outbox`

This prevents “it says it sent, but it didn’t” problems.

END:
- lead_email_sent (bool)
- admin_email_sent (bool)
- lead_email_sent_at (timestamp)
- admin_email_sent_at (timestamp)
- lead_email_error (string)
- admin_email_error (string)
- updated_at (timestamp)

END