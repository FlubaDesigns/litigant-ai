import { describe, it, expect } from "vitest";
import { normalizeTier, effectiveTier, hasCapability, assertCapability } from "../src/tierPolicy";

describe("tierPolicy", () => {
  it("normalizeTier maps inputs safely", () => {
    expect(normalizeTier("PRO")).toBe("pro");
    expect(normalizeTier("enterprise")).toBe("enterprise");
    expect(normalizeTier("")).toBe("free");
    expect(normalizeTier(undefined)).toBe("free");
    expect(normalizeTier("unknown-tier")).toBe("free");
  });

  it("effectiveTier respects tier_override when present", () => {
    const lead = { tier: "free", tier_override: "pro" };
    expect(effectiveTier(lead)).toBe("pro");
  });

  it("hasCapability enforces capability matrix", () => {
    const freeLead = { tier: "free" };
    expect(hasCapability(freeLead, "client_portal")).toBe(true);
    expect(hasCapability(freeLead, "audit_generate")).toBe(false);

    const proLead = { tier: "pro" };
    expect(hasCapability(proLead, "contract_send")).toBe(true);
  });

  it("assertCapability returns ok boolean", () => {
    const lead = { tier: "audit" };
    expect(assertCapability(lead, "audit_generate")).toEqual({ ok: true, tier: "audit" });
    expect(assertCapability(lead, "proposal_send")).toEqual({ ok: false, tier: "audit" });
  });
});
