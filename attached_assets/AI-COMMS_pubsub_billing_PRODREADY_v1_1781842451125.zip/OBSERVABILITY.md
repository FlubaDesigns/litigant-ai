# Observability & Incident Response (Step 4)

This project uses **two layers** of visibility:

1) **Cloud Logs (Firebase Functions / GCP Logging)**
2) **Firestore “ops telemetry” collections** for lightweight Admin dashboards (no external tooling required)

## Core Signals (the 6 that matter)

1. **Stripe webhook failures**
   - Source: `ops_signals` kind `stripe_webhook_sig_fail` / `stripe_webhook_processed_fail`
2. **Checkout success rate**
   - Source: Stripe dashboard + `system_events` / `ops_signals`
3. **Email send success rate**
   - Source: `ops_signals` kind `email_send_ok` / `email_send_fail`
4. **Function error rate**
   - Source: Cloud logs + `ops_errors` + `ops_signals` kind `function_error`
5. **Firestore permission denied spikes**
   - Source: Cloud logs (permission-denied) + optional `ops_signals` kind `firestore_permission_denied`
6. **Latency (p95 function execution time)**
   - Source: Cloud logs / trace; can be added later as a rollup

## Firestore Collections Added/Used

- `ops_signals` — append-only events (safe, no secrets)
- `ops_signal_rollups/{YYYYMMDDHH}` — hourly cheap dashboards
- `ops_errors` — critical failures (already used)
- `system_events` — general system logging (already used)

## Recommended Admin Views

1) **Last 24h rollup**
- Read last 24 docs from `ops_signal_rollups` and render totals by kind.

2) **Latest failures**
- Query `ops_signals` where `ok == false`, order by created_at desc.

3) **Email health**
- Show:
  - queued count (from emailQueueHealth)
  - last hour send_ok vs send_fail

4) **Stripe health**
- Show:
  - verified webhooks vs failures
  - processed_ok vs processed_fail

## Cloud Logging Queries (copy/paste)

### Stripe webhook errors
resource.type="cloud_function"
severity>=ERROR
textPayload:"stripeWebhook"

### Email outbox failures
resource.type="cloud_function"
severity>=ERROR
textPayload:"email_outbox_send_failed"

### Permission denied spikes
severity>=ERROR
("PERMISSION_DENIED" OR "permission-denied")

## Alerting

`functions/src/systemAlerts.ts` runs hourly and emails the owner when:
- Stripe failures >= 1 (last hour)
- Ops errors >= 10 (last hour)
- Email DLQ >= 5

Tune thresholds as traffic grows.
