# Firestore: project_intake_packets (Website-Layer Schema Draft)

> This file is provided as **copy/paste** reference.  
> Website layer currently submits a structured object (`projectIntakePacket`) alongside the existing `submitEvidencePack` payload.

## Collection
`project_intake_packets`

## Fields (copy code)

```txt
recommendedTier
```
```txt
number
```
```txt
System-recommended autonomy tier (0–3) based on declared risk posture + approval structure.
```

```txt
selectedTier
```
```txt
number
```
```txt
Client-selected autonomy tier (0–3) used for delivery behavior inside scoped lanes.
```

```txt
tierOverrideFlag
```
```txt
boolean
```
```txt
True if selectedTier != recommendedTier; used to trigger additional acknowledgement + logging.
```

```txt
tierOverrideAcknowledgment
```
```txt
string
```
```txt
Typed acknowledgement text required when overriding the recommended tier.
```

```txt
tierOverrideTimestamp
```
```txt
string
```
```txt
ISO timestamp when the override was acknowledged.
```

```txt
autonomyChangeHistory
```
```txt
array
```
```txt
Append-only history of autonomy tier changes (from, to, at, note). All changes versioned.
```
