
# Production Launch Checklist

✔ Firestore rules reviewed
✔ Stripe webhook signature verified
✔ Rate limits enabled
✔ Email queue dead-letter active
✔ Terms & refund policy visible
✔ Staging tested
✔ Full user path tested:
   RiskScan → Pricing → Checkout → Onboarding → Dashboard
✔ Weekly reassurance email scheduled
✔ Monitoring alerts enabled

If all are green, launch is authorized.
