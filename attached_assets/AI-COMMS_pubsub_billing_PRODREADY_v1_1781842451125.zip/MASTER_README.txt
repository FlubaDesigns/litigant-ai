AI-COMMS MASTER BUILD

This package contains:
1) Website Layer (STACK-COMPAT v4 with Brain Enforcement Bridge)
2) Complete Claude Handoff Packet (under /CLAUDE_HANDOFF_PACKET)

Website Layer = production runtime foundation.
Claude Handoff Packet = build specification for pricing, governance lock,
Stripe integration, approval queue, and enforcement wiring.

Nothing has been removed.
Website layer remains intact.
Handoff documentation added without overwriting runtime files.

Deployment order:
1) Review /CLAUDE_HANDOFF_PACKET
2) Implement pricing + webhook + governance versioning
3) Wire Brain enforcement gate
4) Test in emulator
5) Deploy
