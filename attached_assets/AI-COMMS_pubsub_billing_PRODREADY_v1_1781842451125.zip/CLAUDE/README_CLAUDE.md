# CLAUDE — AI-COMMS PRODUCTION WIRING CHECKLIST (ONE SOURCE OF TRUTH)

NOTE: Read `HARDENING_NOTES.md` (root) and `CLAUDE/DEPLOY_ADDENDUM_HARDENING.md` for hardened-build deltas.

This ZIP is the **only** canonical project tree. Do not create parallel folders.
Work in the existing `/web` and `/functions` folders.

## GOAL
Dashboard-controlled pricing (DFY/DYS + tiers + add-ons) -> Stripe checkout (Price IDs) -> Stripe webhook mirrors subscription -> issues append-only governance profile -> org pointer updated -> Brain/Socket uses governance envelope -> approvals queue for escalations.

---

## 1) FIREBASE PROJECT SETUP (CONSOLE)
1. Confirm Firebase project exists and you have Owner access.
2. Enable Authentication (Email/Password or whatever you use).
3. Enable Firestore Database (production mode).
4. Enable Cloud Functions (Blaze plan for Stripe webhooks).

---

## 2) FIRESTORE: CREATE ADMIN
Admin is defined as: a document at `/admins/{uid}` exists.

### Steps
1. Create a user (your account) in Firebase Auth.
2. Find your UID.
3. In Firestore, create:
   - Collection: `admins`
   - Document ID: your UID
   - Field: `created_at` (timestamp)

This unlocks `/admin/*` UI + admin-only callable functions.

---

## 3) FIRESTORE RULES
Deploy the rules from:
- `firestore.rules` (root of this ZIP)

Rules must allow:
- Public read pricing collections
- Admin write pricing collections
- Org owner/admin read subscriptions/governance_profiles/approvals
- Append-only governance_profiles versions
- Webhook/service writes subscriptions + governance_profiles

---

## 4) PRICING CONFIG SEED
Option A (preferred for first run): Run the admin callable seeder function if present:
- `seedPricing` callable (in `/functions`)

If not present or disabled, manually create the docs:
- `pricing_version/config`
- `pricing_modes/DFY`, `pricing_modes/DYS`
- tiers in `pricing_tiers/*`
- addons in `pricing_addons/*`

IMPORTANT:
You must populate Stripe Price IDs into:
- `pricing_tiers.{stripe_price_id_monthly, stripe_price_id_onboarding}`
- `pricing_addons.{stripe_price_id_monthly}`

---

## 5) STRIPE SETUP (STRIPE DASHBOARD)
Create Stripe Products + Prices:
- For each tier:
  - Monthly recurring Price ID (required)
  - Onboarding one-time Price ID (optional)
- For each add-on:
  - Monthly recurring Price ID

Then copy those Price IDs into Firestore pricing docs.

---

## 6) FUNCTIONS: REQUIRED SECRETS / ENV
Cloud Functions require these secrets (names may vary; check `/functions/src`):
- Stripe secret key
- Stripe webhook signing secret
- Socket base URL (Brain endpoint)
- Socket token/key (if used)
- SOCKET_APPROVAL_SHARED_SECRET (if approvals are created by Brain server-to-server)
- Resend key (if email used)

Set these using Firebase Functions secrets or env config per project conventions.

---

## 7) DEPLOY FUNCTIONS
From `/functions`:
- install deps
- build
- deploy

Confirm deployed endpoints:
- `createTieredCheckoutSession` (callable/https)
- `stripeWebhook` (https)
- `resolveApproval` (callable)
- `createApproval` (https, Bearer protected) — if included
- any scheduled expiry sweep — if included

---

## 8) WEB APP CONFIG
From `/web`:
- Ensure Firebase config is set (env vars or config file as used in this project)
- Ensure App Check setup matches the function requirements (if required)

Deploy hosting.

---

## 9) STRIPE WEBHOOK ROUTING
In Stripe:
- Add webhook endpoint URL (deployed `stripeWebhook`)
- Subscribe to events:
  - checkout.session.completed
  - customer.subscription.updated
  - customer.subscription.deleted
  - invoice.paid
  - invoice.payment_failed

---

## 10) END-TO-END TEST (EMULATOR FIRST)
1. Visit `/pricing` and confirm it loads from Firestore.
2. Visit `/admin/pricing` and toggle a tier active/inactive.
3. Publish bump and confirm `/pricing` updates.
4. Start checkout: select a tier -> call `createTieredCheckoutSession` -> Stripe URL returns.
5. Complete checkout in Stripe test mode.
6. Confirm Firestore writes:
   - `subscriptions/{orgId}` updated
   - `orgs/{orgId}` snapshot updated
   - `governance_profiles/{orgId}/versions/{versionId}` created (append-only)
   - `orgs.active_governance_profile_version` points to latest
7. Trigger an approval-required action (or simulate by calling `createApproval`).
8. Confirm `/admin/approvals` shows it and resolve it.

---

## 11) BRAINSIDE (SOCKET) WIRING REQUIREMENT
Brain/Socket must:
- Read `orgs.active_governance_profile_version`
- Fetch `governance_profiles/{orgId}/versions/{versionId}`
- Include it in every job envelope
- Enforce autonomy/patch/logging/escalation rules via ONE gate
- Create approvals when gate requires, using `createApproval` endpoint (if used)

---

## DELIVERABLES REQUIRED FROM CLAUDE
1. Screenshot/proof: pricing reads on `/pricing`.
2. Screenshot/proof: pricing edits/publish in `/admin/pricing`.
3. Firestore proof: governance profile version issuance after Stripe checkout.
4. Proof: approvals queue created + resolved.
5. List of secrets configured and where.
6. Final “Production Launch Checklist” confirmed.
