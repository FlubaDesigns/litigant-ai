# Deploy Addendum (Hardened Build)

## New / important environment variables
- `BRAIN_SUBMIT_RATE_WINDOW_SEC` (default: 60)
- `BRAIN_SUBMIT_RATE_MAX` (default: 8)

Ensure these are set in:
- Firebase Functions config (or env vars if using 2nd gen)

## Pub/Sub
Confirm the topic used by `submitBrainJob.ts` exists and matches the Brain worker subscription.

## Stripe
Confirm:
- webhook signing secret set
- webhook handler remains idempotent

## Post-deploy validation
- Trigger a test checkout or webhook replay
- Confirm only one workflow is created (idempotency)
- Confirm a Brain job is published with `schemaVersion: brain_job_v1`
