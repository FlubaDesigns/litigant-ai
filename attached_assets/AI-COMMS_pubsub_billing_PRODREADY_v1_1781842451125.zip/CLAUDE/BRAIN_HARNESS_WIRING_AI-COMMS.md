# AI-COMMS → Brain Harness Wiring (Push Mode) — Claude Instructions

## Goal
Wire AI-COMMS so that **when HARNESS_MODE=brain**, AI-COMMS **pushes intents to Brain** and receives results back, while still remaining **fully usable standalone** when HARNESS_MODE=local (unplug/orphan mode).

This wiring must preserve the architecture:
- Fluba talks only to Brain (control endpoints)
- AI-COMMS talks only to Brain (intent push / result receive)
- Conscience is called by Brain, not by AI-COMMS
- No direct AI-COMMS ↔ Conscience coupling

---

## Current State (what’s already in the zip)
A harness scaffold exists here:

- `functions/src/harness_prep/HarnessProvider.ts`

It supports two modes:
- `HARNESS_MODE=local`  → existing in-plane behavior
- `HARNESS_MODE=brain`  → intended to call Brain ingress: `POST {BRAIN_BASE_URL}/brain/intents`

**Problem:** there are currently **no call sites** (nothing imports/uses it), so AI-COMMS is not actually connected to Brain yet.

---

## Required Wiring Changes (do these in one clean pass)

### 1) Decide the “Intent Ingress Points” in AI-COMMS
Find where AI-COMMS currently starts work (user requests, jobs, billing events). Typical ingress points:
- HTTP endpoints in `functions/src` (Express/https functions)
- Callable functions or REST routes handling “start audit/build/govern”
- Any Pub/Sub-triggered job kickoff (billing/usage events)
- Any API route that currently runs orchestration locally

**These are the places that must call the harness.**

### 2) Create a single helper: submitIntent(intent)
Create a thin wrapper in the functions layer that always routes through HarnessProvider.

**Example file:**
- `functions/src/harness/submitIntent.ts` (new)

Pseudo:
```ts
import { HarnessProvider } from "../harness_prep/HarnessProvider";

export async function submitIntent(intent: any) {
  const hp = new HarnessProvider();
  return hp.submitIntent(intent); // implement or adapt to your provider API
}
```

If HarnessProvider doesn’t expose a clean `submitIntent`, add it there rather than scattering logic.

### 3) Replace local-start logic with conditional harness push
At each ingress point:
- Build an `intent` object (schema below)
- Call `submitIntent(intent)`
- If `HARNESS_MODE=local` it should keep current behavior
- If `HARNESS_MODE=brain` it should push to Brain and return Brain’s response (jobId, status, etc.)

**Hard rule:** no direct calls to Conscience from AI-COMMS.

### 4) Support async completion (recommended)
Brain workflows may be multi-step. AI-COMMS should handle one of these patterns:

**Pattern A (simple):** “submit and poll”
- Submit intent → Brain returns `{ jobId }`
- AI-COMMS polls `GET /brain/jobs/:jobId` until done (requires Brain endpoint)
- Then render results

**Pattern B (better):** “submit and callback”
- AI-COMMS includes `callbackUrl` in the intent
- Brain calls back with final artifact refs/results
- AI-COMMS stores results and updates UI

Choose A if you want the fastest integration; choose B for smoother UX.

---

## Intent Envelope (Push Contract)
Use a consistent envelope so Brain can route and audit.

Minimum recommended fields:
```json
{
  "schemaVersion": "brain_intent_v1",
  "planeId": "ai-comms",
  "requestId": "uuid-or-ulid",
  "createdAtISO": "2026-03-02T00:00:00.000Z",
  "actor": {
    "uid": "firebaseUidOrAnon",
    "role": "user|admin"
  },
  "action": "start_billing_cycle|audit_governance|build_workflow|...",
  "payload": {
    "...": "plane-specific data (no secrets)"
  },
  "context": {
    "appVersion": "AI-COMMS v4",
    "channel": "web|pubsub|api"
  }
}
```

**No secrets in payload.** Keys/credentials belong in Brain/Fluba knobs, not inside plane events.

---

## Environment Variables (AI-COMMS deploy)
Set in Cloud Run / Functions / Firebase env (wherever this plane is hosted):

- `HARNESS_MODE=brain`  (or `local` for orphan mode)
- `BRAIN_BASE_URL=https://<brain-host>`
- `PLANE_ID=ai-comms` (optional but useful)
- `BRAIN_AUTH_MODE=idtoken|service_token` (optional)
- `BRAIN_SERVICE_TOKEN=...` (if using a service token approach)

---

## Auth (required for production)
AI-COMMS must authenticate to Brain.

Two clean options:

### Option 1: Firebase ID Token (user context)
If the user is signed in:
- AI-COMMS obtains Firebase ID token
- Sends `Authorization: Bearer <idToken>` to Brain
- Brain verifies token and checks admin claim when needed

### Option 2: Service-to-service token (recommended for plane backends)
- AI-COMMS uses a service token (stored as secret env var)
- Sends `Authorization: Bearer <serviceToken>`
- Brain verifies against allowlist or secret

**Do not ship with no auth.**

---

## Unplug / Orphan Mode Requirement (non-negotiable)
AI-COMMS must run without Brain by flipping:

- `HARNESS_MODE=local`

In local mode:
- AI-COMMS uses its internal flow exactly as before
- No Brain calls required

This preserves your “sellable plane” requirement.

---

## Tests / Verification Checklist
After wiring, verify:

1) With `HARNESS_MODE=local`, everything works as before.
2) With `HARNESS_MODE=brain` and valid `BRAIN_BASE_URL`:
   - AI-COMMS submits intent successfully
   - Brain logs jobId
   - Brain calls Conscience gate (Brain responsibility)
   - Result can be retrieved and displayed in AI-COMMS
3) Auth failures are rejected (401/403), not silently allowed.
4) No secrets are sent in intents.
5) CORS configured only as needed (if browser calls Brain directly; prefer server-to-server).

---

## Deliverables Claude Should Produce
- Updated functions code (wiring HarnessProvider into real call sites)
- One README section: “Harness Mode (brain/local)”
- Deployed env vars + secrets setup notes
- Quick runbook: how to flip planes between brain/local
