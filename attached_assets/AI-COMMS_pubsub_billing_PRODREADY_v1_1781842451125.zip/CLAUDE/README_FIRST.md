# AI‑COMMS Billing + Pub/Sub Bridge — Claude Handoff (READ FIRST)
Updated: 2026-03-02

This zip is the **AI‑COMMS revenue + workflow dispatch** layer.
It receives Stripe events, manages entitlement, and **publishes Brain jobs** to Pub/Sub.
It also ingests Brain callbacks and writes results to Firestore.

## What changed in this hardened build
- Safer signature comparison (timingSafeEqual length guard)
- Per‑user submit throttling (basic abuse guard)
- Pub/Sub job schema stamping (`schemaVersion: brain_job_v1`)
- `HARDENING_NOTES.md` added/updated (root)

## Read these files (in order)
1) `CLAUDE/README_CLAUDE.md` (existing) — overall wiring
2) `HARDENING_NOTES.md` (root) — new knobs
3) `BRAIN_PUBSUB_BRIDGE.md` — topic/sub expectations
4) `functions/src/submitBrainJob.ts` — publisher
5) `functions/src/ingestBrainResult.ts` — callback ingest

## Deploy quick start
- Firebase project configured in `.firebaserc`
- Deploy:
  - rules/indexes
  - functions
  - hosting (if applicable)

See: `CLAUDE/DEPLOY_ADDENDUM_HARDENING.md` for the delta steps introduced by hardening.


---

## Zero-confusion commands
Read: `CLAUDE/DEPLOY_COMMAND_SHEET.md`
