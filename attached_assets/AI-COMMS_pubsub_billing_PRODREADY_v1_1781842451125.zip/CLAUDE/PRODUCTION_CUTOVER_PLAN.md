# PRODUCTION CUTOVER PLAN (v1)

This document defines the exact order to move from development to live production
while preserving unplug safety and avoiding cascade failures.

------------------------------------------------------------
PHASE 0 – PRE-CHECKS
------------------------------------------------------------
- Verify all services build locally
- Verify HARNESS_MODE=local works end-to-end for each plane
- Confirm Firestore rules are locked
- Confirm Stripe webhooks validate signatures (AI-COMMS)

------------------------------------------------------------
PHASE 1 – DEPLOY CONTROL PLANE (Fluba Project)
------------------------------------------------------------
1) Deploy Conscience (AI-Guardrails)
   - Confirm POST /conscience/evaluate works
   - Test with sample payload

2) Deploy Brain API
   - Confirm /healthz returns 200
   - Set CONSCIENCE_EVAL_URL to Conscience endpoint

3) Deploy Brain Worker
   - Attach to Pub/Sub topic
   - Configure Dead Letter Queue
   - Set max delivery attempts

4) Smoke test Brain manually:
   - Send test intent
   - Verify Conscience decision
   - Verify job record created
   - Verify structured logs present

------------------------------------------------------------
PHASE 2 – DEPLOY FLUBA (Control Tower UI)
------------------------------------------------------------
1) Deploy Hosting + Auth
2) Set BRAIN_BASE_URL
3) Verify:
   - Knobs page loads
   - Incidents page loads
   - Approvals page loads

------------------------------------------------------------
PHASE 3 – PLANES (AI-COMMS FIRST)
------------------------------------------------------------
1) Deploy AI-COMMS with HARNESS_MODE=local
   - Confirm standalone operation works

2) Flip to HARNESS_MODE=brain (staging first)
   - Confirm intent routes to Brain
   - Confirm Conscience evaluation occurs
   - Confirm no local bypass execution

------------------------------------------------------------
PHASE 4 – GRADUAL GOVERNANCE ENABLEMENT
------------------------------------------------------------
1) Enable logging-only mode first (no blocking)
2) Enable requireApproval for high-risk intents only
3) Enable stricter rate limits
4) Enable fail-closed behavior once stable

------------------------------------------------------------
ROLLBACK STRATEGY
------------------------------------------------------------
- Planes: switch HARNESS_MODE back to local
- Brain: scale to zero if needed
- Conscience: disable endpoint (Brain must fail closed if configured)

------------------------------------------------------------
PRODUCTION COMPLETE WHEN:
------------------------------------------------------------
- All 6 must-pass gates in PROD_ACCEPTANCE_CHECKLIST.md are checked
- Smoke tests pass in staging and production
- Incident pipeline verified
- DLQ tested and working
