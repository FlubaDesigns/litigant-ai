# AI-COMMS Retail v1.2

- Web control panel wired to Socket endpoints (submit/get/apply/rollback)
- Artifact vault now reads from Socket job
- Approval queue approve endpoint triggers Socket apply when socket_job_id present
