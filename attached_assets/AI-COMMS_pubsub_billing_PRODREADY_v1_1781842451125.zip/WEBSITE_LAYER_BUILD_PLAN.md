# AI-COMMS — Website Layer Build Plan Implementation

This zip implements the requested **Website Layer Only** rebuild. It does **not** modify:
- Canon kernel
- Brain socket harness
- Runtime execution logic
- Cortex generation engine

## Implemented

1) Dual Entry Landing  
- Homepage now presents two paths:
  - 🔐 Audit & Govern My AI → `/intake/audit`
  - ⚙️ Build & Automate My Workflow → `/intake/build`

2) Adaptive Intake Engine (replaces static wizard)  
- Route: `/intake/:mode`
- Stages:
  - Stage A — Orientation
  - Stage B — Classification (governance / build / hybrid)
  - Stage C — Targeted follow-ups (guardrail capped)
- Guardrails enforced in `web/src/lib/intakeGuardrails.ts`

3) Evidence Intake (Wizard 2 rebuilt)  
- Route: `/evidence`
- Structured Evidence Pack UI with **file references only** (no uploads).
- Back-compat payload still sent to `submitEvidencePack`, with new structured packet included as `projectIntakePacket`.

4) Autonomy Tier System (Client control panel UI)  
- Tier 0–3 selector included in Evidence Intake (Wizard 2)
- Recommended tier computed from declared posture
- Override requires typed acknowledgment
- Risk delta UI + tier comparison + impact modal

5) Risk Delta UI Components  
- `RiskDeltaDisplay`
- `AutonomyImpactModal`
- `TierComparisonTable`

6) Owner Override Controls (Hidden Admin Layer)  
- Admin adds `OwnerOverrideControlsPanel`
- Website-only: logs admin actions to Firestore `admin_actions` (enforcement happens elsewhere)

7) Intake Guardrail Profile (Pre-Cortex)  
- Hardcoded constraints live only in website logic (no canon/brain/runtime changes)
