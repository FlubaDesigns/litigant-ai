Start here: `CLAUDE/README_FIRST.md`

That file points to the canonical wiring checklist (`CLAUDE/README_CLAUDE.md`) plus the hardened build notes.
