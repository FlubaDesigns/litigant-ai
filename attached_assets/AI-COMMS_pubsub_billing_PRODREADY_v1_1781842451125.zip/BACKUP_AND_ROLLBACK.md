# Backup & Rollback (Sprint 4)

## Firestore Backups
Use Google Cloud scheduled exports (recommended):
- Console: Firestore → Import/Export → Schedule export
- Destination: GCS bucket (staging + production separate)

## Stripe Reconciliation
This build includes:
- functions/src/reconcileStripeSubscriptions.ts (daily best-effort)
- functions/src/sweepGraceDowngrades.ts (daily downgrade after grace)

## Rollback
1) Keep previous zip (v14) ready.
2) Re-deploy functions from prior tag/zip.
3) Verify:
   - Stripe webhooks still validate
   - Checkout success still routes to onboarding

## Alerts
Set secret:
- ADMIN_ALERT_EMAIL
and keep:
- PUBLIC_SITE_BASE_URL
