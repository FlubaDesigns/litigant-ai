AI-COMMS — BUILDER (Owner) Folder
================================

Purpose
- This folder contains only what YOU (Owner) must do manually to deploy/run AI-COMMS.

Quick Start (Local)
1) Install deps
   - cd web && npm i
   - cd ../functions && npm i

2) Run web
   - cd web
   - npm run dev

3) Emulators (optional)
   - firebase emulators:start

Production Deploy (Firebase)
1) Set Firebase project
   - firebase use <your-project-id>

2) Deploy hosting + functions
   - firebase deploy

Required Secrets (Cloud Functions)
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- PUBLIC_SITE_BASE_URL
Optional:
- STRIPE_CURRENCY
- STRIPE_UNIT_AMOUNT_CENTS
- STRIPE_PRO_UNIT_AMOUNT_CENTS
- STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS
- STRIPE_EXPLORER_UNIT_AMOUNT_CENTS (defaults to 2500)

Explorer (Governance Credit)
- The /checkout?tier=explorer flow requires user sign-in (UID) so credits attach deterministically.
- Stripe webhook increments users/{userId}.creditBalance by 25 and enqueues a purchase email (all tiers).

Email (Resend)
Required Secrets:
- RESEND_API_KEY
- AICOMMS_FROM_EMAIL (e.g. "AI-COMMS <noreply@yourdomain.com>")
- AICOMMS_ADMIN_EMAIL (where admin alerts go)

App Check (Web)
- createCheckoutSession enforces App Check.
- Configure Firebase App Check for Web (reCAPTCHA v3) and set VITE_RECAPTCHA_V3_SITE_KEY.

Owner Notes
- Drift Scan entry page is: /drift-scan
- Pricing page includes Governance Credit card.

END
