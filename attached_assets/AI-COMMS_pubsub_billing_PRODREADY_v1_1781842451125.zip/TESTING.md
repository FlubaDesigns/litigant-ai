# Automated Tests (Step 1)

This repo now includes a minimal automated test harness:

## Functions tests
- Located in `functions/test/`
- Runner: Vitest
- Run:
  - `cd functions && npm i && npm test`

## Firestore rules tests
- Located in `tests/rules.test.mjs`
- Runner: Vitest + Firebase emulator exec
- Run from repo root:
  - `npm i`
  - `npm run test:rules`

## Run everything
- From repo root:
  - `npm i`
  - `npm run test:all`

Notes:
- Rules tests use `firebase emulators:exec --only firestore` to boot a local emulator and run vitest.
- This is intentionally small and focused; expand coverage around billing/webhooks/governance next.
