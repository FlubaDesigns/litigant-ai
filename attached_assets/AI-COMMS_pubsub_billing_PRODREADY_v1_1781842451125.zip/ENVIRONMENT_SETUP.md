
# Environment Separation

You must maintain two Firebase projects:

- aicomms-staging
- aicomms-production

Ensure:

- Separate Stripe keys
- Separate .env files
- Separate Firestore databases

Never deploy production from staging config.

Use:
firebase use staging
firebase deploy

firebase use production
firebase deploy
