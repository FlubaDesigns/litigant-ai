# HARDENING_NOTES (AI-COMMS Billing + Pub/Sub)
Date: 2026-03-02

Changes:
- ingestBrainResult: fixed timingSafeEqual length mismatch handling; improved signature fail logging.
- submitBrainJob: added best-effort per-user rate limiting (BRAIN_SUBMIT_RATE_WINDOW_SEC default 60, BRAIN_SUBMIT_RATE_MAX default 8).
- submitBrainJob: publish payload now includes schemaVersion + createdAtISO/publishedAtISO (keeps Firestore serverTimestamp in job record).

Recommended next hardening (infra):
- Pub/Sub topic/subscription DLQ with max delivery attempts.
- Cloud Logging alerts on ops_signals / ops_errors.
- Stripe webhook endpoint should be behind proper rawBody config and verify signatures (already in code).
