# Incident Runbook (Step 4)

Use this when an alert fires or users report issues.

## 0) Triage Checklist (2 minutes)

1. Open Admin and check:
   - latest `ops_errors`
   - latest failed `ops_signals` (ok=false)
   - email DLQ count (`email_dead_letter`)
2. Open Firebase Console → Functions → Logs.
3. Identify:
   - what broke (Stripe / Email / Auth / Rules / Task engine)
   - if it’s ongoing or a one-off spike

## 1) Stripe Webhook Signature Failures

**Signal**
- `ops_signals.kind = stripe_webhook_sig_fail`

**Common causes**
- Wrong `STRIPE_WEBHOOK_SECRET` in Functions secrets
- Webhook endpoint URL mismatch in Stripe
- Raw body handling misconfigured (less likely in v2)

**Fix**
1. Confirm the webhook endpoint in Stripe points to the correct URL.
2. Rotate / re-set Functions secret:
   - `firebase functions:secrets:set STRIPE_WEBHOOK_SECRET`
3. Redeploy functions.
4. Use Stripe “Send test event”.

## 2) Stripe Webhook Internal Errors (Processed Fail)

**Signal**
- `ops_signals.kind = stripe_webhook_processed_fail`
- `ops_errors.kind` includes `stripeWebhook`

**Fix**
1. Read error stack in Functions logs.
2. Confirm Firestore pricing docs exist:
   - `pricing_tiers`
   - `pricing_addons`
3. Confirm required secrets:
   - `STRIPE_SECRET_KEY`
   - `PUBLIC_SITE_BASE_URL`
4. Replay event from Stripe if needed.

## 3) Email Backlog / DLQ Growth

**Signals**
- `email_queue_backlog` or DLQ count rising

**Common causes**
- Resend key invalid
- suppressed recipients
- HTML too large / invalid
- provider outage

**Fix**
1. Confirm `RESEND_API_KEY` and `AICOMMS_FROM_EMAIL` secrets.
2. Check Resend dashboard for bounces.
3. Inspect `email_dead_letter` docs for last_error.
4. If backlog is huge:
   - temporarily raise processor batch size (carefully)
   - or run manual processor once (admin-only) (optional future)

## 4) Sudden Permission Denied Spikes

**Signals**
- Cloud logs show PERMISSION_DENIED
- Users report “missing data”

**Fix**
1. Check latest `firestore.rules` change.
2. Run rules tests locally (Step 1):
   - `npm run test:rules`
3. Roll back rules if needed.

## 5) Emergency Safe Mode

If you need to stop harm quickly:
1. Disable risky scheduled jobs in Firebase console (temporary)
2. Flip feature flags in Firestore config (if used)
3. Redeploy last known good tag (CI Step 2)

Document what you did in `system_events` as `incident_action`.
