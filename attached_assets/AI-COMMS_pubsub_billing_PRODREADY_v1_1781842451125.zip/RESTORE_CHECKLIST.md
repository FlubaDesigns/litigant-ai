# Restore Verification Checklist (Staging)

## Identity
- [ ] Confirm you are on **STAGING** project (not prod)
- [ ] Record staging project id: ____________
- [ ] Record export folder path: ____________

## Firestore sanity
- [ ] `users` collection exists and has documents
- [ ] `orgs` exists and documents load
- [ ] `project_intake_packets` exists and documents load
- [ ] `approvals` exists and documents load
- [ ] `email_outbox` / `email_queue` exists (if used)
- [ ] `ops_signals` exists (from Step 4)
- [ ] Canon collections are present (`canon_*`)

## App / portal
- [ ] Web app loads against staging
- [ ] Login works
- [ ] Admin pages load (for admin user)
- [ ] Intake submit works (risk scan / evidence pack)
- [ ] Billing pages load (no checkout required for this test)

## Functions
- [ ] `health` function responds
- [ ] Stripe webhook endpoint returns 400 on bad signature (expected)
- [ ] Email outbox processor runs (or is triggerable)

## Post-restore
- [ ] Run `node scripts/post-restore-reconcile.mjs --project STAGING`
- [ ] Derived rollups either rebuild or are confirmed non-critical
- [ ] Document anything missing, then re-run the drill after fix

## Sign-off
- Date: ____________
- Operator: ____________
- Notes: _______________________________________________
