# Secrets & Environment Setup (Step 3)

This repo is structured to **avoid committing secrets**.

## 1) GitHub Actions secret (for CI deploy)

- `FIREBASE_TOKEN` (generated via `firebase login:ci`)

Add it in your GitHub repo:
`Settings → Secrets and variables → Actions → New repository secret`

## 2) Firebase Functions v2 secrets (GCP Secret Manager)

The Functions backend uses `defineSecret("NAME")` for sensitive values.

### Set secrets (CLI)
From repo root:

```bash
firebase functions:secrets:set RESEND_API_KEY
firebase functions:secrets:set STRIPE_SECRET_KEY
firebase functions:secrets:set STRIPE_WEBHOOK_SECRET
```

Repeat for any additional secrets you use (see the manifest below).

### List secrets used by this code
This project references the following secret names:

- `ADMIN_ALERT_EMAIL`
- `AICOMMS_ADMIN_EMAIL`
- `AICOMMS_FROM_EMAIL`
- `ANTHROPIC_API_KEY`
- `EXECUTION_MODE`
- `GRACE_PERIOD_DAYS`
- `OPENAI_API_KEY`
- `OWNER_PIN_HASH`
- `OWNER_UID`
- `PRICE_MINUTES_BASE_ID`
- `PRICE_MINUTES_OVERAGE_ID`
- `PUBLIC_SITE_BASE_URL`
- `RESEND_API_KEY`
- `SOCKET_APPROVAL_SHARED_SECRET`
- `SOCKET_WEBHOOK_SECRET`
- `STRIPE_AUDIT_PRICE_ID`
- `STRIPE_CURRENCY`
- `STRIPE_ENTERPRISE_PRICE_ID`
- `STRIPE_ENTERPRISE_UNIT_AMOUNT_CENTS`
- `STRIPE_EXPLORER_UNIT_AMOUNT_CENTS`
- `STRIPE_PRO_PRICE_ID`
- `STRIPE_PRO_UNIT_AMOUNT_CENTS`
- `STRIPE_SECRET_KEY`
- `STRIPE_UNIT_AMOUNT_CENTS`
- `STRIPE_WEBHOOK_SECRET`
- `XAI_API_KEY`

> Note: Some of these are configuration-style values (like price IDs). They are still treated as secrets because the code uses `defineSecret` for consistency.

## 3) Local development

### Web
- Copy `web/.env.example` → `web/.env.local`
- Fill out your Firebase web config values.

### Functions
- Do **not** put real Stripe/Resend keys into `functions/.env`.
- Use `firebase functions:secrets:set ...` and run Functions with emulators.

## 4) Guardrail: secret scanning

Run:

```bash
npm run security:scan
```

This performs a lightweight repository scan for common secret patterns.



## Brain Bridge Secrets
- **BRAIN_CALLBACK_SECRET**: Shared HMAC secret used by Brain to sign result callbacks to `ingestBrainResult`.

## Brain Bridge Params
- **BRAIN_PUBSUB_PROJECT**: GCP project id where Brain Pub/Sub topic lives.
- **BRAIN_PUBSUB_TOPIC**: Pub/Sub topic name to publish jobs to (e.g., `brain-jobs`).
