# Stripe Setup — Minutes Hybrid Plan (Sprint 5)

Defaults:
- Base: $25/month
- Included: 60 minutes / billing cycle
- Overage: $1.00 per minute (metered)

## Create two Prices in Stripe
1) Base recurring price (monthly):
- Price ID -> set as secret PRICE_MINUTES_BASE_ID

2) Metered overage price:
- Usage type: metered
- Unit: minute
- Price per unit: $1.00
- Price ID -> set as secret PRICE_MINUTES_OVERAGE_ID

## Set Firebase Function Secrets
- PRICE_MINUTES_BASE_ID
- PRICE_MINUTES_OVERAGE_ID
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- PUBLIC_SITE_BASE_URL
