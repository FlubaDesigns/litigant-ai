# AI-COMMS Production Environment

This build requires Vite env vars for Firebase config (no placeholders):

## Required
- VITE_FIREBASE_API_KEY
- VITE_FIREBASE_AUTH_DOMAIN
- VITE_FIREBASE_PROJECT_ID

## Optional
- VITE_FIREBASE_APP_ID
- VITE_FIREBASE_STORAGE_BUCKET
- VITE_FIREBASE_MESSAGING_SENDER_ID

## App Check
If App Check is enabled, set:
- VITE_RECAPTCHA_V3_SITE_KEY (if the code expects it)

Do not commit real values into source.
