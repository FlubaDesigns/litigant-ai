import { useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function GovernanceHealthPanel() {
  const [data, setData] = useState<any>(null);
  const [msg, setMsg] = useState("");

  async function load() {
    setMsg("Loading…");
    const r = await postJson("/getGovernanceHealth", {});
    if (!r.ok) { setMsg(`Error: ${JSON.stringify(r.json)}`); return; }
    setData(r.json);
    setMsg("Loaded.");
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Governance Health</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Server-side health summary: providers, locks, security config, canary config, anomaly thresholds.
      </p>

      <button onClick={load} style={btn()}>Refresh</button>
      <div style={{ marginTop: 8, fontSize: 12, opacity: 0.75 }}>{msg}</div>

      {data ? (
        <pre style={pre()}>{JSON.stringify(data, null, 2)}</pre>
      ) : (
        <div style={{ marginTop: 10, opacity: 0.6, fontSize: 12 }}>No data loaded.</div>
      )}
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
function pre(): React.CSSProperties {
  return { marginTop: 10, padding: 12, borderRadius: 12, background: "rgba(0,0,0,0.35)", overflowX: "auto", fontSize: 12 };
}
