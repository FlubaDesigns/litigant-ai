import { useEffect, useMemo, useState } from "react";
import { db, auth } from "../firebase";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";

export default function ObservabilityPanel() {
  const [taskId, setTaskId] = useState("");
  const [alerts, setAlerts] = useState<any[]>([]);
  const [traces, setTraces] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const uid = auth.currentUser?.uid || "";

  async function load() {
    setLoading(true);
    try {
      // alerts
      const aQ = query(collection(db, "alerts"), orderBy("created_at", "desc"), limit(20));
      const aSnap = await getDocs(aQ);
      setAlerts(aSnap.docs.map((d) => ({ id: d.id, ...d.data() })));

      // traces (global) optionally filtered by taskId
      const tBase = collection(db, "trace_events");
      const tQ = taskId.trim()
        ? query(tBase, where("taskId", "==", taskId.trim()), orderBy("createdAt", "desc"), limit(50))
        : query(tBase, orderBy("createdAt", "desc"), limit(50));
      const tSnap = await getDocs(tQ);
      setTraces(tSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Observability</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Alerts + trace events (admin-only reads). Filter by Task ID for deterministic debugging.
      </p>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <input
          value={taskId}
          onChange={(e) => setTaskId(e.target.value)}
          placeholder="Filter by taskId (optional)"
          style={input()}
        />
        <button onClick={load} style={btn()} disabled={loading}>
          {loading ? "Loading…" : "Refresh"}
        </button>
      </div>

      <div style={{ marginTop: 12, display: "grid", gap: 12 }}>
        <div style={subcard()}>
          <div style={subhead()}>Recent Alerts</div>
          {alerts.length === 0 ? <div style={muted()}>No alerts.</div> : null}
          {alerts.map((a) => (
            <div key={a.id} style={row()}>
              <div style={{ fontSize: 12, opacity: 0.85 }}>
                <b>{String(a.level || "").toUpperCase()}</b> — {a.subject}
              </div>
              <div style={{ fontSize: 12, opacity: 0.7 }}>{String(a.message || "")}</div>
            </div>
          ))}
        </div>

        <div style={subcard()}>
          <div style={subhead()}>Trace Events</div>
          {traces.length === 0 ? <div style={muted()}>No trace events.</div> : null}
          {traces.map((t) => (
            <div key={t.id} style={row()}>
              <div style={{ fontSize: 12, opacity: 0.85 }}>
                <b>{t.code || t.level}</b> — task <code>{t.taskId}</code> — run <code>{t.runId}</code>
              </div>
              <div style={{ fontSize: 12, opacity: 0.7 }}>
                {t.role ? `${t.role} · ` : ""}
                {t.provider ? `${t.provider} · ` : ""}
                {t.message}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 8, opacity: 0.6, fontSize: 12 }}>
        Signed-in UID: <code>{uid}</code>
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}
function subcard(): React.CSSProperties {
  return {
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(0,0,0,0.20)",
  };
}
function subhead(): React.CSSProperties {
  return { fontSize: 13, opacity: 0.85, marginBottom: 8 };
}
function row(): React.CSSProperties {
  return { padding: "8px 0", borderTop: "1px solid rgba(255,255,255,0.08)" };
}
function muted(): React.CSSProperties {
  return { opacity: 0.6, fontSize: 12 };
}
function input(): React.CSSProperties {
  return {
    flex: "1 1 280px",
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    cursor: "pointer",
  };
}
