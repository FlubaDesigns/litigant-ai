import { useEffect, useMemo, useState } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

type ProviderStatus = "online" | "degraded" | "offline";

type ProviderDoc = {
  providerId: string;
  status: ProviderStatus;
  last_heartbeat?: any;
  latency_p95_ms?: number;
  error_rate_1h?: number;
  success_rate_1h?: number;
  cost_per_1k_tokens_est?: number;
};

export default function ProviderStatusPanel() {
  const [rows, setRows] = useState<ProviderDoc[]>([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "provider_registry"), (snap) => {
      const data = snap.docs.map((d) => {
        const v: any = d.data();
        return {
          providerId: String(v.providerId || d.id),
          status: (v.status || "offline") as ProviderStatus,
          last_heartbeat: v.last_heartbeat,
          latency_p95_ms: v.latency_p95_ms,
          error_rate_1h: v.error_rate_1h,
          success_rate_1h: v.success_rate_1h,
          cost_per_1k_tokens_est: v.cost_per_1k_tokens_est,
        };
      });
      setRows(data.sort((a,b) => a.providerId.localeCompare(b.providerId)));
    });
    return () => unsub();
  }, []);

  const online = useMemo(() => rows.filter(r => r.status === "online" || r.status === "degraded").length, [rows]);

  return (
    <div style={card()}>
      <h3 style={{ marginTop: 0 }}>Connected AI Providers</h3>
      <div style={{ opacity: 0.75, fontSize: 12, marginBottom: 10 }}>
        Online/Degraded: {online} • Total: {rows.length}
      </div>

      <div style={{ overflowX: "auto" }}>
        <table style={table()}>
          <thead>
            <tr>
              <th style={th()}>Provider</th>
              <th style={th()}>Status</th>
              <th style={th()}>Last heartbeat</th>
              <th style={th()}>p95 latency (ms)</th>
              <th style={th()}>err 1h</th>
              <th style={th()}>succ 1h</th>
              <th style={th()}>$/1k est</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.providerId}>
                <td style={td()}><code>{r.providerId}</code></td>
                <td style={td()}>{r.status}</td>
                <td style={td()}>{formatTs(r.last_heartbeat)}</td>
                <td style={td()}>{num(r.latency_p95_ms)}</td>
                <td style={td()}>{num(r.error_rate_1h)}</td>
                <td style={td()}>{num(r.success_rate_1h)}</td>
                <td style={td()}>{num(r.cost_per_1k_tokens_est)}</td>
              </tr>
            ))}
            {!rows.length ? (
              <tr><td style={td()} colSpan={7}>No provider heartbeats yet.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 10, opacity: 0.7, fontSize: 12 }}>
        Heartbeats are written via <code>/providerHeartbeat</code> Cloud Function using header <code>x-provider-key</code>.
      </div>
    </div>
  );
}

function formatTs(ts: any) {
  try {
    if (!ts) return "";
    const d = ts.toDate ? ts.toDate() : new Date(ts);
    return d.toLocaleString();
  } catch {
    return "";
  }
}
function num(v: any) {
  if (v === undefined || v === null || v === "") return "";
  const n = Number(v);
  if (Number.isNaN(n)) return String(v);
  return n.toFixed(3).replace(/\.000$/, "");
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}

function table(): React.CSSProperties {
  return { width: "100%", borderCollapse: "collapse", fontSize: 12 };
}
function th(): React.CSSProperties {
  return { textAlign: "left", padding: 8, borderBottom: "1px solid rgba(255,255,255,0.12)", opacity: 0.8 };
}
function td(): React.CSSProperties {
  return { padding: 8, borderBottom: "1px solid rgba(255,255,255,0.08)" };
}
