import { Link, NavLink, useLocation } from "react-router-dom";

const navStyle = ({ isActive }: { isActive: boolean }) => ({
  opacity: isActive ? 1 : 0.82,
  textDecoration: "none",
  fontWeight: 750 as const
});

export default function Navbar() {
  const loc = useLocation();
  const isPortal = loc.pathname.startsWith("/portal") || loc.pathname.startsWith("/login") || loc.pathname.startsWith("/admin") || loc.pathname.startsWith("/evidence") || loc.pathname.startsWith("/client");
  return (
    <div
      style={{
        position: "sticky",
        top: 0,
        zIndex: 50,
        backdropFilter: "blur(12px)",
        background: "rgba(7,10,18,0.65)",
        borderBottom: "1px solid rgba(255,255,255,0.08)"
      }}
    >
      <div
        className="container"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          paddingTop: 12,
          paddingBottom: 12
        }}
      >
        <Link to="/" style={{ display: "flex", gap: 10, alignItems: "center", fontWeight: 900 }}>
          <span
            style={{
              width: 12,
              height: 12,
              borderRadius: 999,
              background: "linear-gradient(180deg, rgba(0,212,255,0.9), rgba(79,70,229,0.9))",
              boxShadow: "0 0 18px rgba(0,212,255,0.25)"
            }}
          />
          <span>AI-COMMS</span>
          <span style={{ opacity: 0.55, fontWeight: 700 }}>Intuitive</span>
        </Link>

        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <NavLink to="/how-it-works" style={navStyle}>How It Works</NavLink>
          <NavLink to="/pricing" style={navStyle}>Pricing</NavLink>
          <NavLink to="/case-studies" style={navStyle}>Case Studies</NavLink>
          <NavLink to="/docs" style={navStyle}>Docs</NavLink>
          <NavLink to="/legal" style={navStyle}>Legal</NavLink>
          <NavLink to="/portal" style={navStyle}>
            {isPortal ? "Portal" : "Portal"}
          </NavLink>
        </div>
      </div>
    </div>
  );
}
