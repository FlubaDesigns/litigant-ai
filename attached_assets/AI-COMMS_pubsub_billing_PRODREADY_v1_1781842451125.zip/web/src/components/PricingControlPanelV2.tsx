
import { useEffect, useMemo, useState } from "react";
import { auth, db } from "../firebase";
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where,
  serverTimestamp,
} from "firebase/firestore";

type Mode = {
  mode_id: string;
  label: string;
  description?: string;
  is_active: boolean;
  display_order: number;
  updated_at?: any;
};

type Tier = {
  tier_id: string;
  mode_id: string;
  name: string;
  recommended_for?: string;
  is_active: boolean;
  display_order: number;
  monthly_fee_cents: number;
  onboarding_fee_cents: number;
  stripe_price_id_monthly: string;
  stripe_price_id_onboarding?: string;
  defaults_autonomy_level: number;
  defaults_logging_depth: "basic" | "extended" | "immutable";
  defaults_patch_mode: "proposal_only" | "approval_required" | "restricted_auto_minor";
  defaults_escalation_sla: "48h" | "24h" | "4h" | "1h";
  eligibility_min_risk_class: "SMB" | "MID_MARKET" | "REGULATED";
  version?: number;
};

type Addon = {
  addon_id: string;
  name: string;
  description?: string;
  is_active: boolean;
  monthly_fee_cents: number;
  stripe_price_id_monthly: string;
  requires_min_tier_id?: string;
  version?: number;
};

function mustBeAuthed() {
  const u = auth.currentUser;
  if (!u) throw new Error("Not logged in");
  return u;
}

function fmtCents(cents: number) {
  const n = Number(cents || 0) / 100;
  return n.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

function sortByOrder(a: any, b: any) {
  return (Number(a.display_order || 0) - Number(b.display_order || 0)) || String(a.name||a.label||"").localeCompare(String(b.name||b.label||""));
}

export default function PricingControlPanelV2() {
  const [modes, setModes] = useState<Mode[]>([]);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [addons, setAddons] = useState<Addon[]>([]);
  const [msg, setMsg] = useState("");
  const [editing, setEditing] = useState<{ kind: "mode"|"tier"|"addon", id: string } | null>(null);
  const [jsonDraft, setJsonDraft] = useState("");

  useEffect(() => {
    const qm = query(collection(db, "pricing_modes"), orderBy("display_order", "asc"));
    const qt = query(collection(db, "pricing_tiers"), orderBy("display_order", "asc"));
    const qa = query(collection(db, "pricing_addons"), orderBy("name", "asc"));
    const unsubM = onSnapshot(qm, (snap) => setModes(snap.docs.map(d => ({ ...(d.data() as any), mode_id: d.id })) as any));
    const unsubT = onSnapshot(qt, (snap) => setTiers(snap.docs.map(d => ({ ...(d.data() as any), tier_id: d.id })) as any));
    const unsubA = onSnapshot(qa, (snap) => setAddons(snap.docs.map(d => ({ ...(d.data() as any), addon_id: d.id })) as any));
    return () => { unsubM(); unsubT(); unsubA(); };
  }, []);

  const publishedVersion = useMemo(() => {
    // show current version (best effort)
    return null as any;
  }, []);

  async function openEdit(kind: "mode"|"tier"|"addon", id: string) {
    setMsg("");
    setEditing({ kind, id });
    const ref = doc(db, kind === "mode" ? "pricing_modes" : kind === "tier" ? "pricing_tiers" : "pricing_addons", id);
    const snap = await getDoc(ref);
    const data = snap.exists() ? snap.data() : {};
    setJsonDraft(JSON.stringify({ ...(data as any) }, null, 2));
  }

  async function saveEdit() {
    if (!editing) return;
    setMsg("Saving…");
    const parsed = JSON.parse(jsonDraft || "{}");
    const col = editing.kind === "mode" ? "pricing_modes" : editing.kind === "tier" ? "pricing_tiers" : "pricing_addons";
    const ref = doc(db, col, editing.id);
    await setDoc(ref, { ...parsed, updated_at: serverTimestamp() }, { merge: true });
    setMsg("Saved.");
  }

  async function createMode(id: string) {
    setMsg("");
    const modeId = id.trim().toUpperCase();
    if (!modeId) return;
    await setDoc(doc(db, "pricing_modes", modeId), {
      mode_id: modeId,
      label: modeId === "DFY" ? "Done For You" : modeId === "DYS" ? "Do It Yourself" : modeId,
      description: "",
      is_active: true,
      display_order: modes.length + 1,
      updated_at: serverTimestamp(),
    }, { merge: true });
  }

  async function createTier(modeId: string, tierId: string) {
    const id = tierId.trim().toUpperCase();
    if (!id) return;
    await setDoc(doc(db, "pricing_tiers", id), {
      tier_id: id,
      mode_id: modeId,
      name: id.replace(/^(DFY_|DYS_)/, "").replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (m: string)=>m.toUpperCase()),
      recommended_for: "SMB",
      is_active: true,
      display_order: tiers.filter(t => t.mode_id === modeId).length + 1,
      monthly_fee_cents: 0,
      onboarding_fee_cents: 0,
      stripe_price_id_monthly: "",
      stripe_price_id_onboarding: "",
      defaults_autonomy_level: 1,
      defaults_logging_depth: "basic",
      defaults_patch_mode: "approval_required",
      defaults_escalation_sla: "24h",
      eligibility_min_risk_class: "SMB",
      version: 1,
      updated_at: serverTimestamp(),
    }, { merge: true });
  }

  async function createAddon(addonId: string) {
    const id = addonId.trim().toUpperCase();
    if (!id) return;
    await setDoc(doc(db, "pricing_addons", id), {
      addon_id: id,
      name: id.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (m: string)=>m.toUpperCase()),
      description: "",
      is_active: true,
      monthly_fee_cents: 0,
      stripe_price_id_monthly: "",
      requires_min_tier_id: "",
      version: 1,
      updated_at: serverTimestamp(),
    }, { merge: true });
  }

  async function publish() {
    setMsg("Publishing…");
    // simple publish: increment pricing_version/config.current_version
    const ref = doc(db, "pricing_version", "config");
    const snap = await getDoc(ref);
    const cur = Number((snap.data() as any)?.current_version || 0);
    const next = cur + 1;
    await setDoc(ref, { current_version: next, published_at: serverTimestamp(), published_by_uid: auth.currentUser?.uid || "" }, { merge: true });
    setMsg(`Published version ${next}.`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Pricing Control</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Edit DFY/DYS modes, tiers, and add-ons in Firestore. Click Publish to bump pricing_version for cache invalidation.
      </p>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }}>
        <button style={btn()} onClick={publish}>Publish</button>
        <span style={{ opacity: 0.75 }}>{msg}</span>
      </div>

      <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "1fr", gap: 12 }}>
        <div>
          <h4 style={{ margin: "8px 0" }}>Modes</h4>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button style={btn()} onClick={() => createMode("DFY")}>+ DFY</button>
            <button style={btn()} onClick={() => createMode("DYS")}>+ DYS</button>
          </div>
          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
            {modes.sort(sortByOrder).map(m => (
              <div key={m.mode_id} style={row()}>
                <div>
                  <div><b>{m.mode_id}</b> — {m.label}</div>
                  <div style={{ opacity: 0.75, fontSize: 12 }}>{m.description}</div>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button style={btn()} onClick={() => openEdit("mode", m.mode_id)}>Edit JSON</button>
                  <button style={btn()} onClick={() => createTier(m.mode_id, `${m.mode_id}_NEW_TIER`)}>+ Tier</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 style={{ margin: "8px 0" }}>Tiers</h4>
          <div style={{ display: "grid", gap: 8 }}>
            {tiers.sort(sortByOrder).map(t => (
              <div key={t.tier_id} style={row()}>
                <div>
                  <div><b>{t.tier_id}</b> ({t.mode_id}) — {t.name}</div>
                  <div style={{ opacity: 0.75, fontSize: 12 }}>
                    {fmtCents(t.monthly_fee_cents)} / mo • Onboarding {fmtCents(t.onboarding_fee_cents)} • {t.defaults_logging_depth}/{t.defaults_patch_mode}/A{t.defaults_autonomy_level}
                  </div>
                </div>
                <button style={btn()} onClick={() => openEdit("tier", t.tier_id)}>Edit JSON</button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 style={{ margin: "8px 0" }}>Add-ons</h4>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button style={btn()} onClick={() => createAddon("NEW_ADDON")}>+ Add-on</button>
          </div>
          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
            {addons.map(a => (
              <div key={a.addon_id} style={row()}>
                <div>
                  <div><b>{a.addon_id}</b> — {a.name}</div>
                  <div style={{ opacity: 0.75, fontSize: 12 }}>{fmtCents(a.monthly_fee_cents)} / mo • min tier: {a.requires_min_tier_id || "—"}</div>
                </div>
                <button style={btn()} onClick={() => openEdit("addon", a.addon_id)}>Edit JSON</button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {editing ? (
        <div style={{ marginTop: 16 }}>
          <h4 style={{ margin: "8px 0" }}>Edit {editing.kind}: {editing.id}</h4>
          <textarea
            value={jsonDraft}
            onChange={(e) => setJsonDraft(e.target.value)}
            style={{
              width: "100%",
              minHeight: 240,
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.18)",
              background: "rgba(0,0,0,0.25)",
              color: "white",
              padding: 12,
              fontFamily: "monospace",
              fontSize: 12,
            }}
          />
          <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
            <button style={btn()} onClick={saveEdit}>Save</button>
            <button style={btn()} onClick={() => setEditing(null)}>Close</button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function row(): React.CSSProperties {
  return { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" };
}
function btn(): React.CSSProperties {
  return { padding: "8px 10px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.18)", background: "rgba(0,0,0,0.18)", color: "white", cursor: "pointer" };
}
