import { useEffect, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";

export default function SecurityStatusPanel() {
  const [verify, setVerify] = useState<any>(null);
  const [verifyErr, setVerifyErr] = useState<string>("");
  const [running, setRunning] = useState(false);

  const [targetUid, setTargetUid] = useState("");
  const [ownerPin, setOwnerPin] = useState("");
  const [claimResult, setClaimResult] = useState<any>(null);
  const [claimErr, setClaimErr] = useState<string>("");
  const [claiming, setClaiming] = useState(false);

  async function runVerify() {
    setRunning(true);
    setVerifyErr("");
    setVerify(null);
    try {
      const fn = httpsCallable(functions, "verifyConfig");
      const res: any = await fn({ appId: "aicomms_site" });
      setVerify(res.data);
    } catch (e: any) {
      setVerifyErr(e?.message || String(e));
    } finally {
      setRunning(false);
    }
  }

  async function grantAdmin(makeAdmin: boolean) {
    setClaiming(true);
    setClaimErr("");
    setClaimResult(null);
    try {
      const fn = httpsCallable(functions, "setAdminClaim");
      const res: any = await fn({ uid: targetUid.trim(), makeAdmin, ownerPin: ownerPin.trim() });
      setClaimResult(res.data);
    } catch (e: any) {
      setClaimErr(e?.message || String(e));
    } finally {
      setClaiming(false);
    }
  }

  useEffect(() => {
    // auto-run on load so dashboard shows state immediately
    runVerify().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Security</h3>
      <div style={{ opacity: 0.75, marginTop: 6, fontSize: 12 }}>
        Verify server configuration + manage admin claims (owner/admin gated).
      </div>

      <div style={{ marginTop: 10, display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button onClick={runVerify} style={btn()} disabled={running}>
          {running ? "Running verifyConfig…" : "Run verifyConfig"}
        </button>
      </div>

      {verifyErr ? <div style={{ color: "#ffb4b4", marginTop: 8 }}>{verifyErr}</div> : null}
      {verify ? (
        <pre style={pre()}>{JSON.stringify(verify, null, 2)}</pre>
      ) : (
        <div style={{ opacity: 0.7, marginTop: 8 }}>No verifyConfig result yet.</div>
      )}

      <div style={{ marginTop: 14, borderTop: "1px solid rgba(255,255,255,0.12)", paddingTop: 12 }}>
        <div style={{ fontWeight: 700, marginBottom: 8 }}>Admin Claim</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <input value={targetUid} onChange={(e) => setTargetUid(e.target.value)} placeholder="Target UID" style={input(380)} />
          <input value={ownerPin} onChange={(e) => setOwnerPin(e.target.value)} placeholder="Owner PIN (if required)" style={input(220)} />
          <button onClick={() => grantAdmin(true)} style={btn()} disabled={claiming || !targetUid.trim()}>
            {claiming ? "Working…" : "Grant Admin"}
          </button>
          <button onClick={() => grantAdmin(false)} style={btnDanger()} disabled={claiming || !targetUid.trim()}>
            {claiming ? "Working…" : "Remove Admin"}
          </button>
        </div>
        {claimErr ? <div style={{ color: "#ffb4b4", marginTop: 8 }}>{claimErr}</div> : null}
        {claimResult ? <pre style={pre()}>{JSON.stringify(claimResult, null, 2)}</pre> : null}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.18)", background: "rgba(0,0,0,0.25)", color: "white", cursor: "pointer" };
}
function btnDanger(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,180,180,0.35)", background: "rgba(80,0,0,0.25)", color: "white", cursor: "pointer" };
}
function input(w: number): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white", width: w };
}
function pre(): React.CSSProperties {
  return { marginTop: 10, padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.25)", overflow: "auto", maxHeight: 360, whiteSpace: "pre-wrap", wordBreak: "break-word" };
}
