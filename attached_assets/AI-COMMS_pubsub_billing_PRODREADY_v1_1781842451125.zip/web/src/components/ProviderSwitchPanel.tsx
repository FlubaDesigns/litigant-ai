import { useEffect, useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function ProviderSwitchPanel() {
  const [state, setState] = useState<any>(null);
  const [owner_pin, setOwnerPin] = useState("");
  const [msg, setMsg] = useState("");

  async function refresh() {
    setMsg("Loading…");
    const r = await postJson("/getProviderControls", {});
    if (r.ok) {
      setState(r.json.state);
      setMsg("");
    } else {
      setMsg(`Error: ${JSON.stringify(r.json)}`);
    }
  }

  useEffect(() => { refresh(); }, []);

  async function toggle(provider: string, enabled: boolean) {
    setMsg("Saving…");
    const r = await postJson("/setProviderEnabled", { provider, enabled, owner_pin });
    if (r.ok) {
      await refresh();
      setMsg(`${provider} => ${enabled ? "ENABLED" : "DISABLED"}`);
    } else {
      setMsg(`Error: ${JSON.stringify(r.json)}`);
    }
  }

  const enabled = (state?.enabled || {}) as Record<string, any>;
  const providers = ["openai", "anthropic", "xai", "google"];

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Provider Switches (Owner Locked, Immutable)</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        These toggles are enforced server-side. Direct Firestore writes are blocked. Only Owner + PIN can change.
      </p>

      <input value={owner_pin} onChange={(e)=>setOwnerPin(e.target.value)} placeholder="OWNER PIN (required to toggle)" style={input()} />

      <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
        {providers.map(p => {
          const isOn = enabled[p] !== false;
          return (
            <div key={p} style={row()}>
              <div style={{ fontWeight: 700 }}>{p}</div>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={()=>toggle(p, true)} style={btn(isOn)}>ON</button>
                <button onClick={()=>toggle(p, false)} style={btn(!isOn)}>OFF</button>
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>{msg}</div>

      <button onClick={refresh} style={{ ...btn(true), marginTop: 10 }}>Refresh</button>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function row(): React.CSSProperties {
  return { display: "flex", justifyContent: "space-between", alignItems: "center", padding: 12, borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.2)" };
}
function btn(active: boolean): React.CSSProperties {
  return {
    padding: "6px 10px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: active ? "rgba(255,255,255,0.14)" : "rgba(255,255,255,0.06)",
    color: "white",
    cursor: "pointer",
    minWidth: 54
  };
}
