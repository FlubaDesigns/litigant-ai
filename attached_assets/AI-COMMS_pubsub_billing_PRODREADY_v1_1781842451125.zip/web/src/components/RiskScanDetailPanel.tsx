import { useEffect, useState } from "react";
import { watchRiskScansForLead } from "../lib/adminData";

export default function RiskScanDetailPanel({ leadId }: { leadId: string | null }) {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    setRows([]);
    setErr("");
    if (!leadId) return;
    const unsub = watchRiskScansForLead(leadId, setRows, (e) => setErr(String(e?.message || e)));
    return () => unsub();
  }, [leadId]);

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Risk Scans</h3>
      <div style={{ opacity: 0.75, fontSize: 12, marginTop: 6 }}>
        {leadId ? <>Lead: <code>{leadId}</code></> : "Select a lead to view scans."}
      </div>
      {err ? <div style={{ color: "#ffb4b4", marginTop: 8 }}>{err}</div> : null}
      <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 10 }}>
        {rows.map((r) => (
          <div key={r.id} style={scan()}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
              <div style={{ fontWeight: 700 }}>
                Score: {r.score ?? "—"} · Band: {r.band ?? "—"}
              </div>
              <div style={{ opacity: 0.75, fontSize: 12 }}>
                {String(r.created_at?.toDate?.() || r.created_at || "—")}
              </div>
            </div>
            <div style={{ marginTop: 8 }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>Findings</div>
              <ul style={{ marginTop: 0 }}>
                {(r.findings || []).slice(0, 12).map((f: any, idx: number) => <li key={idx}>{String(f)}</li>)}
              </ul>
            </div>
            <div style={{ marginTop: 8 }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>Recommended Next</div>
              <ul style={{ marginTop: 0 }}>
                {(r.recommended_next || []).slice(0, 12).map((f: any, idx: number) => <li key={idx}>{String(f)}</li>)}
              </ul>
            </div>
          </div>
        ))}
        {leadId && !rows.length ? <div style={{ opacity: 0.7 }}>No scans found for this lead.</div> : null}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function scan(): React.CSSProperties {
  return { padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.18)" };
}
