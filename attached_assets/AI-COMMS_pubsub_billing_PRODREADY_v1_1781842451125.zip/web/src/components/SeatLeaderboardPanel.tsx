import { useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function SeatLeaderboardPanel() {
  const [role, setRole] = useState("architect");
  const [taskType, setTaskType] = useState("PATCH_SMALL");
  const [rows, setRows] = useState<any[]>([]);
  const [msg, setMsg] = useState("");

  async function load() {
    setMsg("Loading leaderboard…");
    const r = await postJson("/getSeatLeaderboard", { role, taskType });
    if (!r.ok) {
      setMsg(`Error: ${JSON.stringify(r.json)}`);
      return;
    }
    setRows(r.json?.ranked || []);
    setMsg(`Loaded ${r.json?.ranked?.length || 0} providers.`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Seat A/B Leaderboard</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Ranking providers by the exact router score for a given <b>role</b> + <b>taskType</b>.
      </p>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <select value={role} onChange={(e) => setRole(e.target.value)} style={input()}>
          <option value="architect">architect</option>
          <option value="builder">builder</option>
          <option value="auditor">auditor</option>
        </select>
        <input value={taskType} onChange={(e) => setTaskType(e.target.value)} style={input()} placeholder="TaskType (e.g. PATCH_SMALL)" />
        <button onClick={load} style={btn()}>Load</button>
      </div>

      <div style={{ marginTop: 10, opacity: 0.75, fontSize: 12 }}>{msg}</div>

      <div style={{ marginTop: 12, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr>
              {["provider","score","success","steps","duration_ms","cost_usd","runs"].map((h) => (
                <th key={h} style={th()}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.id || i} style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                <td style={td()}><code>{r.provider}</code></td>
                <td style={td()}>{Number(r.score ?? 0).toFixed(2)}</td>
                <td style={td()}>{Number(r.success_rate ?? 0).toFixed(3)}</td>
                <td style={td()}>{Number(r.avg_steps ?? 0).toFixed(1)}</td>
                <td style={td()}>{Math.round(Number(r.avg_duration_ms ?? 0))}</td>
                <td style={td()}>{Number(r.avg_cost_usd ?? 0).toFixed(3)}</td>
                <td style={td()}>{Number(r.runs_total ?? 0)}</td>
              </tr>
            ))}
            {rows.length === 0 ? (
              <tr>
                <td style={td()} colSpan={7}><span style={{ opacity: 0.6 }}>No data yet. Run tasks to generate rollups.</span></td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}
function input(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
    minWidth: 180,
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    cursor: "pointer",
  };
}
function th(): React.CSSProperties {
  return { textAlign: "left", padding: "8px 6px", opacity: 0.8 };
}
function td(): React.CSSProperties {
  return { padding: "8px 6px", verticalAlign: "top" };
}
