import { useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function SeatCanaryConfigPanel() {
  const [role, setRole] = useState("architect");
  const [taskType, setTaskType] = useState("PATCH_SMALL");
  const [incumbent, setInc] = useState("gpt-4o");
  const [challenger, setCh] = useState("claude");
  const [canary_percent, setPct] = useState(10);
  const [min_runs, setMinRuns] = useState(10);
  const [margin, setMargin] = useState(15);
  const [step, setStep] = useState(5);
  const [msg, setMsg] = useState("");

  async function save() {
    setMsg("Saving…");
    const r = await postJson("/setSeatCanaryConfig", { role, taskType, incumbent, challenger, canary_percent, min_runs, margin, step });
    setMsg(r.ok ? "Saved seat canary config." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Seat Canary Config</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Configure incumbent vs challenger per (role, taskType). The hourly evaluator will auto-adjust canary percent.
      </p>

      <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
        <select value={role} onChange={(e)=>setRole(e.target.value)} style={input()}>
          <option value="architect">architect</option>
          <option value="builder">builder</option>
          <option value="auditor">auditor</option>
        </select>
        <input value={taskType} onChange={(e)=>setTaskType(e.target.value)} placeholder="taskType" style={input()} />
        <input value={incumbent} onChange={(e)=>setInc(e.target.value)} placeholder="incumbent provider" style={input()} />
        <input value={challenger} onChange={(e)=>setCh(e.target.value)} placeholder="challenger provider" style={input()} />
        <input type="number" value={canary_percent} onChange={(e)=>setPct(Number(e.target.value))} style={input()} />
        <input type="number" value={min_runs} onChange={(e)=>setMinRuns(Number(e.target.value))} style={input()} />
        <input type="number" value={margin} onChange={(e)=>setMargin(Number(e.target.value))} style={input()} />
        <input type="number" value={step} onChange={(e)=>setStep(Number(e.target.value))} style={input()} />
      </div>

      <button onClick={save} style={btn()}>Save Seat Canary</button>
      <div style={{ fontSize: 12, opacity: 0.75, marginTop: 8 }}>{msg}</div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer", marginTop: 10 };
}
