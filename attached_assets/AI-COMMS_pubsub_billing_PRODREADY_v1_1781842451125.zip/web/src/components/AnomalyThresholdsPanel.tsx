import { useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function AnomalyThresholdsPanel() {
  const [MIN_SUCCESS, setMinSuccess] = useState(0.6);
  const [MAX_STEPS, setMaxSteps] = useState(150);
  const [MAX_DUR_MS, setMaxDur] = useState(240000);
  const [MAX_COST, setMaxCost] = useState(2.0);
  const [msg, setMsg] = useState("");

  async function save() {
    setMsg("Saving…");
    const r = await postJson("/setAnomalyThresholds", { MIN_SUCCESS, MAX_STEPS, MAX_DUR_MS, MAX_COST });
    setMsg(r.ok ? "Saved." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Anomaly Detector Thresholds</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>Tune breaker sensitivity without redeploying code.</p>

      <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
        <Field label="MIN_SUCCESS" value={MIN_SUCCESS} onChange={setMinSuccess} step="0.01" />
        <Field label="MAX_STEPS" value={MAX_STEPS} onChange={setMaxSteps} step="1" />
        <Field label="MAX_DUR_MS" value={MAX_DUR_MS} onChange={setMaxDur} step="1000" />
        <Field label="MAX_COST" value={MAX_COST} onChange={setMaxCost} step="0.1" />
      </div>

      <button onClick={save} style={btn()}>Save Thresholds</button>
      <div style={{ fontSize: 12, opacity: 0.75, marginTop: 8 }}>{msg}</div>
    </div>
  );
}

function Field({ label, value, onChange, step }: any) {
  return (
    <div style={{ display: "grid", gap: 6 }}>
      <div style={{ fontSize: 12, opacity: 0.8 }}>{label}</div>
      <input type="number" value={value} step={step} onChange={(e)=>onChange(Number(e.target.value))} style={input()} />
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer", marginTop: 10 };
}
