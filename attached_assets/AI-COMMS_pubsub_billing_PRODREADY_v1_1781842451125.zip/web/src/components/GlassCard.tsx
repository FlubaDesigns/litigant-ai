import React from "react";

export default function GlassCard({
  children,
  className = ""
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={className}
      style={{
        borderRadius: "var(--radius)",
        border: "1px solid var(--stroke)",
        background: "linear-gradient(180deg, var(--panel), var(--panel2))",
        boxShadow: "var(--shadow)",
        padding: 16
      }}
    >
      {children}
    </div>
  );
}