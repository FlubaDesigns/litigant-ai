import { Link } from "react-router-dom";
import { APP_VERSION } from "../version";

function short(hash: string | null | undefined) {
  if (!hash) return null;
  return hash.slice(0, 10) + "…";
}

export default function Footer() {
  const canonShort = short(APP_VERSION.canonHash);
  const webShort = short(APP_VERSION.webHash);

  return (
    <footer style={{ marginTop: 30, padding: "26px 0", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
      <div className="container" style={{ display: "flex", gap: 14, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap" }}>
        <div style={{ opacity: 0.8, fontSize: 13, lineHeight: 1.35 }}>
          <div>© {new Date().getFullYear()} AI-COMMS — Intuitive. Powered by AI-COMMS.</div>
          <div style={{ opacity: 0.75 }}>
            v{APP_VERSION.version}
            {webShort ? ` · web ${webShort}` : ""}
            {canonShort ? ` · canon ${canonShort}` : ""}
          </div>
        </div>

        <div style={{ display: "flex", gap: 12, fontSize: 13, opacity: 0.85 }}>
          <Link to="/docs">Docs</Link>
          <Link to="/pricing">Pricing</Link>
          <Link to="/intake">Intake</Link>
          <Link to="/legal">Privacy & Terms</Link>
        </div>
      </div>
    </footer>
  );
}