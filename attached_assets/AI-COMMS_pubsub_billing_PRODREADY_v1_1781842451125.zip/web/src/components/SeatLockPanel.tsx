import { useEffect, useMemo, useState } from "react";
import { auth, db } from "../firebase";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

type Lock = { id: string; role?: string; taskType?: string; provider?: string; is_locked?: boolean; };

export default function SeatLockPanel() {
  const [role, setRole] = useState("architect");
  const [taskType, setTaskType] = useState("PATCH_SMALL");
  const [provider, setProvider] = useState("openai");
  const [is_locked, setLocked] = useState(true);
  const [locks, setLocks] = useState<Lock[]>([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const q = query(collection(db, "seat_locks"), orderBy("updated_at", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setLocks(snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
    });
    return () => unsub();
  }, []);

  const locked = useMemo(() => locks.filter(l => !!l.is_locked), [locks]);

  async function save() {
    setMsg("Saving…");
    const r = await postJson("/setSeatLock", { role, taskType, provider, is_locked });
    setMsg(r.ok ? "Saved." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function unlockExisting(id: string, role: string, taskType: string) {
    setMsg("Unlocking…");
    const r = await postJson("/setSeatLock", { role, taskType, is_locked: false, provider: "" });
    setMsg(r.ok ? "Unlocked." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Seat Locks</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Hard override routing for a given (role, taskType). When locked, the router will always pick the locked provider.
      </p>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <select value={role} onChange={(e)=>setRole(e.target.value)} style={input()}>
          <option value="architect">architect</option>
          <option value="builder">builder</option>
          <option value="auditor">auditor</option>
          <option value="moderator">moderator</option>
          <option value="agents">agents</option>
        </select>
        <input value={taskType} onChange={(e)=>setTaskType(e.target.value)} style={input()} placeholder="taskType" />
        <input value={provider} onChange={(e)=>setProvider(e.target.value)} style={input()} placeholder="provider (openai/anthropic/xai)" />
        <label style={{ display: "flex", gap: 6, alignItems: "center", opacity: 0.9 }}>
          <input type="checkbox" checked={is_locked} onChange={(e)=>setLocked(e.target.checked)} />
          locked
        </label>
        <button onClick={save} style={btn()}>Save</button>
      </div>

      <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>{msg}</div>

      <div style={{ marginTop: 12 }}>
        <div style={{ opacity: 0.8, marginBottom: 6 }}>Locked seats</div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr>{["role","taskType","provider","id","controls"].map(h=> <th key={h} style={th()}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {locked.map(l => (
                <tr key={l.id} style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                  <td style={td()}><code>{l.role}</code></td>
                  <td style={td()}><code>{l.taskType}</code></td>
                  <td style={td()}><code>{l.provider}</code></td>
                  <td style={td()}><code>{l.id}</code></td>
                  <td style={td()}><button style={btn()} onClick={() => unlockExisting(l.id, String(l.role||""), String(l.taskType||""))}>Unlock</button></td>
                </tr>
              ))}
              {locked.length===0 ? <tr><td style={td()} colSpan={5}><span style={{opacity:0.6}}>No seat locks set.</span></td></tr> : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white", minWidth: 180 };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
function th(): React.CSSProperties { return { textAlign:"left", padding:"8px 6px", opacity:0.8 }; }
function td(): React.CSSProperties { return { padding:"8px 6px", verticalAlign:"top" }; }
