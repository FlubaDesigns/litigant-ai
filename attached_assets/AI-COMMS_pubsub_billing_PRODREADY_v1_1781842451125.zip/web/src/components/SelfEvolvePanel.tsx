import { useEffect, useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function SelfEvolvePanel() {
  const [canary, setCanary] = useState(5);
  const [mode, setMode] = useState<"REAL" | "SIMULATED">("REAL");
  const [breakerKey, setBreakerKey] = useState("");
  const [replayTaskId, setReplayTaskId] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    // default values only; stored config is managed server-side
  }, []);

  async function saveCanary() {
    setMsg("Saving canary…");
    const r = await postJson("/setCanaryConfig", { canary_percent: canary });
    setMsg(r.ok ? "Canary saved." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function saveMode() {
    setMsg("Saving mode…");
    const r = await postJson("/setSimulationMode", { mode });
    setMsg(r.ok ? "Mode saved." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function unfreeze() {
    setMsg("Unfreezing…");
    const r = await postJson("/unfreezeBreaker", { key: breakerKey });
    setMsg(r.ok ? "Breaker unfrozen." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function replay() {
    setMsg("Replaying task…");
    const r = await postJson("/replayTask", { taskId: replayTaskId });
    setMsg(r.ok ? "Replay triggered (check task trace)." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Self‑Evolving Controls</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Canary routing, simulation toggle, breaker unfreeze, and deterministic task replay.
      </p>

      <div style={grid()}>
        <div style={subcard()}>
          <div style={label()}>Canary % (0–50)</div>
          <input type="number" min={0} max={50} value={canary} onChange={(e) => setCanary(Number(e.target.value))} style={input()} />
          <button onClick={saveCanary} style={btn()}>Save Canary</button>
        </div>

        <div style={subcard()}>
          <div style={label()}>Execution Mode</div>
          <select value={mode} onChange={(e) => setMode(e.target.value as any)} style={input()}>
            <option value="REAL">REAL</option>
            <option value="SIMULATED">SIMULATED</option>
          </select>
          <button onClick={saveMode} style={btn()}>Save Mode</button>
        </div>

        <div style={subcard()}>
          <div style={label()}>Unfreeze Breaker</div>
          <input value={breakerKey} onChange={(e) => setBreakerKey(e.target.value)} placeholder="role__TASKTYPE" style={input()} />
          <button onClick={unfreeze} style={btn()}>Unfreeze</button>
        </div>

        <div style={subcard()}>
          <div style={label()}>Replay Task</div>
          <input value={replayTaskId} onChange={(e) => setReplayTaskId(e.target.value)} placeholder="taskId" style={input()} />
          <button onClick={replay} style={btn()}>Replay</button>
        </div>
      </div>

      <div style={{ marginTop: 10, opacity: 0.75, fontSize: 12 }}>{msg}</div>
    </div>
  );
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}
function grid(): React.CSSProperties {
  return { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 12, marginTop: 12 };
}
function subcard(): React.CSSProperties {
  return {
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(0,0,0,0.20)",
    display: "grid",
    gap: 8,
  };
}
function label(): React.CSSProperties {
  return { fontSize: 12, opacity: 0.8 };
}
function input(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    cursor: "pointer",
  };
}
