import { useEffect, useMemo, useState } from "react";
import { auth, db } from "../firebase";
import { collection, onSnapshot, orderBy, query, limit } from "firebase/firestore";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

type ReqRow = {
  id: string;
  status?: string;
  action?: string;
  app?: string;
  intent?: string;
  scope?: string;
  created_at?: any;
};

export default function ApprovalQueuePanel() {
  const [rows, setRows] = useState<ReqRow[]>([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const q = query(collection(db, "orchestrator_requests"), orderBy("created_at", "desc"), limit(50));
    const unsub = onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      setRows(list);
    });
    return () => unsub();
  }, []);

  const pending = useMemo(
    () => rows.filter(r => ["queued","reviewing","awaiting_architect"].includes(String(r.status||""))),
    [rows]
  );

  async function approve(id: string) {
    setMsg("Approving…");
    const r = await postJson("/approveOrchestratorRequest", { id });
    setMsg(r.ok ? "Approved." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function deny(id: string) {
    const reason = prompt("Reason for deny? (optional)") || "";
    setMsg("Denying…");
    const r = await postJson("/denyOrchestratorRequest", { id, reason });
    setMsg(r.ok ? "Denied." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Approval Queue</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Owner/Admin control over approval requests. If a request is tied to a Socket job, Approve will trigger Socket apply using an owner approval token, then log decision_log.
      </p>
      <div style={{ fontSize: 12, opacity: 0.75 }}>{msg}</div>

      <div style={{ marginTop: 10, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr>
              {["status","action","app","scope","intent","id","controls"].map(h => <th key={h} style={th()}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {pending.map((r) => (
              <tr key={r.id} style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                <td style={td()}><code>{String(r.status||"")}</code></td>
                <td style={td()}>{String(r.action||"")}</td>
                <td style={td()}>{String(r.app||"")}</td>
                <td style={td()}>{String(r.scope||"")}</td>
                <td style={td()}>{String(r.intent||"")}</td>
                <td style={td()}><code>{r.id}</code></td>
                <td style={td()}>
                  <button style={btn()} onClick={() => approve(r.id)}>Approve</button>
                  <button style={{...btn(), marginLeft: 8}} onClick={() => deny(r.id)}>Deny</button>
                </td>
              </tr>
            ))}
            {pending.length === 0 ? (
              <tr><td style={td()} colSpan={7}><span style={{ opacity: 0.6 }}>No pending requests.</span></td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function btn(): React.CSSProperties {
  return { padding: "8px 10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
function th(): React.CSSProperties {
  return { textAlign: "left", padding: "8px 6px", opacity: 0.8 };
}
function td(): React.CSSProperties {
  return { padding: "8px 6px", verticalAlign: "top" };
}
