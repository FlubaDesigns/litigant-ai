import { useEffect, useMemo, useState } from "react";
import { watchLatestLeads } from "../lib/adminData";

export default function LeadsPanel({ onSelectLead }: { onSelectLead: (leadId: string) => void }) {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState<string>("");
  const [q, setQ] = useState("");

  useEffect(() => {
    const unsub = watchLatestLeads(setRows, (e) => setErr(String(e?.message || e)));
    return () => unsub();
  }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) => String(r.email || "").toLowerCase().includes(s) || String(r.business_name || "").toLowerCase().includes(s));
  }, [rows, q]);

  return (
    <div style={card()}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h3 style={{ margin: 0 }}>Leads</h3>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search email or business…"
          style={input()}
        />
      </div>
      {err ? <div style={{ color: "#ffb4b4", marginTop: 8 }}>{err}</div> : null}
      <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
        {filtered.map((r) => (
          <button key={r.id} onClick={() => onSelectLead(r.id)} style={rowBtn()}>
            <div style={{ fontWeight: 600 }}>{r.email || "(no email)"}</div>
            <div style={{ opacity: 0.75, fontSize: 12 }}>
              {r.business_name || r.name || "—"} · Tier: {r.tier || "free"} · Updated: {String(r.updated_at?.toDate?.() || r.updated_at || "—")}
            </div>
          </button>
        ))}
        {!filtered.length ? <div style={{ opacity: 0.7 }}>No leads found.</div> : null}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "8px 10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white", width: 260 };
}
function rowBtn(): React.CSSProperties {
  return { textAlign: "left", padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.18)", color: "white", cursor: "pointer" };
}
