import React from "react";

export default function Section({
  title,
  kicker,
  children
}: {
  title: string;
  kicker?: string;
  children: React.ReactNode;
}) {
  return (
    <section style={{ padding: "26px 0" }}>
      {kicker && <div className="badge">{kicker}</div>}
      <h2 className="h2" style={{ marginTop: 10 }}>{title}</h2>
      <div style={{ marginTop: 12 }}>{children}</div>
    </section>
  );
}