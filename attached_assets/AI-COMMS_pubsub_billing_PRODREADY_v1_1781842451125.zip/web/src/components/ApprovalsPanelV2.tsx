
import { useEffect, useMemo, useState } from "react";
import { auth, db, functions } from "../firebase";
import { collection, limit, onSnapshot, orderBy, query } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";

type Approval = {
  id: string;
  org_id?: string;
  status?: string;
  action_summary?: string;
  policy_trigger?: string;
  created_at?: any;
  expires_at?: any;
  owner_uid?: string;
};

export default function ApprovalsPanelV2() {
  const [rows, setRows] = useState<Approval[]>([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const q = query(collection(db, "approvals"), orderBy("created_at", "desc"), limit(50));
    const unsub = onSnapshot(q, (snap) => {
      setRows(snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
    });
    return () => unsub();
  }, []);

  const pending = useMemo(() => rows.filter(r => String(r.status||"") === "pending"), [rows]);

  async function decide(id: string, decision: "approve"|"reject") {
    setMsg("Submitting…");
    const fn = httpsCallable(functions, "resolveApproval");
    const res: any = await fn({ approvalId: id, decision, comment: "" });
    setMsg(`Done: ${decision}`);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Approvals (v2)</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        When governance requires human approval, requests appear here.
      </p>

      {msg ? <div style={{ marginTop: 8, opacity: 0.8 }}>{msg}</div> : null}

      <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
        {pending.length === 0 ? <div style={{ opacity: 0.75 }}>No pending approvals.</div> : null}
        {pending.map(a => (
          <div key={a.id} style={row()}>
            <div>
              <div><b>{a.status}</b> — {a.action_summary || a.id}</div>
              <div style={{ opacity: 0.75, fontSize: 12 }}>Trigger: {a.policy_trigger || "—"} • Org: {a.org_id || "—"}</div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button style={btn()} onClick={() => decide(a.id, "approve")}>Approve</button>
              <button style={btn()} onClick={() => decide(a.id, "reject")}>Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function row(): React.CSSProperties {
  return { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" };
}
function btn(): React.CSSProperties {
  return { padding: "8px 10px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.18)", background: "rgba(0,0,0,0.18)", color: "white", cursor: "pointer" };
}
