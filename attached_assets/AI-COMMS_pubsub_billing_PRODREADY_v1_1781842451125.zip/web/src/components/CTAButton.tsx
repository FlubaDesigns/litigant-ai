import { Link } from "react-router-dom";

export default function CTAButton({
  to,
  label,
  variant = "primary"
}: {
  to: string;
  label: string;
  variant?: "primary" | "secondary";
}) {
  const isPrimary = variant === "primary";
  return (
    <Link
      to={to}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        padding: "12px 14px",
        borderRadius: 14,
        border: `1px solid ${isPrimary ? "rgba(79,70,229,0.65)" : "var(--stroke)"}`,
        background: isPrimary
          ? "linear-gradient(90deg, rgba(79,70,229,0.85), rgba(0,212,255,0.35))"
          : "rgba(255,255,255,0.04)",
        fontWeight: 800,
        textDecoration: "none"
      }}
    >
      {label}
      <span style={{ opacity: 0.9 }}>→</span>
    </Link>
  );
}