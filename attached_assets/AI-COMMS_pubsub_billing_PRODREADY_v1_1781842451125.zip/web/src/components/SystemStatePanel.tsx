import { useEffect, useState } from "react";

export default function SystemStatePanel() {
  const [raw, setRaw] = useState<string>("");
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/CONTROL/SYSTEM_STATE.json", { cache: "no-store" as any });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        setRaw(await res.text());
      } catch (e: any) {
        setErr(e?.message || "Failed to load SYSTEM_STATE.json");
      }
    })();
  }, []);

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>SYSTEM_STATE.json</h3>
      <p style={{ opacity: 0.75, marginTop: 6 }}>
        Global truth anchor. Any AI task must read this first.
      </p>
      {err ? <div style={{ color: "#ffb4b4" }}>{err}</div> : null}
      <pre style={pre()}>{raw || "Loading…"}</pre>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function pre(): React.CSSProperties {
  return { marginTop: 10, padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.25)", overflow: "auto", maxHeight: 320, whiteSpace: "pre-wrap", wordBreak: "break-word" };
}
