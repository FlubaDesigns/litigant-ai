import { useEffect, useMemo, useState } from "react";
import { auth, db } from "../firebase";
import { collection, getDocs, limit, orderBy, query } from "firebase/firestore";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function CanonGovernancePanel() {
  const [proposed_hash, setHash] = useState("");
  const [proposed_version, setVer] = useState("");
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState("");
  const [owner_pin, setOwnerPin] = useState("");
  const [requests, setRequests] = useState<any[]>([]);
  const [refreshTick, setRefreshTick] = useState(0);

  async function refresh() {
    try {
      const qy = query(collection(db, "canon_update_requests"), orderBy("created_at", "desc"), limit(20));
      const snap = await getDocs(qy);
      setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) {
      // ignore if rules restrict
    }
  }

  useEffect(() => { refresh(); }, [refreshTick]);

  async function requestUpdate() {
    setMsg("Requesting…");
    const r = await postJson("/requestCanonUpdate", { proposed_hash, proposed_version, reason });
    setMsg(r.ok ? `Requested: ${r.json.requestId}` : `Error: ${JSON.stringify(r.json)}`);
    setRefreshTick(x=>x+1);
  }

  async function ownerApprove(requestId: string, approve: boolean) {
    setMsg(approve ? "Approving…" : "Rejecting…");
    const r = await postJson("/approveCanonUpdate", { requestId, approve, owner_pin });
    setMsg(r.ok ? `Owner decision: ${r.json.status}` : `Error: ${JSON.stringify(r.json)}`);
    setRefreshTick(x=>x+1);
  }

  async function ownerApply(requestId: string) {
    setMsg("Applying…");
    const r = await postJson("/applyCanonUpdate", { requestId, owner_pin });
    setMsg(r.ok ? `Applied canon: ${r.json.canon_version}` : `Error: ${JSON.stringify(r.json)}`);
    setRefreshTick(x=>x+1);
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Canon Governance (Owner Locked)</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Admins can request a Canon change. Only the Owner UID (secret OWNER_UID) can approve/apply.
      </p>

      <div style={{ display: "grid", gap: 8 }}>
        <input value={proposed_version} onChange={(e)=>setVer(e.target.value)} placeholder="proposed_version (e.g. canon-v1.2)" style={input()} />
        <input value={proposed_hash} onChange={(e)=>setHash(e.target.value)} placeholder="proposed_hash (sha256...)" style={input()} />
        <input value={reason} onChange={(e)=>setReason(e.target.value)} placeholder="reason (optional)" style={input()} />
        <input value={owner_pin} onChange={(e)=>setOwnerPin(e.target.value)} placeholder="OWNER PIN (required to approve/apply)" style={input()} />
        <button onClick={requestUpdate} style={btn()}>Request Canon Update</button>
        <div style={{ fontSize: 12, opacity: 0.75 }}>{msg}</div>
      </div>

      <div style={{ marginTop: 14, fontSize: 12, opacity: 0.9 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <b>Recent Requests</b>
          <button onClick={()=>setRefreshTick(x=>x+1)} style={btnSmall()}>Refresh</button>
        </div>

        <div style={{ marginTop: 8, display: "grid", gap: 10 }}>
          {requests.map((r:any) => (
            <div key={r.id} style={box()}>
              <div><b>{r.id}</b></div>
              <div>Status: <b>{String(r.status || "")}</b></div>
              <div>Version: {String(r.proposed_version || "")}</div>
              <div style={{ wordBreak: "break-all" }}>Hash: {String(r.proposed_hash || "")}</div>
              <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button onClick={()=>ownerApprove(r.id, true)} style={btnSmall()}>Owner Approve</button>
                <button onClick={()=>ownerApprove(r.id, false)} style={btnSmall()}>Owner Reject</button>
                <button onClick={()=>ownerApply(r.id)} style={btnSmall()}>Owner Apply</button>
              </div>
              <div style={{ marginTop: 6, opacity: 0.7 }}>Reason: {String(r.reason || "")}</div>
            </div>
          ))}
          {!requests.length ? <div style={{ opacity: 0.7 }}>No requests loaded (may be rules / empty).</div> : null}
        </div>
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
function btnSmall(): React.CSSProperties {
  return { padding: "6px 10px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.06)", color: "white", cursor: "pointer" };
}
function box(): React.CSSProperties {
  return { padding: 12, borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.2)" };
}
