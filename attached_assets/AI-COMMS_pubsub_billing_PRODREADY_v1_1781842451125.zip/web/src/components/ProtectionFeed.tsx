import { useEffect, useState } from "react";
import { collection, query, where, orderBy, limit, onSnapshot } from "firebase/firestore";
import { auth, db } from "../firebase";

type ProtectionEvent = {
  severity: "calm" | "medium" | "critical";
  type: string;
  message: string;
  createdAt?: any;
};

const sevColor: Record<string, string> = {
  calm: "text-green-400",
  medium: "text-yellow-400",
  critical: "text-red-500",
};

export default function ProtectionFeed() {
  const [events, setEvents] = useState<ProtectionEvent[]>([]);
  const [status, setStatus] = useState<string>("Loading protection activity...");

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      setStatus("Sign in to see your protection activity.");
      return;
    }

    const q = query(
      collection(db, "protection_events"),
      where("userId", "==", user.uid),
      orderBy("createdAt", "desc"),
      limit(10)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const rows = snap.docs.map((d) => d.data() as any);
        setEvents(rows);
        setStatus(rows.length ? "" : "No protection events yet. Run your safety check to begin.");
      },
      (err) => {
        console.error("ProtectionFeed snapshot error:", err);
        setStatus("Unable to load protection activity.");
      }
    );

    return () => unsub();
  }, []);

  return (
    <div className="bg-gray-900 p-6 rounded-xl mt-6">
      <h2 className="text-xl font-semibold mb-2">Protection Activity</h2>
      <p className="text-gray-400 mb-4 text-sm">
        Quiet signals that show your blanket is working.
      </p>

      {status ? (
        <div className="text-gray-300">{status}</div>
      ) : (
        <ul className="space-y-3 text-gray-200">
          {events.map((e, i) => (
            <li key={i} className="flex gap-3 items-start">
              <span className={`font-bold ${sevColor[e.severity] || "text-gray-300"}`}>
                [{String(e.severity || "calm").toUpperCase()}]
              </span>
              <span>{e.message}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
