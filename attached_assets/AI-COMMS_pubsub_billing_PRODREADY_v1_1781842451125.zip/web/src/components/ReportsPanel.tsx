import { useEffect, useState } from "react";
import { watchReports } from "../lib/adminData";

export default function ReportsPanel() {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    const unsub = watchReports(setRows, (e) => setErr(String(e?.message || e)));
    return () => unsub();
  }, []);

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Reports</h3>
      <div style={{ opacity: 0.75, marginTop: 6, fontSize: 12 }}>Recent governance reports (if enabled).</div>
      {err ? <div style={{ color: "#ffb4b4", marginTop: 8 }}>{err}</div> : null}
      <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 8 }}>
        {rows.map((r) => (
          <div key={r.id} style={row()}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
              <div style={{ fontWeight: 700 }}>{r.title || r.app || "Report"}</div>
              <div style={{ opacity: 0.75, fontSize: 12 }}>{String(r.created_at?.toDate?.() || r.created_at || "—")}</div>
            </div>
            {r.summary ? <div style={{ opacity: 0.85, marginTop: 6 }}>{String(r.summary)}</div> : null}
            <div style={{ opacity: 0.7, fontSize: 12, marginTop: 6 }}><code>{r.id}</code></div>
          </div>
        ))}
        {!rows.length ? <div style={{ opacity: 0.7 }}>No reports found.</div> : null}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function row(): React.CSSProperties {
  return { padding: 12, borderRadius: 12, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(0,0,0,0.18)" };
}
