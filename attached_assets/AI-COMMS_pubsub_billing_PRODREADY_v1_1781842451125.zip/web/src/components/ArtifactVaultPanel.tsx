import { useState } from "react";
import { socketGet } from "../lib/socketApi";

export default function ArtifactVaultPanel() {
  const [jobId, setJobId] = useState("");
  const [out, setOut] = useState<any>(null);
  const [msg, setMsg] = useState("");

  async function load() {
    if (!jobId) return;
    setMsg("Loading…");
    const r = await socketGet(jobId);
    setOut(r.json);
    setMsg(r.ok ? "Loaded." : `Error: ${JSON.stringify(r.json)}`);
  }

  const artifacts = out?.artifacts || out?.artifact || null;

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Artifact Vault</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>
        Looks up a Socket job and displays its artifact links and receipts. (Retail UI; Socket stores and signs artifacts.)
      </p>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        <input value={jobId} onChange={(e)=>setJobId(e.target.value)} placeholder="Socket jobId" style={input()} />
        <button onClick={load} style={btn()}>Load</button>
      </div>
      <div style={{ marginTop: 8, fontSize: 12, opacity: 0.75 }}>{msg}</div>

      <pre style={pre()}>{JSON.stringify(out, null, 2)}</pre>

      {artifacts ? (
        <div style={{ marginTop: 10, fontSize: 12, opacity: 0.85 }}>
          <div><b>Artifacts:</b></div>
          <pre style={pre()}>{JSON.stringify(artifacts, null, 2)}</pre>
        </div>
      ) : null}
    </div>
  );
}

function card(): React.CSSProperties {
  return {
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 16,
    padding: 14,
    background: "rgba(0,0,0,0.22)",
  };
}
function input(): React.CSSProperties {
  return {
    minWidth: 240,
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
    outline: "none",
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,180,255,0.25)",
    color: "white",
    cursor: "pointer",
  };
}
function pre(): React.CSSProperties {
  return {
    marginTop: 10,
    background: "rgba(0,0,0,0.35)",
    padding: 12,
    borderRadius: 12,
    overflowX: "auto",
    maxHeight: 360,
  };
}
