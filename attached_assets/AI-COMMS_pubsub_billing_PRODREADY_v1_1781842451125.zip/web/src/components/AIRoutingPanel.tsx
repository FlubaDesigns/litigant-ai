import { useEffect, useMemo, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { collection, onSnapshot } from "firebase/firestore";
import { db, functions } from "../firebase";

type ProviderStatus = "online" | "degraded" | "offline";
type RoleSeat = "moderator" | "agents" | "architect" | "builder" | "auditor";

type ProviderDoc = {
  providerId: string;
  status: ProviderStatus;
};

type RoleRule =
  | { mode: "manual"; provider: string }
  | { mode: "auto"; pool: string[] };

type RoleRoutingConfig = Partial<Record<RoleSeat, RoleRule>>;

const TASK_TYPES = [
  "RISKSCAN_LEAD_CAPTURE",
  "STRIPE_WEBHOOK_FULFILLMENT",
  "COPY_PAGE_GENERATION",
  "PATCH_SMALL",
  "PATCH_MULTI_FILE",
  "REFACTOR",
  "SPIDER_SCAN",
  "DRIFT_CHECK",
  "SECURITY_RULES_AUDIT",
  "DEPLOY_CHECK",
  "UNKNOWN",
];

export default function AIRoutingPanel() {
  const [providers, setProviders] = useState<ProviderDoc[]>([]);
  const [taskType, setTaskType] = useState<string>("PATCH_SMALL");
  const [globalCfg, setGlobalCfg] = useState<RoleRoutingConfig>({});
  const [typeCfg, setTypeCfg] = useState<RoleRoutingConfig>({});
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string>("");

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "provider_registry"), (snap) => {
      const rows: ProviderDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        return { providerId: String(data.providerId || d.id), status: (data.status || "offline") as ProviderStatus };
      });
      setProviders(rows);
    });
    return () => unsub();
  }, []);

  const callableGet = useMemo(() => httpsCallable(functions, "getRoleRouting"), []);
  const callableSet = useMemo(() => httpsCallable(functions, "setRoleRouting"), []);

  async function refresh() {
    setMsg("");
    const res: any = await callableGet({ taskType });
    if (res?.data?.ok) {
      setGlobalCfg(res.data.global || {});
      setTypeCfg(res.data.byTaskType || {});
    } else {
      setMsg("Failed to load routing config.");
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskType]);

  const onlineProviders = useMemo(() => {
    const base = ["simulated", ...providers.filter(p => p.status === "online" || p.status === "degraded").map((p) => p.providerId)];
    return Array.from(new Set(base));
  }, [providers]);

  function updateRule(target: "global" | "type", role: RoleSeat, rule: RoleRule) {
    if (target === "global") setGlobalCfg((prev) => ({ ...prev, [role]: rule }));
    else setTypeCfg((prev) => ({ ...prev, [role]: rule }));
  }

  async function save(target: "global" | "type") {
    setSaving(true);
    setMsg("");
    try {
      const config = target === "global" ? globalCfg : typeCfg;
      const scope = target === "global" ? "global" : "taskType";
      const payload: any = { scope, config };
      if (scope === "taskType") payload.taskType = taskType;

      const res: any = await callableSet(payload);
      if (res?.data?.ok) setMsg("Saved.");
      else setMsg("Save failed.");
    } catch (e: any) {
      setMsg(e?.message || "Save error.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={card()}>
      <h3 style={{ marginTop: 0 }}>AI Seat Routing (Task-Type Aware)</h3>

      <div style={row()}>
        <label style={label()}>Task Type</label>
        <select value={taskType} onChange={(e) => setTaskType(e.target.value)} style={input()}>
          {TASK_TYPES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <button style={btn()} onClick={refresh} disabled={saving}>Refresh</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <RoutingEditor
          title="Global Routing (fallback)"
          providers={onlineProviders}
          cfg={globalCfg}
          onChange={(role, rule) => updateRule("global", role, rule)}
          onSave={() => save("global")}
          saving={saving}
        />
        <RoutingEditor
          title={`Overrides for ${taskType}`}
          providers={onlineProviders}
          cfg={typeCfg}
          onChange={(role, rule) => updateRule("type", role, rule)}
          onSave={() => save("type")}
          saving={saving}
        />
      </div>

      {msg ? <div style={{ marginTop: 12, opacity: 0.85 }}>{msg}</div> : null}

      <div style={{ marginTop: 10, opacity: 0.7, fontSize: 12 }}>
        Notes: “Manual” pins a provider. “Auto” lets AICOMMS choose from a pool using success rate + steps + latency + cost.
      </div>
    </div>
  );
}

function RoutingEditor(props: {
  title: string;
  providers: string[];
  cfg: RoleRoutingConfig;
  onChange: (role: RoleSeat, rule: RoleRule) => void;
  onSave: () => void;
  saving: boolean;
}) {
  const roles: RoleSeat[] = ["architect", "builder", "auditor", "agents", "moderator"];

  return (
    <div style={subcard()}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h4 style={{ margin: 0 }}>{props.title}</h4>
        <button style={btn()} onClick={props.onSave} disabled={props.saving}>Save</button>
      </div>

      <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 12 }}>
        {roles.map((role) => (
          <RoleRow
            key={role}
            role={role}
            providers={props.providers}
            value={props.cfg[role]}
            onChange={(rule) => props.onChange(role, rule)}
          />
        ))}
      </div>
    </div>
  );
}

function RoleRow(props: {
  role: RoleSeat;
  providers: string[];
  value?: RoleRule;
  onChange: (rule: RoleRule) => void;
}) {
  const mode = props.value?.mode || "manual";
  const manualProvider = (props.value && props.value.mode === "manual" ? props.value.provider : "simulated") || "simulated";
  const pool = (props.value && props.value.mode === "auto" ? props.value.pool : []) || [];

  function togglePool(p: string) {
    const set = new Set(pool);
    if (set.has(p)) set.delete(p); else set.add(p);
    props.onChange({ mode: "auto", pool: Array.from(set) });
  }

  return (
    <div style={roleRow()}>
      <div style={{ width: 130, fontWeight: 600 }}>{props.role}</div>

      <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        <select
          value={mode}
          onChange={(e) => {
            const m = e.target.value as "manual" | "auto";
            if (m === "manual") props.onChange({ mode: "manual", provider: manualProvider });
            else props.onChange({ mode: "auto", pool: pool.length ? pool : ["simulated"] });
          }}
          style={input()}
        >
          <option value="manual">manual</option>
          <option value="auto">auto</option>
        </select>

        {mode === "manual" ? (
          <select
            value={manualProvider}
            onChange={(e) => props.onChange({ mode: "manual", provider: e.target.value })}
            style={input()}
          >
            {props.providers.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        ) : (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {props.providers.map((p) => (
              <label key={p} style={{ fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}>
                <input type="checkbox" checked={pool.includes(p)} onChange={() => togglePool(p)} />
                {p}
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}

function subcard(): React.CSSProperties {
  return {
    padding: 12,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(0,0,0,0.12)",
  };
}

function row(): React.CSSProperties {
  return { display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" };
}
function label(): React.CSSProperties {
  return { opacity: 0.8, fontSize: 12, marginRight: 6 };
}
function input(): React.CSSProperties {
  return {
    padding: "8px 10px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "8px 12px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    cursor: "pointer",
  };
}
function roleRow(): React.CSSProperties {
  return {
    padding: 10,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.03)",
    display: "flex",
    gap: 12,
    alignItems: "flex-start",
  };
}
