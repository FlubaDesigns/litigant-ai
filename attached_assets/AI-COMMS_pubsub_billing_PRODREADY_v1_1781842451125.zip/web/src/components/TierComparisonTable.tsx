import React from "react";

type Tier = 0 | 1 | 2 | 3;

const ROWS: Array<{ label: string; t0: string; t1: string; t2: string; t3: string }> = [
  { label: "AI autonomy", t0: "Read-only advice", t1: "Suggestion + human apply", t2: "Conditional apply w/ approvals", t3: "High autonomy w/ tight guardrails" },
  { label: "Approvals", t0: "N/A", t1: "Owner approves changes", t2: "Owner + optional approvers", t3: "Owner override + escalations" },
  { label: "Scope", t0: "Observe only", t1: "Narrow scoped edits", t2: "Scoped automation lanes", t3: "Broader lanes (immutable boundaries)" },
  { label: "Escalations", t0: "Always escalate", t1: "Frequent", t2: "Only on risky deltas", t3: "Only on boundary hits / anomalies" },
];

export default function TierComparisonTable({ selected }: { selected: Tier }) {
  const th = "text-left text-xs uppercase tracking-wide opacity-70 py-2";
  const td = "py-3 text-sm border-t border-white/10 align-top";
  const col = (tier: Tier) =>
    "px-3 " +
    (selected === tier ? "bg-white/10 rounded-xl" : "");

  return (
    <div className="mt-4 overflow-x-auto">
      <table className="min-w-[720px] w-full">
        <thead>
          <tr>
            <th className={th}>Capability</th>
            <th className={th}>Tier 0</th>
            <th className={th}>Tier 1</th>
            <th className={th}>Tier 2</th>
            <th className={th}>Tier 3</th>
          </tr>
        </thead>
        <tbody>
          {ROWS.map((r) => (
            <tr key={r.label}>
              <td className={td + " pr-3 font-medium"}>{r.label}</td>
              <td className={td + col(0)}>{r.t0}</td>
              <td className={td + col(1)}>{r.t1}</td>
              <td className={td + col(2)}>{r.t2}</td>
              <td className={td + col(3)}>{r.t3}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
