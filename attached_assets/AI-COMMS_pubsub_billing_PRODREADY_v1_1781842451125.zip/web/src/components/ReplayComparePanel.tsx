import { useState } from "react";
import { auth } from "../firebase";

async function postJson(path: string, body: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body || {}),
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export default function ReplayComparePanel() {
  const [taskId, setTaskId] = useState("");
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [result, setResult] = useState<any>(null);
  const [msg, setMsg] = useState("");

  async function compare() {
    setMsg("Comparing…");
    const r = await postJson("/compareDeterministicSnapshots", { taskId, snapshotAId: a, snapshotBId: b });
    if (!r.ok) { setMsg(`Error: ${JSON.stringify(r.json)}`); return; }
    setResult(r.json);
    setMsg("Done.");
  }

  return (
    <div style={card()}>
      <h3 style={{ margin: 0 }}>Deterministic Replay Compare</h3>
      <p style={{ opacity: 0.8, marginTop: 6 }}>Compare two snapshot docs and verify input/output/canon hash equivalence.</p>

      <div style={{ display: "grid", gap: 8 }}>
        <input value={taskId} onChange={(e)=>setTaskId(e.target.value)} placeholder="taskId" style={input()} />
        <input value={a} onChange={(e)=>setA(e.target.value)} placeholder="snapshotAId" style={input()} />
        <input value={b} onChange={(e)=>setB(e.target.value)} placeholder="snapshotBId" style={input()} />
        <button onClick={compare} style={btn()}>Compare</button>
        <div style={{ fontSize: 12, opacity: 0.75 }}>{msg}</div>
      </div>

      {result ? (
        <div style={{ marginTop: 10, fontSize: 12, opacity: 0.9 }}>
          <div>sameInputs: <b>{String(result.sameInputs)}</b> · sameOutputs: <b>{String(result.sameOutputs)}</b> · sameCanon: <b>{String(result.sameCanon)}</b></div>
          <pre style={pre()}>{JSON.stringify(result, null, 2)}</pre>
        </div>
      ) : null}
    </div>
  );
}

function card(): React.CSSProperties {
  return { padding: 16, borderRadius: 16, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.05)" };
}
function input(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function btn(): React.CSSProperties {
  return { padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
function pre(): React.CSSProperties {
  return { marginTop: 8, padding: 12, borderRadius: 12, background: "rgba(0,0,0,0.35)", overflowX: "auto" };
}
