import React from "react";
import CTAButton from "./CTAButton";
import TierComparisonTable from "./TierComparisonTable";

type Tier = 0 | 1 | 2 | 3;

export default function AutonomyImpactModal({
  open,
  onClose,
  selectedTier,
  recommendedTier,
  deltaSummary,
}: {
  open: boolean;
  onClose: () => void;
  selectedTier: Tier;
  recommendedTier: Tier;
  deltaSummary: string;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl rounded-3xl border border-white/10 bg-gray-950 p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xl font-bold">Autonomy Impact</div>
            <div className="text-sm opacity-80 mt-1">
              Recommended tier: <span className="font-semibold">Tier {recommendedTier}</span> · Selected tier:{" "}
              <span className="font-semibold">Tier {selectedTier}</span>
            </div>
          </div>
          <button onClick={onClose} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm hover:bg-white/10">
            Close
          </button>
        </div>

        <div className="mt-4 text-sm opacity-80">{deltaSummary}</div>

        <TierComparisonTable selected={selectedTier} />

        <div className="mt-6 flex justify-end">
          <CTAButton onClick={onClose}>Got it</CTAButton>
        </div>
      </div>
    </div>
  );
}
