import { useMemo, useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../firebase";
import GlassCard from "./GlassCard";

type Action =
  | "freeze_project"
  | "downgrade_autonomy"
  | "reset_recommended"
  | "lock_autonomy_switches"
  | "force_reevaluation";

export default function OwnerOverrideControlsPanel() {
  const [leadId, setLeadId] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const canRun = useMemo(() => leadId.trim().length > 3, [leadId]);

  async function log(action: Action) {
    setErr(null);
    setMsg(null);
    if (!canRun) {
      setErr("Provide a leadId/project id.");
      return;
    }
    setBusy(true);
    try {
      await addDoc(collection(db, "admin_actions"), {
        leadId: leadId.trim(),
        action,
        note: note.trim(),
        createdAt: serverTimestamp(),
        // Website-layer only: this is a log entry, not an execution hook.
        source: "website_admin_panel",
      });
      setMsg(`Logged: ${action}`);
    } catch (e: any) {
      setErr(e?.message || "Unable to write admin action log (check Firestore rules).");
    } finally {
      setBusy(false);
    }
  }

  const btn = "rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm hover:bg-white/10 disabled:opacity-50 disabled:hover:bg-white/5";

  return (
    <GlassCard>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold">Owner Override Controls</h2>
          <p className="text-sm opacity-80 mt-1">
            Hidden admin layer. Website-only: actions are <span className="font-semibold">logged</span> to Firestore for downstream enforcement
            (Cortex/brain not touched here).
          </p>
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        <label className="text-sm">
          <div className="opacity-80 mb-1">Lead / Project ID</div>
          <input value={leadId} onChange={(e) => setLeadId(e.target.value)} className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3" placeholder="leadId" />
        </label>

        <label className="text-sm">
          <div className="opacity-80 mb-1">Note (optional)</div>
          <input value={note} onChange={(e) => setNote(e.target.value)} className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3" placeholder="why / context" />
        </label>

        <div className="grid md:grid-cols-2 gap-3 mt-2">
          <button className={btn} disabled={busy} onClick={() => log("freeze_project")}>Freeze project</button>
          <button className={btn} disabled={busy} onClick={() => log("downgrade_autonomy")}>Downgrade autonomy</button>
          <button className={btn} disabled={busy} onClick={() => log("reset_recommended")}>Reset to recommended</button>
          <button className={btn} disabled={busy} onClick={() => log("lock_autonomy_switches")}>Lock autonomy switches</button>
          <button className={btn} disabled={busy} onClick={() => log("force_reevaluation")}>Force re-evaluation</button>
        </div>

        {err && <div className="text-sm text-red-300">{err}</div>}
        {msg && <div className="text-sm text-green-300">{msg}</div>}
      </div>
    </GlassCard>
  );
}
