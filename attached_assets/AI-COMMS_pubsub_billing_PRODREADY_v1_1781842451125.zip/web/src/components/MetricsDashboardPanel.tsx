import { useEffect, useMemo, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";

type RoleSeat = "moderator" | "agents" | "architect" | "builder" | "auditor";

const TASK_TYPES = [
  "RISKSCAN_LEAD_CAPTURE",
  "STRIPE_WEBHOOK_FULFILLMENT",
  "COPY_PAGE_GENERATION",
  "PATCH_SMALL",
  "PATCH_MULTI_FILE",
  "REFACTOR",
  "SPIDER_SCAN",
  "DRIFT_CHECK",
  "SECURITY_RULES_AUDIT",
  "DEPLOY_CHECK",
  "UNKNOWN",
];

export default function MetricsDashboardPanel() {
  const [taskType, setTaskType] = useState<string>("PATCH_SMALL");
  const [role, setRole] = useState<RoleSeat>("builder");
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const callable = useMemo(() => httpsCallable(functions, "getProviderMetrics"), []);

  async function load() {
    setLoading(true);
    setMsg("");
    try {
      const res: any = await callable({ role, taskType, limit: 100 });
      if (res?.data?.ok) setRows(res.data.rows || []);
      else setMsg("Failed to load metrics.");
    } catch (e: any) {
      setMsg(e?.message || "Load error.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [taskType, role]);

  return (
    <div style={card()}>
      <h3 style={{ marginTop: 0 }}>AI Performance Metrics (by Task Type)</h3>

      <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", marginBottom: 10 }}>
        <label style={label()}>Task Type</label>
        <select value={taskType} onChange={(e) => setTaskType(e.target.value)} style={input()}>
          {TASK_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>

        <label style={label()}>Role</label>
        <select value={role} onChange={(e) => setRole(e.target.value as RoleSeat)} style={input()}>
          {(["architect","builder","auditor","agents","moderator"] as RoleSeat[]).map((r) => <option key={r} value={r}>{r}</option>)}
        </select>

        <button style={btn()} onClick={load} disabled={loading}>{loading ? "Loading…" : "Refresh"}</button>
      </div>

      {msg ? <div style={{ opacity: 0.85, marginBottom: 8 }}>{msg}</div> : null}

      <div style={{ overflowX: "auto" }}>
        <table style={table()}>
          <thead>
            <tr>
              <th style={th()}>Provider</th>
              <th style={th()}>Success</th>
              <th style={th()}>Avg steps</th>
              <th style={th()}>Avg duration (ms)</th>
              <th style={th()}>Avg cost (USD)</th>
              <th style={th()}>Runs</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td style={td()}><code>{r.provider}</code></td>
                <td style={td()}>{pct(r.success_rate)}</td>
                <td style={td()}>{num(r.avg_steps)}</td>
                <td style={td()}>{num(r.avg_duration_ms)}</td>
                <td style={td()}>{money(r.avg_cost_usd)}</td>
                <td style={td()}>{num(r.runs_total)}</td>
              </tr>
            ))}
            {!rows.length ? <tr><td style={td()} colSpan={6}>No metrics yet for this role/task type.</td></tr> : null}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 10, opacity: 0.7, fontSize: 12 }}>
        Deterministic routing uses these rollups (success + steps + latency + cost). If a provider consistently takes more steps, it will lose the seat in auto mode.
      </div>
    </div>
  );
}

function pct(v: any) {
  if (v === undefined || v === null) return "";
  const n = Number(v);
  if (Number.isNaN(n)) return "";
  return `${Math.round(n * 100)}%`;
}
function num(v: any) {
  if (v === undefined || v === null) return "";
  const n = Number(v);
  if (Number.isNaN(n)) return String(v);
  return n.toFixed(2).replace(/\.00$/, "");
}
function money(v: any) {
  if (v === undefined || v === null) return "";
  const n = Number(v);
  if (Number.isNaN(n)) return "";
  return `$${n.toFixed(4)}`;
}
function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}
function table(): React.CSSProperties { return { width: "100%", borderCollapse: "collapse", fontSize: 12 }; }
function th(): React.CSSProperties { return { textAlign: "left", padding: 8, borderBottom: "1px solid rgba(255,255,255,0.12)", opacity: 0.8 }; }
function td(): React.CSSProperties { return { padding: 8, borderBottom: "1px solid rgba(255,255,255,0.08)" }; }
function label(): React.CSSProperties { return { opacity: 0.8, fontSize: 12 }; }
function input(): React.CSSProperties {
  return { padding: "8px 10px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.18)", background: "rgba(0,0,0,0.25)", color: "white" };
}
function btn(): React.CSSProperties {
  return { padding: "8px 12px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.18)", background: "rgba(255,255,255,0.08)", color: "white", cursor: "pointer" };
}
