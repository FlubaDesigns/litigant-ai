import React from "react";

export type RiskDelta = {
  title: string;
  delta: "down" | "same" | "up";
  explanation: string;
};

export default function RiskDeltaDisplay({ items }: { items: RiskDelta[] }) {
  return (
    <div className="mt-4 grid gap-3">
      {items.map((it, idx) => (
        <div key={idx} className="rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-center justify-between">
            <div className="font-semibold">{it.title}</div>
            <div className="text-xs uppercase tracking-wide opacity-80">
              {it.delta === "down" ? "Risk ↓" : it.delta === "up" ? "Risk ↑" : "No change"}
            </div>
          </div>
          <div className="text-sm opacity-80 mt-2">{it.explanation}</div>
        </div>
      ))}
    </div>
  );
}
