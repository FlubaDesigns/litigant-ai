import { useEffect, useMemo, useState } from "react";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { auth, db, functions } from "../firebase";

type AppId = "pollsit" | "aicomms_site";

type RuntimeConfigDoc = {
  functionsRegion?: string;
  publicBaseUrl?: string;
  appCheckSiteKey?: string;
  featureFlags?: Record<string, any>;
  updatedAt?: any;
  updatedByUid?: string;
};

function blockStyle(): React.CSSProperties {
  return {
    width: "100%",
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(0,0,0,0.35)",
    color: "white",
    fontFamily: "monospace",
    fontSize: 12,
    whiteSpace: "pre-wrap",
    overflowX: "auto",
  };
}

export default function ConfigVaultPanel() {
  const [appId, setAppId] = useState<AppId>("aicomms_site");
  const [cfg, setCfg] = useState<RuntimeConfigDoc>({
    functionsRegion: "us-central1",
    publicBaseUrl: "",
    appCheckSiteKey: "",
    featureFlags: {},
  });

  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  const uid = auth.currentUser?.uid || "";

  async function load() {
    setErr("");
    setMsg("");
    setLoading(true);
    try {
      const snap = await getDoc(doc(db, "runtime_config", appId));
      if (snap.exists()) {
        setCfg({ ...(snap.data() as any) });
      } else {
        setCfg((x) => ({ ...x, functionsRegion: x.functionsRegion || "us-central1" }));
      }
    } catch (e: any) {
      setErr(e?.message || "Failed to load runtime_config.");
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    setErr("");
    setMsg("");
    if (!uid) {
      setErr("Login required.");
      return;
    }
    setBusy(true);
    try {
      const cleaned: RuntimeConfigDoc = {
        functionsRegion: String(cfg.functionsRegion || "us-central1").trim(),
        publicBaseUrl: String(cfg.publicBaseUrl || "").trim(),
        appCheckSiteKey: String(cfg.appCheckSiteKey || "").trim(),
        featureFlags: cfg.featureFlags || {},
        updatedAt: serverTimestamp(),
        updatedByUid: uid,
      };
      await setDoc(doc(db, "runtime_config", appId), cleaned, { merge: true });
      setMsg("Saved runtime_config.");
    } catch (e: any) {
      setErr(e?.message || "Save failed (are you admin?).");
    } finally {
      setBusy(false);
    }
  }

  async function verifyServer() {
    setErr("");
    setMsg("");
    setBusy(true);
    try {
      const fn = httpsCallable(functions, "verifyConfig");
      const res = await fn({ appId });
      setMsg(`verifyConfig OK: ${JSON.stringify(res.data)}`);
    } catch (e: any) {
      setErr(e?.message || "verifyConfig failed.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appId]);

  const envBlock = useMemo(() => {
    const base = `# ${appId.toUpperCase()} WEB (.env)
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_STORAGE_BUCKET=...
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
VITE_FIREBASE_APPCHECK_SITE_KEY=${cfg.appCheckSiteKey || ""}

# Notes:
# functionsRegion=${cfg.functionsRegion || "us-central1"}
# publicBaseUrl=${cfg.publicBaseUrl || ""}`;
    return base;
  }, [appId, cfg.appCheckSiteKey, cfg.functionsRegion, cfg.publicBaseUrl]);

  const secretsCmdBlock = useMemo(() => {
    if (appId === "pollsit") {
      return `# POLLSIT FUNCTIONS SECRETS
firebase functions:secrets:set POLLSIT_STRIPE_SECRET_KEY
firebase functions:secrets:set POLLSIT_STRIPE_WEBHOOK_SECRET
firebase functions:secrets:set POLLSIT_PUBLIC_BASE_URL

# Optional:
firebase functions:secrets:set POLLSIT_CURRENCY
firebase functions:secrets:set POLLSIT_SPONSOR_DAY_PRICE_CENTS
firebase functions:secrets:set POLLSIT_SPONSOR_WEEK_PRICE_CENTS
firebase functions:secrets:set POLLSIT_SPONSOR_MONTH_PRICE_CENTS`;
    }

    return `# AICOMMS SITE FUNCTIONS SECRETS (adjust to what your functions actually require)
firebase functions:secrets:set PUBLIC_SITE_BASE_URL
firebase functions:secrets:set STRIPE_SECRET_KEY
firebase functions:secrets:set STRIPE_WEBHOOK_SECRET`;
  }, [appId]);

  return (
    <div style={{ marginTop: 16, padding: 14, borderRadius: 16, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.05)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap", alignItems: "baseline" }}>
        <div>
          <div style={{ fontWeight: 900, fontSize: 16 }}>Config Vault</div>
          <div style={{ opacity: 0.75, fontSize: 12, marginTop: 6 }}>
            Writes to <code>/runtime_config/{`{appId}`}</code> (public-safe runtime config only). Secrets stay in Functions Secrets.
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <select
            value={appId}
            onChange={(e) => setAppId(e.target.value as AppId)}
            style={{ padding: "10px 12px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.35)", color: "white" }}
          >
            <option value="aicomms_site">aicomms_site</option>
            <option value="pollsit">pollsit</option>
          </select>

          <button onClick={load} disabled={loading || busy} style={btn()}>
            {loading ? "Loading…" : "Reload"}
          </button>
        </div>
      </div>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <Field
          label="Functions Region"
          value={cfg.functionsRegion || ""}
          onChange={(v) => setCfg((x) => ({ ...x, functionsRegion: v }))}
          placeholder="us-central1"
        />
        <Field
          label="Public Base URL"
          value={cfg.publicBaseUrl || ""}
          onChange={(v) => setCfg((x) => ({ ...x, publicBaseUrl: v }))}
          placeholder="https://example.com"
        />
        <Field
          label="App Check Site Key (reCAPTCHA v3 public key)"
          value={cfg.appCheckSiteKey || ""}
          onChange={(v) => setCfg((x) => ({ ...x, appCheckSiteKey: v }))}
          placeholder="your_site_key"
        />

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 6 }}>
          <button onClick={save} disabled={busy} style={btnPrimary()}>
            {busy ? "Saving…" : "Save Runtime Config"}
          </button>
          <button onClick={verifyServer} disabled={busy} style={btn()}>
            {busy ? "Working…" : "Verify Server Config"}
          </button>
        </div>

        {err && <div style={{ color: "#ff6b6b", marginTop: 6 }}>{err}</div>}
        {msg && <div style={{ color: "#7CFC90", marginTop: 6 }}>{msg}</div>}

        <div style={{ marginTop: 14, opacity: 0.9, fontWeight: 900 }}>Generated Blocks</div>

        <div>
          <div style={{ opacity: 0.75, fontSize: 12, marginBottom: 6 }}>.env template (copy/paste)</div>
          <div style={blockStyle()}>{envBlock}</div>
        </div>

        <div>
          <div style={{ opacity: 0.75, fontSize: 12, marginBottom: 6 }}>Functions secrets commands (copy/paste)</div>
          <div style={blockStyle()}>{secretsCmdBlock}</div>
        </div>
      </div>
    </div>
  );
}

function Field(props: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 6 }}>{props.label}</div>
      <input
        value={props.value}
        onChange={(e) => props.onChange(e.target.value)}
        placeholder={props.placeholder}
        style={{
          width: "100%",
          padding: 12,
          borderRadius: 12,
          border: "1px solid rgba(255,255,255,0.15)",
          background: "rgba(0,0,0,0.35)",
          color: "white",
          outline: "none",
        }}
      />
    </div>
  );
}

function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.08)",
    color: "white",
    fontWeight: 900,
    cursor: "pointer",
  };
}

function btnPrimary(): React.CSSProperties {
  return {
    ...btn(),
    background: "rgba(79,70,229,0.95)",
  };
}