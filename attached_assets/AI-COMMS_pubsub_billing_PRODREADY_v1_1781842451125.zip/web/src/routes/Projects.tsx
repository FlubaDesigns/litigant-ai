import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getMyProjects } from "../lib/portalApi";

type Project = {
  id: string;
  status?: string;
  type?: string;
  updatedAt?: any;
  createdAt?: any;
  brainJobId?: string | null;
  deliverablesUrl?: string | null;
};

function badge(status?: string) {
  const s = String(status || "unknown");
  const base = "inline-flex items-center px-2 py-0.5 rounded-full text-xs border";
  if (s === "delivered") return `${base} border-emerald-500/50 text-emerald-200`;
  if (s === "processing") return `${base} border-sky-500/50 text-sky-200`;
  if (s === "awaiting_intake") return `${base} border-amber-500/50 text-amber-200`;
  return `${base} border-white/20 text-white/70`;
}

export default function Projects() {
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      setErr(null);
      const res = await getMyProjects(100);
      if (!res.ok) {
        setErr(res.json?.error || `Request failed (${res.status})`);
        setLoading(false);
        return;
      }
      setProjects(res.json?.projects || []);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="h1">Projects</h1>
          <p className="p">Track packet jobs, validation, and deliverables across your organization.</p>
        </div>
        <Link to="/portal" className="btn btn-secondary">Back to Portal</Link>
      </div>

      {loading && <p className="p">Loading…</p>}
      {err && <div className="card"><p className="p text-red-300">{err}</p></div>}

      {!loading && !err && (
        <div className="card">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-white/70">
                <tr>
                  <th className="text-left py-2 pr-3">Project</th>
                  <th className="text-left py-2 pr-3">Type</th>
                  <th className="text-left py-2 pr-3">Status</th>
                  <th className="text-left py-2 pr-3">Brain Job</th>
                  <th className="text-left py-2 pr-3">Deliverables</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.id} className="border-t border-white/10">
                    <td className="py-2 pr-3">
                      <Link className="link" to={`/portal/projects/${p.id}`}>{p.id}</Link>
                    </td>
                    <td className="py-2 pr-3">{p.type || "-"}</td>
                    <td className="py-2 pr-3"><span className={badge(p.status)}>{p.status || "unknown"}</span></td>
                    <td className="py-2 pr-3">{p.brainJobId || "-"}</td>
                    <td className="py-2 pr-3">
                      {p.deliverablesUrl ? <a className="link" href={p.deliverablesUrl} target="_blank" rel="noreferrer">Download</a> : "-"}
                    </td>
                  </tr>
                ))}
                {!projects.length && (
                  <tr><td className="py-4 text-white/60" colSpan={5}>No projects yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
