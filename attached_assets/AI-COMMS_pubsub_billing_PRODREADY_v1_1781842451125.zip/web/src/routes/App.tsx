import { Routes, Route, Navigate } from "react-router-dom";

import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

// Public marketing pages
import Home from "./Home";
import Docs from "./Docs";
import Services from "./Services";
import Intuitive from "./Intuitive";
import HowItWorks from "./HowItWorks";
import CaseStudies from "./CaseStudies";
import Intake from "./Intake";
import Legal from "./Legal";

// Monetization + flow pages already in ZIP
import Pricing from "./Pricing";
import Checkout from "./Checkout";
import CheckoutSuccess from "./CheckoutSuccess";
import CheckoutCancel from "./CheckoutCancel";

// Auth/admin pages already in ZIP
import Login from "./Login";
import Admin from "./Admin";
import Dashboard from "./Dashboard";

// Delivery/workflow pages already in ZIP
import GuardrailPacks from "./GuardrailPacks";
import Audit from "./Audit";
import Implementation from "./Implementation";

// NEW
import ClientPortal from "./ClientPortal";
import Portal from "./Portal";
import DIY from "./DIY";
import EvidenceIntake from "./EvidenceIntake";
import Projects from "./Projects";
import ProjectDetail from "./ProjectDetail";

// Risk Scan (Vite-only canonical)
import DriftScan from "./DriftScan";
import RiskScan from "./RiskScan";
import RiskScanQuestions from "./RiskScanQuestions";
import RiskScanResult from "./RiskScanResult";
import Lockdown from "./Lockdown";
import Book from "./Book";

function NotFound() {
  return (
    <div style={{ paddingTop: 40 }}>
      <h1 className="h1">404</h1>
      <p className="p">That page doesn’t exist.</p>
    </div>
  );
}

export default function App() {
  return (
    <>
      <Navbar />

      <main className="container" style={{ paddingTop: 24, paddingBottom: 24 }}>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Home />} />
          <Route path="/docs" element={<Docs />} />
          <Route path="/services" element={<Services />} />
          <Route path="/intuitive" element={<Intuitive />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/case-studies" element={<CaseStudies />} />
          <Route path="/intake" element={<Intake />} />
          <Route path="/legal" element={<Legal />} />

          {/* Pricing + Checkout */}
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/checkout/success" element={<CheckoutSuccess />} />
          <Route path="/checkout/cancel" element={<CheckoutCancel />} />

          {/* Drift Scan */}
          <Route path="/drift-scan" element={<DriftScan />} />

          {/* Risk Scan */}
          <Route path="/risk-scan" element={<RiskScan />} />
          <Route path="/risk-scan/questions" element={<RiskScanQuestions />} />
          <Route path="/risk-scan/result" element={<RiskScanResult />} />
          <Route path="/lockdown" element={<Lockdown />} />
          <Route path="/book" element={<Book />} />

          {/* Auth + Admin */}
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin" element={<Admin />} />

          {/* Delivery / Workflow */}
          <Route path="/packs" element={<GuardrailPacks />} />
          <Route path="/audit" element={<Audit />} />
          <Route path="/implementation" element={<Implementation />} />


          {/* Portal + DIY */}
          <Route path="/portal" element={<Portal />} />
          <Route path="/diy" element={<DIY />} />
          <Route path="/evidence" element={<EvidenceIntake />} />
          <Route path="/portal/projects" element={<Projects />} />
          <Route path="/portal/projects/:projectId" element={<ProjectDetail />} />

          {/* Client portal */}
          <Route path="/client/:leadId" element={<ClientPortal />} />

          {/* Convenience redirects */}
          <Route path="/pack" element={<Navigate to="/packs" replace />} />
          <Route path="/pricing/" element={<Navigate to="/pricing" replace />} />

          {/* Catch-all */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <Footer />
    </>
  );
}