import { useNavigate } from "react-router-dom";

export default function Home() {
  const nav = useNavigate();

  const card =
    "w-full rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 hover:bg-white/10 transition cursor-pointer";
  const title = "text-xl md:text-2xl font-bold";
  const desc = "text-sm md:text-base text-gray-300 mt-2";

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center px-6 py-16">
      <div className="max-w-4xl w-full text-center">
        <h1 className="text-4xl md:text-6xl font-bold">AI that helps… without putting your business at risk</h1>
        <p className="text-lg text-gray-300 max-w-3xl mx-auto mt-5">
          AI-COMMS is a control plane for <span className="font-semibold">safe automation</span>. We help you use AI to save time and reduce mistakes
          — with approvals, logs, and clear boundaries. No passwords. No API keys. No secrets.
        </p>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold" onClick={() => nav("/intake/audit")}>Start (2–3 min)</button>
          <button className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold" onClick={() => nav("/pricing")}>View Pricing</button>
          <button className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold" onClick={() => nav("/diy")}>DIY Kit</button>
        </div>

        <div className="grid md:grid-cols-2 gap-5 mt-10 text-left">
          <div
            className={card}
            onClick={() => nav("/intake/audit")}
            role="button"
            aria-label="Audit and govern my AI"
          >
            <div className="text-3xl">🔐</div>
            <div className={title + " mt-3"}>AI Safety Checkup</div>
            <div className={desc}>
              Find the weak spots before AI causes a costly mistake. Output: clear risk summary + recommended protections + who approves what.
            </div>
            <div className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">
              Start checkup <span aria-hidden>→</span>
            </div>
          </div>

          <div
            className={card}
            onClick={() => nav("/intake/build")}
            role="button"
            aria-label="Build and automate my workflow"
          >
            <div className="text-3xl">⚙️</div>
            <div className={title + " mt-3"}>Automate Safely</div>
            <div className={desc}>
              Turn repeat work into safe automation (with approvals and a paper trail). Output: a build plan + staged rollout with guardrails.
            </div>
            <div className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">
              Start automation intake <span aria-hidden>→</span>
            </div>
          </div>
        </div>

        <div className="mt-10 text-sm text-gray-400">
          Already paid? Continue to <button className="underline" onClick={() => nav("/evidence")}>Evidence Intake</button>.
        </div>
      </div>
    </div>
  );
}
