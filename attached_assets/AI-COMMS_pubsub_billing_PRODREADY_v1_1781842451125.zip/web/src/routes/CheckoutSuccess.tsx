import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function getPlan(): string {
  try {
    return String(localStorage.getItem("aicomms_plan") || "").toLowerCase();
  } catch {
    return "";
  }
}

export default function CheckoutSuccess() {
  const nav = useNavigate();

  useEffect(() => {
    const plan = getPlan();
    const next = plan === "diy" ? "/diy" : "/evidence";
    const t = setTimeout(() => nav(next), 1400);
    return () => clearTimeout(t);
  }, [nav]);

  const plan = getPlan();
  const nextLabel = plan === "diy" ? "DIY Kit download" : "Evidence Intake";

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center text-center px-6">
      <h1 className="text-4xl font-bold mb-4">Payment complete.</h1>
      <p className="text-gray-300 max-w-xl">
        Next: <span className="font-semibold">{nextLabel}</span>.
      </p>
      <p className="text-gray-500 mt-3 text-sm">Redirecting…</p>
    </div>
  );
}
