import { useNavigate } from "react-router-dom";

export default function DIY() {
  const nav = useNavigate();

  const kitHref = "/packs/aicomms_diy_packet.zip";

  return (
    <div className="min-h-screen bg-gray-950 text-white px-6 py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold">DIY — Self Implement Kit</h1>
        <p className="text-gray-300 mt-4">
          If you want to implement AI-COMMS governance yourself, this kit gives you the packet templates and
          a structured workflow. You keep control. We provide the rails.
        </p>

        <div className="mt-8 rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-2xl font-semibold">Download</h2>
          <p className="text-gray-300 mt-2">Includes PACKET/RESPONSE templates and implementation guidance.</p>

          <a
            href={kitHref}
            className="inline-flex mt-5 px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold"
          >
            Download DIY Kit (.zip)
          </a>

          <div className="mt-6 text-sm text-gray-400">
            Next: read the implementation guide and wire it to your workflow.
          </div>

          <div className="mt-4 flex flex-wrap gap-3">
            <button
              className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold"
              onClick={() => nav("/implementation")}
            >
              Implementation Guide
            </button>
            <button
              className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold"
              onClick={() => nav("/docs")}
            >
              Documentation
            </button>
            <button
              className="px-5 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold"
              onClick={() => nav("/pricing")}
            >
              Compare DFY vs DIY
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
