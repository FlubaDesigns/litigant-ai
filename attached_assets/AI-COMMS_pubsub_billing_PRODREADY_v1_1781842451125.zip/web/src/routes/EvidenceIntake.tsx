import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";
import Section from "../components/Section";
import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";
import RiskDeltaDisplay, { type RiskDelta } from "../components/RiskDeltaDisplay";
import AutonomyImpactModal from "../components/AutonomyImpactModal";
import TierComparisonTable from "../components/TierComparisonTable";
import { violatesIntakeGuardrails } from "../lib/intakeGuardrails";

function safeTrim(s: string) {
  return (s || "").trim();
}

type RiskTolerance = "conservative" | "balanced" | "aggressive";
type DeployMode = "none" | "manual" | "ci_cd";
type ApprovalStructure = "owner_only" | "owner_plus_approvers";

type UnknownPolicy = "escalate" | "sandbox" | "allow";

// Autonomy tier selector (Tier 0–3)
type AutonomyTier = 0 | 1 | 2 | 3;

// Package mode: Done-For-You vs DIY kit
type PackageMode = "dfy" | "diy";

function recommendAutonomyTier(input: {
  riskTolerance: RiskTolerance;
  unknownPolicy: UnknownPolicy;
  approvalStructure: ApprovalStructure;
}): AutonomyTier {
  // Conservative + escalate => Tier 1
  if (input.riskTolerance === "conservative" || input.unknownPolicy === "escalate") return input.approvalStructure === "owner_plus_approvers" ? 1 : 1;
  // Balanced => Tier 2 (if approvals exist), else Tier 1
  if (input.riskTolerance === "balanced") return input.approvalStructure === "owner_plus_approvers" ? 2 : 1;
  // Aggressive => Tier 3 (still bounded), unless approvals are minimal -> Tier 2
  return input.approvalStructure === "owner_plus_approvers" ? 3 : 2;
}

function tierDeltaSummary(recommended: AutonomyTier, selected: AutonomyTier) {
  if (selected === recommended) return "You’re aligned with the recommended autonomy tier based on your declared risk posture and approval structure.";
  if (selected > recommended) {
    return "You selected a higher autonomy tier than recommended. This increases operational speed, but also increases the blast radius if guardrails are misconfigured. Immutable boundaries still apply.";
  }
  return "You selected a lower autonomy tier than recommended. This reduces risk and increases human control, but may slow delivery and reduce automation ROI.";
}

function buildRiskDelta(recommended: AutonomyTier, selected: AutonomyTier): RiskDelta[] {
  const up = selected > recommended;
  const down = selected < recommended;
  return [
    {
      title: "Change control",
      delta: up ? "up" : down ? "down" : "same",
      explanation: up
        ? "More changes can be applied automatically inside scoped lanes; escalations occur on boundary hits."
        : down
        ? "More changes require human review/approval; fewer automated applies."
        : "No change to change-control posture.",
    },
    {
      title: "Escalation frequency",
      delta: up ? "down" : down ? "up" : "same",
      explanation: up
        ? "Fewer escalations during normal operation; only high-risk deltas or boundary hits escalate."
        : down
        ? "More escalations and checkpoints; higher human involvement."
        : "No change to escalation behavior.",
    },
    {
      title: "Auditability",
      delta: "same",
      explanation: "All tiers keep immutable audit logging requirements; autonomy only changes how often humans must approve.",
    },
  ];
}

export default function EvidenceIntake() {
  const nav = useNavigate();

  const leadId = useMemo(() => localStorage.getItem("aicomms_leadId") || "", []);
  const email = useMemo(() => localStorage.getItem("aicomms_email") || "", []);
  const plan = useMemo(() => localStorage.getItem("aicomms_plan") || "", []);

  // Evidence Pack core
  const [projectName, setProjectName] = useState("");
  const [automationDomain, setAutomationDomain] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [stack, setStack] = useState("");
  const [envs, setEnvs] = useState("dev,staging,prod");
  const [deployMode, setDeployMode] = useState<DeployMode>("ci_cd");
  const [deployProvider, setDeployProvider] = useState("GitHub Actions");

  // File refs only — no uploads, no secrets
  const [artifactRefs, setArtifactRefs] = useState("e.g., docs/ai-policy.pdf (redacted)\nlogs/sample-run.txt (redacted)\nlink:https://...");

  // Scope boundaries
  const [sensitivePaths, setSensitivePaths] = useState(".env\nsecrets/\nconfig/");
  const [neverTouchPaths, setNeverTouchPaths] = useState("governance/\ninfra/\nfunctions/");

  // Governance posture inputs
  const [riskTolerance, setRiskTolerance] = useState<RiskTolerance>("balanced");
  const [unknownPolicy, setUnknownPolicy] = useState<UnknownPolicy>("escalate");
  const [approvalStructure, setApprovalStructure] = useState<ApprovalStructure>("owner_only");
  const [ownerName, setOwnerName] = useState("");
  const [ownerEmail, setOwnerEmail] = useState(email);
  const [approverEmails, setApproverEmails] = useState("");

  // Autonomy tier system fields
  const [selectedTier, setSelectedTier] = useState<AutonomyTier>(2);
  const [tierOverrideAcknowledgment, setTierOverrideAcknowledgment] = useState("");

  const recommendedTier = useMemo(
    () => recommendAutonomyTier({ riskTolerance, unknownPolicy, approvalStructure }),
    [riskTolerance, unknownPolicy, approvalStructure]
  );

  const tierOverrideFlag = useMemo(() => selectedTier !== recommendedTier, [selectedTier, recommendedTier]);
  const deltaSummary = useMemo(() => tierDeltaSummary(recommendedTier, selectedTier), [recommendedTier, selectedTier]);
  const riskDelta = useMemo(() => buildRiskDelta(recommendedTier, selectedTier), [recommendedTier, selectedTier]);

  const [impactOpen, setImpactOpen] = useState(false);

  const [notes, setNotes] = useState("");

  const [packageMode, setPackageMode] = useState<PackageMode>("dfy");

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  const canSubmit = useMemo(() => {
    return safeTrim(projectName).length >= 2 && safeTrim(ownerEmail).includes("@");
  }, [projectName, ownerEmail]);

  function guardrailCheckAll(): string | null {
    const fields = [
      projectName,
      automationDomain,
      repoUrl,
      stack,
      envs,
      deployProvider,
      artifactRefs,
      sensitivePaths,
      neverTouchPaths,
      ownerName,
      ownerEmail,
      approverEmails,
      notes,
      tierOverrideAcknowledgment,
    ];
    for (const f of fields) {
      const v = violatesIntakeGuardrails(f);
      if (v) return v;
    }
    return null;
  }

  async function submit() {
    setErr(null);
    setOk(null);

    const v = guardrailCheckAll();
    if (v) {
      setErr(v);
      return;
    }

    if (!canSubmit) {
      setErr("Project name and a valid owner email are required.");
      return;
    }

    if (tierOverrideFlag && safeTrim(tierOverrideAcknowledgment).length < 6) {
      setErr("Type an acknowledgment (at least 6 characters) to override the recommended autonomy tier.");
      return;
    }

    setBusy(true);
    try {
      const fn = httpsCallable(functions, "submitEvidencePack");

      // Website-layer structure: project_intake_packets concept (backend storage may be implemented separately).
      const autonomyChangeHistory = [
        {
          from: recommendedTier,
          to: selectedTier,
          at: new Date().toISOString(),
          note: tierOverrideFlag ? safeTrim(tierOverrideAcknowledgment) : "aligned_with_recommendation",
        },
      ];

      const packet = {
        // Collection: project_intake_packets
        leadProfile: {
          leadId: safeTrim(leadId) || null,
          email: safeTrim(ownerEmail),
          plan: safeTrim(plan),
          company: safeTrim((localStorage.getItem("aicomms_company") || "")),
        },
        automationDomain: safeTrim(automationDomain),
        riskScore: 0, // website-layer placeholder; final scoring occurs in governance engine
        governancePosture: {
          riskTolerance,
          unknownPolicy,
          approvalStructure,
          ownerName: safeTrim(ownerName),
          ownerEmail: safeTrim(ownerEmail),
          approverEmails: safeTrim(approverEmails),
        },
        userDeclaredAutonomyPreference: {
          recommendedTier,
          selectedTier,
          tierOverrideFlag,
          tierOverrideAcknowledgment: safeTrim(tierOverrideAcknowledgment),
          tierOverrideTimestamp: new Date().toISOString(),
          autonomyChangeHistory,
        },
        uploadedArtifacts: {
          // file refs only
          artifactRefs: safeTrim(artifactRefs),
        },
        scopeBoundaries: {
          sensitivePaths,
          neverTouchPaths,
        },
        project: {
          projectName: safeTrim(projectName),
          repoUrl: safeTrim(repoUrl),
          stack: safeTrim(stack),
          envs: safeTrim(envs),
          deployMode,
          deployProvider: safeTrim(deployProvider),
        },
        notes: safeTrim(notes),
        source: "evidence_intake_v2",
      };

      // Back-compat payload for existing function:
      const payload = {
        leadId: safeTrim(leadId) || null,
        email: safeTrim(ownerEmail),
        projectName: safeTrim(projectName),
        repoUrl: safeTrim(repoUrl),
        stack: safeTrim(stack),
        envs: safeTrim(envs),
        deployMode,
        deployProvider: safeTrim(deployProvider),
        sensitivePaths,
        neverTouchPaths,
        riskTolerance,
        unknownPolicy,
        autonomyPref: `tier_${selectedTier}`,
        ownerName: safeTrim(ownerName),
        ownerEmail: safeTrim(ownerEmail),
        approverEmails: safeTrim(approverEmails),
        notes: safeTrim(notes),
        plan: safeTrim(plan),
        packageMode,
        source: "evidence_intake",
        governance_profile: (() => {
          try {
            const raw = localStorage.getItem("aicomms_governance_profile");
            return raw ? JSON.parse(raw) : null;
          } catch {
            return null;
          }
        })(),
        // New structured packet:
        projectIntakePacket: packet,
      };

      const res: any = await fn(payload);
      const evidenceId = res?.data?.evidenceId as string | undefined;
      const socketJobId = res?.data?.socketJobId as string | undefined;
      const diyPacketUrl = res?.data?.diyPacketUrl as string | undefined;

      if (evidenceId && socketJobId) setOk(`Submitted. Evidence ID: ${evidenceId} · Brain Job: ${socketJobId}`);
      else if (evidenceId && diyPacketUrl) setOk(`Submitted. Evidence ID: ${evidenceId} · DIY Packet: ${diyPacketUrl}`);
      else if (evidenceId) setOk(`Submitted. Evidence ID: ${evidenceId}`);
      else setOk(socketJobId ? `Submitted. Brain Job: ${socketJobId}` : "Submitted.");
      if (leadId) nav(`/client/${encodeURIComponent(leadId)}?token=${encodeURIComponent(res?.data?.clientToken || "")}`);
    } catch (e: any) {
      setErr(e?.message || "Failed to submit.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Section title="Evidence Intake">
      <GlassCard>
        <h1 className="h1">Evidence Intake</h1>
        <p className="p">
          Wizard 2 rebuilt cleanly. This captures a structured Evidence Pack (file references only). No secrets. No credentials.
          No API keys. Scope boundaries enforced.
        </p>

        <div className="mt-4 text-sm opacity-80">
          {leadId ? (
            <div>
              Lead: <code>{leadId}</code> · Plan: <code>{plan || "unknown"}</code>
            </div>
          ) : (
            <div>
              Lead: <em>not found</em> (ok — we’ll store intake under your email)
            </div>
          )}
        </div>

        {/* Project */}
        <div className="mt-6 grid gap-4">
          {/* Package Mode */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Delivery Package</div>
            <div className="text-sm opacity-80 mt-1">
              Choose whether you want a Done-For-You generated packet (Brain + Conscience) or a DIY implementation kit.
            </div>
            <div className="mt-3 grid md:grid-cols-2 gap-3">
              <select
                value={packageMode}
                onChange={(e) => setPackageMode(e.target.value as PackageMode)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
              >
                <option value="dfy">Done For You (recommended)</option>
                <option value="diy">DIY — Self Implement</option>
              </select>
              <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm opacity-90">
                {packageMode === "dfy" ? (
                  <span>
                    We will generate your packet through the Brain + Conscience pipeline (Guardrails-validated). If you provide a repo URL, the system can build a deterministic deliverable.
                  </span>
                ) : (
                  <span>
                    You’ll receive a DIY packet kit you can implement yourself. No Brain execution is triggered.
                    <span className="block mt-2 opacity-80">Download: <a className="underline" href="/packs/aicomms_diy_packet.zip">/packs/aicomms_diy_packet.zip</a></span>
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Project</div>
            <div className="grid md:grid-cols-2 gap-3 mt-3">
              <input
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Project name"
              />
              <input
                value={automationDomain}
                onChange={(e) => setAutomationDomain(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Automation domain (e.g., support triage, compliance review)"
              />
              <input
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                className="md:col-span-2 rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Repo URL (optional)"
              />
              <input
                value={stack}
                onChange={(e) => setStack(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Stack (e.g., Vite+React+Firebase+Stripe)"
              />
              <input
                value={envs}
                onChange={(e) => setEnvs(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Environments (comma-separated)"
              />
              <select
                value={deployMode}
                onChange={(e) => setDeployMode(e.target.value as DeployMode)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
              >
                <option value="ci_cd">CI/CD</option>
                <option value="manual">Manual deploy</option>
                <option value="none">No deploy yet</option>
              </select>
              <input
                value={deployProvider}
                onChange={(e) => setDeployProvider(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Deploy provider"
              />
            </div>
          </div>

          {/* Artifacts (refs only) */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Uploaded Artifacts (File Refs Only)</div>
            <div className="text-sm opacity-80 mt-1">
              Paste paths, filenames, or links to <em>redacted</em> artifacts. Do not upload/paste secrets.
            </div>
            <textarea
              value={artifactRefs}
              onChange={(e) => setArtifactRefs(e.target.value)}
              className="mt-3 w-full min-h-[120px] rounded-xl bg-black/40 border border-white/10 px-4 py-3"
            />
          </div>

          {/* Scope boundaries */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Scope Boundaries</div>
            <div className="grid md:grid-cols-2 gap-3 mt-3">
              <label className="text-sm">
                <div className="opacity-80 mb-1">Sensitive paths (examples only)</div>
                <textarea
                  value={sensitivePaths}
                  onChange={(e) => setSensitivePaths(e.target.value)}
                  className="w-full min-h-[110px] rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                />
              </label>
              <label className="text-sm">
                <div className="opacity-80 mb-1">Never-touch paths</div>
                <textarea
                  value={neverTouchPaths}
                  onChange={(e) => setNeverTouchPaths(e.target.value)}
                  className="w-full min-h-[110px] rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                />
              </label>
            </div>
          </div>

          {/* Governance posture */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Governance Posture</div>

            <div className="grid md:grid-cols-3 gap-3 mt-3">
              <label className="text-sm">
                <div className="opacity-80 mb-1">Risk tolerance</div>
                <select value={riskTolerance} onChange={(e) => setRiskTolerance(e.target.value as RiskTolerance)} className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3">
                  <option value="conservative">Conservative</option>
                  <option value="balanced">Balanced</option>
                  <option value="aggressive">Aggressive</option>
                </select>
              </label>

              <label className="text-sm">
                <div className="opacity-80 mb-1">Unknown policy</div>
                <select value={unknownPolicy} onChange={(e) => setUnknownPolicy(e.target.value as UnknownPolicy)} className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3">
                  <option value="escalate">Escalate</option>
                  <option value="sandbox">Sandbox</option>
                  <option value="allow">Allow (bounded)</option>
                </select>
              </label>

              <label className="text-sm">
                <div className="opacity-80 mb-1">Approval structure</div>
                <select value={approvalStructure} onChange={(e) => setApprovalStructure(e.target.value as ApprovalStructure)} className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3">
                  <option value="owner_only">Owner only</option>
                  <option value="owner_plus_approvers">Owner + approvers</option>
                </select>
              </label>
            </div>

            <div className="grid md:grid-cols-2 gap-3 mt-3">
              <input
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Owner name"
              />
              <input
                value={ownerEmail}
                onChange={(e) => setOwnerEmail(e.target.value)}
                className="rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Owner email"
              />
              <input
                value={approverEmails}
                onChange={(e) => setApproverEmails(e.target.value)}
                className="md:col-span-2 rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Approver emails (comma-separated, optional)"
              />
            </div>
          </div>

          {/* Autonomy tiers */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="font-semibold">Autonomy Tier System (Client Control Panel)</div>
                <div className="text-sm opacity-80 mt-1">
                  Recommended tier: <span className="font-semibold">Tier {recommendedTier}</span>
                </div>
              </div>
              <button
                onClick={() => setImpactOpen(true)}
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm hover:bg-white/10"
              >
                See impact
              </button>
            </div>

            <div className="mt-4 grid md:grid-cols-2 gap-4">
              <label className="text-sm">
                <div className="opacity-80 mb-1">Selected tier (0–3)</div>
                <select
                  value={selectedTier}
                  onChange={(e) => setSelectedTier(Number(e.target.value) as AutonomyTier)}
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                >
                  <option value={0}>Tier 0 — Observe</option>
                  <option value={1}>Tier 1 — Guided</option>
                  <option value={2}>Tier 2 — Conditional</option>
                  <option value={3}>Tier 3 — High autonomy (bounded)</option>
                </select>
              </label>

              <div className="text-sm">
                <div className="opacity-80 mb-1">Consequence summary</div>
                <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm opacity-90">
                  {deltaSummary}
                </div>
              </div>
            </div>

            <TierComparisonTable selected={selectedTier} />

            <RiskDeltaDisplay items={riskDelta} />

            {tierOverrideFlag && (
              <div className="mt-4 rounded-2xl border border-yellow-400/30 bg-yellow-500/10 p-4">
                <div className="font-semibold">Override acknowledgment required</div>
                <div className="text-sm opacity-80 mt-1">
                  You’re overriding the recommended tier. Type acknowledgment to proceed.
                </div>
                <input
                  value={tierOverrideAcknowledgment}
                  onChange={(e) => setTierOverrideAcknowledgment(e.target.value)}
                  className="mt-3 w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                  placeholder='Type: "I understand the autonomy change impact."'
                />
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="font-semibold">Notes</div>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="mt-3 w-full min-h-[100px] rounded-xl bg-black/40 border border-white/10 px-4 py-3"
              placeholder="Optional context (no secrets)"
            />
          </div>

          {err && (
            <div className="rounded-2xl border border-red-400/30 bg-red-500/10 p-4 text-sm text-red-200">
              {err}
            </div>
          )}
          {ok && (
            <div className="rounded-2xl border border-green-400/30 bg-green-500/10 p-4 text-sm text-green-200">
              {ok}
            </div>
          )}

          <div className="flex justify-end">
            <CTAButton onClick={submit} disabled={busy}>
              {busy ? "Submitting…" : "Submit Evidence Pack"}
            </CTAButton>
          </div>
        </div>

        <AutonomyImpactModal
          open={impactOpen}
          onClose={() => setImpactOpen(false)}
          selectedTier={selectedTier}
          recommendedTier={recommendedTier}
          deltaSummary={deltaSummary}
        />
      </GlassCard>
    </Section>
  );
}
