import { Link } from "react-router-dom";

export default function Lockdown() {
  return (
    <div className="min-h-screen bg-black text-white px-6 py-14">
      <div className="max-w-4xl mx-auto space-y-12">
        {/* HERO */}
        <header className="space-y-4">
          <div className="inline-flex items-center gap-2 text-xs tracking-widest uppercase text-gray-400">
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">AI-COMMS</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">DFY Lockdown</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">Governance Install</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            Done-For-You AI Governance Lockdown
          </h1>

          <p className="text-lg text-gray-300 max-w-3xl">
            If your AI touches client deliverables, pricing, compliance, or operations — you don’t need “better prompts.”
            You need governance: scope binding, controlled tool exposure, logging, and rollback paths.
          </p>

          <div className="pt-3 flex flex-col sm:flex-row gap-3">
            <Link
              to="/pricing"
              className="inline-flex items-center justify-center bg-white text-black px-8 py-4 rounded-lg font-semibold hover:bg-gray-200 transition"
            >
              View Pricing
            </Link>
            <Link
              to="/risk-scan"
              className="inline-flex items-center justify-center border border-gray-700 px-8 py-4 rounded-lg hover:bg-gray-900 transition"
            >
              Take the Risk Scan
            </Link>
          </div>
        </header>

        {/* WHAT YOU GET */}
        <section className="rounded-2xl border border-gray-800 bg-gray-950 p-6 space-y-5">
          <h2 className="text-2xl font-semibold">What Lockdown Includes</h2>

          <ul className="text-gray-300 space-y-2 list-disc pl-5">
            <li><strong>Scope Binding:</strong> AI tasks are constrained to approved objectives and output formats.</li>
            <li><strong>Controlled Capability Surface:</strong> tools are allowed/denied per tier and logged by invocation.</li>
            <li><strong>Drift Containment:</strong> checks detect mutation over time and force escalation when needed.</li>
            <li><strong>Audit Trail:</strong> who changed what, when, and under which rule-set.</li>
            <li><strong>Rollback Path:</strong> revert AI behavior to a known-safe state quickly.</li>
          </ul>

          <div className="text-sm text-gray-400">
            Governance is infrastructure. It’s the difference between AI “helping” and AI being safe in operations.
          </div>
        </section>

        {/* CTA */}
        <section className="rounded-2xl border border-gray-800 bg-black p-6 space-y-4">
          <h2 className="text-xl font-semibold">If your score is HIGH or CRITICAL</h2>
          <p className="text-gray-300">
            Lockdown is the fastest path to prevent operational drift and client-facing incidents.
          </p>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link
              to="/pricing"
              className="inline-flex items-center justify-center bg-white text-black px-8 py-4 rounded-lg font-semibold hover:bg-gray-200 transition"
            >
              Choose Lockdown Path
            </Link>
            <Link
              to="/intake"
              className="inline-flex items-center justify-center border border-gray-700 px-8 py-4 rounded-lg hover:bg-gray-900 transition"
            >
              Start Intake
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}