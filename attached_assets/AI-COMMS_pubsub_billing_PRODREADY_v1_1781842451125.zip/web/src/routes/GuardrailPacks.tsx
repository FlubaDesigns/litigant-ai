import React from "react";

export default function GuardrailPacks() {
  return (
    <div className="min-h-screen bg-black text-white px-6 py-16">
      <div className="max-w-5xl mx-auto space-y-16">

        <div className="space-y-6 text-center">
          <h1 className="text-4xl font-bold">AI Guardrail Packs</h1>
          <p className="text-lg text-gray-300">
            Structured AI control systems designed to stabilize automation,
            eliminate hallucinations, and prevent workflow chaos.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-10">

          <div className="border border-gray-700 p-8 rounded-xl space-y-4">
            <h2 className="text-2xl font-semibold">Email Stabilization Pack</h2>
            <p className="text-gray-400">
              Prevent embarrassing replies, hallucinated answers, and
              inconsistent tone in AI-driven email systems.
            </p>
            <ul className="text-gray-400 space-y-2">
              <li>• Prompt architecture framework</li>
              <li>• Escalation logic rules</li>
              <li>• Failure containment design</li>
              <li>• Tone control enforcement</li>
            </ul>
          </div>

          <div className="border border-gray-700 p-8 rounded-xl space-y-4">
            <h2 className="text-2xl font-semibold">Customer Support Guardrails</h2>
            <p className="text-gray-400">
              Create predictable, compliant, and safe AI responses across support channels.
            </p>
            <ul className="text-gray-400 space-y-2">
              <li>• Multi-agent containment structure</li>
              <li>• Conflict resolution logic</li>
              <li>• Structured escalation policy</li>
              <li>• Quality control checklist</li>
            </ul>
          </div>

          <div className="border border-gray-700 p-8 rounded-xl space-y-4">
            <h2 className="text-2xl font-semibold">Intake & Lead Routing Pack</h2>
            <p className="text-gray-400">
              Stabilize intake forms and prevent misrouted or hallucinated client data.
            </p>
            <ul className="text-gray-400 space-y-2">
              <li>• Validation structure</li>
              <li>• Response gating system</li>
              <li>• Controlled routing logic</li>
              <li>• Version tracking protocol</li>
            </ul>
          </div>

          <div className="border border-gray-700 p-8 rounded-xl space-y-4">
            <h2 className="text-2xl font-semibold">Founder AI Operating Manual</h2>
            <p className="text-gray-400">
              Governance framework for companies using multiple AI tools simultaneously.
            </p>
            <ul className="text-gray-400 space-y-2">
              <li>• Canon-style structure</li>
              <li>• Closed-loop workflow design</li>
              <li>• Execution honesty framework</li>
              <li>• Drift containment strategy</li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}