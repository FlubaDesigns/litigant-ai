import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";
import CTAButton from "../components/CTAButton";

type Tier = "audit" | "pro" | "enterprise";

const TIER_LABEL: Record<Tier, string> = {
  audit: "Audit",
  pro: "Pro",
  enterprise: "Enterprise",
};

const TIER_DESC: Record<Tier, string> = {
  audit: "Governance audit + recommended guardrail pack.",
  pro: "Audit + proposal + contract automation (tier gated).",
  enterprise: "Pro + enterprise governance posture (expands over time).",
};

function safeTrim(s: string) {
  return (s || "").trim();
}

function normalizeTier(v: string | null): Tier {
  const s = String(v || "").trim().toLowerCase();
  if (s === "enterprise") return "enterprise";
  if (s === "pro") return "pro";
  return "audit";
}


export default function Intake() {
  const nav = useNavigate();
  const loc = useLocation();

  const [tier, setTier] = useState<Tier>("audit");

  const [company, setCompany] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [aiGoal, setAiGoal] = useState("");
  const [notes, setNotes] = useState("");

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // ✅ Preselect tier from querystring: /intake?tier=pro
  useEffect(() => {
    const qs = new URLSearchParams(loc.search);
    const t = normalizeTier(qs.get("tier"));
    setTier(t);
    // Only depends on loc.search; user can still change tier after load
  }, [loc.search]);

  const canSubmit = useMemo(() => {
    const e = safeTrim(email);
    const c = safeTrim(company);
    return c.length >= 2 && e.includes("@") && e.includes(".");
  }, [company, email]);

  async function submit() {
    setErr(null);
    if (!canSubmit) {
      setErr("Company and a valid email are required.");
      return;
    }

    setBusy(true);
    try {
      // Unified lead creation: ALWAYS via Cloud Function (no client writes to /leads).
      const fn = httpsCallable(functions, "submitRiskScan");

      const payload = {
        name: safeTrim(name),
        email: safeTrim(email),
        company: safeTrim(company),
        notes: safeTrim(notes),
        ai_goal: safeTrim(aiGoal),
        tier,
        // Intake is not a risk scan; we store a zero score with empty answers.
        score: 0,
        answers: [],
        source: "intake",
      };

      const res: any = await fn(payload);
      const leadId = res?.data?.leadId || safeTrim(email).toLowerCase();

      nav(
        `/checkout?leadId=${encodeURIComponent(leadId)}&tier=${encodeURIComponent(
          tier
        )}&email=${encodeURIComponent(safeTrim(email))}`
      );
    } catch (e: any) {
      setErr(e?.message || "Failed to create lead.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Section title="Intake">
      <GlassCard>
        <h1 className="h1">Intake</h1>
        <p className="p">
          Choose a tier, tell us what you’re trying to do with AI, and we’ll route you into the correct automated lane.
        </p>

        {/* Tier selection */}
        <div className="mt-6">
          <div className="text-sm opacity-80 mb-2">Tier</div>

          <div className="grid gap-3 md:grid-cols-3">
            {(["audit", "pro", "enterprise"] as Tier[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTier(t)}
                className={`rounded-2xl border px-4 py-4 text-left transition ${
                  tier === t
                    ? "border-indigo-500 bg-indigo-600/15"
                    : "border-white/10 bg-white/5 hover:bg-white/7"
                }`}
                disabled={busy}
              >
                <div className="font-semibold text-lg">{TIER_LABEL[t]}</div>
                <div className="text-xs opacity-80 mt-1">{TIER_DESC[t]}</div>
                <div className="text-xs opacity-70 mt-2">
                  Selected: <code>{tier === t ? "YES" : "NO"}</code>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <div className="mt-6 grid gap-4">
          <div>
            <div className="text-sm opacity-80 mb-1">Company *</div>
            <input
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              placeholder="e.g., Smith & Co. Accounting"
              disabled={busy}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <div className="text-sm opacity-80 mb-1">Name (optional)</div>
              <input
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                disabled={busy}
              />
            </div>

            <div>
              <div className="text-sm opacity-80 mb-1">Email *</div>
              <input
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                disabled={busy}
              />
            </div>
          </div>

          <div>
            <div className="text-sm opacity-80 mb-1">What are you trying to do with AI?</div>
            <input
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none"
              value={aiGoal}
              onChange={(e) => setAiGoal(e.target.value)}
              placeholder="e.g., automate email responses without hallucinations"
              disabled={busy}
            />
          </div>

          <div>
            <div className="text-sm opacity-80 mb-1">Notes (optional)</div>
            <textarea
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 outline-none min-h-[120px]"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="What’s breaking? What have you tried? What matters most?"
              disabled={busy}
            />
          </div>
        </div>

        {/* Submit */}
        <div className="mt-6 flex flex-wrap gap-3 items-center">
          <CTAButton onClick={submit} disabled={busy || !canSubmit}>
            {busy ? "Submitting…" : `Continue to Checkout (${TIER_LABEL[tier]})`}
          </CTAButton>

          <div className="text-xs opacity-70">
            Flow: Pricing → Intake (tier preset) → Checkout → Stripe → Webhook sets tier → Functions enforce.
          </div>
        </div>

        {err && (
          <div className="mt-4 text-red-400">
            <strong>Error:</strong> {err}
          </div>
        )}
      </GlassCard>
    </Section>
  );
}