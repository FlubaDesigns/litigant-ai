import Section from "../components/Section";
import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";

function TocLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      style={{
        display: "block",
        padding: "8px 10px",
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.08)",
        textDecoration: "none",
        opacity: 0.9
      }}
    >
      {label}
    </a>
  );
}

export default function Docs() {
  return (
    <>
      <Section kicker="Strategy Docs" title="Risk, Monetization, Positioning">
        <div className="grid" style={{ gap: 14 }}>
          <GlassCard>
            <div
              style={{
                display: "flex",
                gap: 14,
                alignItems: "flex-start",
                flexWrap: "wrap"
              }}
            >
              <div style={{ flex: "1 1 360px" }}>
                <div className="h3">What this page is</div>
                <p className="p" style={{ marginTop: 8 }}>
                  These are the three core business docs embedded into the site, so the
                  system can sell itself without sending people to scattered notes.
                </p>
                <p className="p" style={{ marginTop: 8, opacity: 0.9 }}>
                  If you want a PDF export later, we can generate one — but the source
                  of truth stays here.
                </p>
              </div>

              <div style={{ flex: "0 0 260px", display: "grid", gap: 10 }}>
                <TocLink href="#risk-audit" label="1) Risk Audit" />
                <TocLink href="#monetization" label="2) Monetization Strategy" />
                <TocLink href="#positioning" label="3) Portfolio Positioning" />
              </div>
            </div>
          </GlassCard>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <CTAButton to="/pricing" label="See Pricing" />
            <CTAButton to="/packs" label="Browse Guardrail Packs" />
            <CTAButton to="/intake" label="Start an Intake" variant="secondary" />
          </div>
        </div>
      </Section>

      {/* 1) RISK AUDIT */}
      <Section kicker="1" title="Ecosystem Risk Audit">
        <div id="risk-audit" />

        <GlassCard>
          <div className="h3">Executive snapshot</div>
          <p className="p" style={{ marginTop: 8 }}>
            The foundation is strong. The highest risk is not architecture — it’s
            enforcement automation and security hardening (especially anything that
            touches roles, admin paths, or payments).
          </p>
        </GlassCard>

        <div className="grid" style={{ marginTop: 14, gap: 14 }}>
          <GlassCard>
            <div className="h3">A) Governance enforcement (Canon / Packs)</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>Risk:</b> Canon drift + pack tampering when more than one person
                touches the system.
              </li>
              <li>
                <b>Impact:</b> Medium–High (becomes High the moment you license/sell
                packs).
              </li>
              <li>
                <b>Fix:</b> Hash + manifest validation; build stamps; pre-deploy checks.
              </li>
            </ul>
          </GlassCard>

          <GlassCard>
            <div className="h3">B) Firestore + Admin surface</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>Risk:</b> Role escalation, unauthorized writes, data poisoning.
              </li>
              <li>
                <b>Impact:</b> High.
              </li>
              <li>
                <b>Fix:</b> Custom claims gating, path isolation, server-only writes for
                aggregation and privileged docs.
              </li>
            </ul>
          </GlassCard>

          <GlassCard>
            <div className="h3">C) Payments / Webhooks</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>Risk:</b> Webhook replay, forged sponsor status, checkout tampering.
              </li>
              <li>
                <b>Impact:</b> High.
              </li>
              <li>
                <b>Fix:</b> Signature verification, idempotency keys, server-side status
                authority only.
              </li>
            </ul>
          </GlassCard>

          <GlassCard>
            <div className="h3">D) Operational risk</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>Risk:</b> Over-architecture before traction; founder bottleneck.
              </li>
              <li>
                <b>Impact:</b> Medium.
              </li>
              <li>
                <b>Fix:</b> Freeze versions, launch revenue, harden after real usage
                feedback.
              </li>
            </ul>
          </GlassCard>
        </div>
      </Section>

      {/* 2) MONETIZATION */}
      <Section kicker="2" title="Monetization Strategy">
        <div id="monetization" />

        <div className="grid" style={{ gap: 14 }}>
          <GlassCard>
            <div className="h3">AICOMMS (Core leverage)</div>
            <p className="p" style={{ marginTop: 8 }}>
              AICOMMS is the scalable asset: it’s governance IP. Apps are proofs. Packs
              and automation are the product.
            </p>
            <div style={{ marginTop: 12 }}>
              <div className="h4" style={{ marginBottom: 8 }}>
                Primary revenue channels
              </div>
              <ul className="ul">
                <li>
                  <b>Guardrail Pack Licensing:</b> Basic $199 · Pro $499 · Enterprise
                  $1,499+
                </li>
                <li>
                  <b>Governance Dashboard SaaS:</b> $29/mo starter · $99/mo pro · $299/mo
                  enterprise
                </li>
                <li>
                  <b>Implementation Services:</b> $150/hr or packaged $5k–$15k
                </li>
              </ul>
            </div>
          </GlassCard>

          <GlassCard>
            <div className="h3">Pollsit (Revenue + proof engine)</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>Phase 1:</b> Sponsored polls ($50–$500/run)
              </li>
              <li>
                <b>Phase 2:</b> Featured placement / boosted distribution
              </li>
              <li>
                <b>Phase 3:</b> Brand insights dashboard subscription
              </li>
              <li>
                <b>Phase 4:</b> White-label polling engine
              </li>
            </ul>
          </GlassCard>

          <GlassCard>
            <div className="h3">Supporting platforms (QR Gear / Kingdom Connects)</div>
            <ul className="ul" style={{ marginTop: 10 }}>
              <li>
                <b>QR Gear:</b> product margin + future QR licensing; operationally
                heavier, great as proof-of-system.
              </li>
              <li>
                <b>Kingdom Connects:</b> Pro listings + sponsorships + commerce share;
                strong niche trust.
              </li>
            </ul>
          </GlassCard>
        </div>
      </Section>

      {/* 3) POSITIONING */}
      <Section kicker="3" title="Portfolio Positioning">
        <div id="positioning" />

        <div className="grid" style={{ gap: 14 }}>
          <GlassCard>
            <div className="h3">The clean narrative</div>
            <p className="p" style={{ marginTop: 8 }}>
              Don’t sell “a group of apps.” Sell a single infrastructure system with
              multiple proof deployments.
            </p>
            <div style={{ marginTop: 12 }}>
              <div className="h4" style={{ marginBottom: 8 }}>
                Position it like this
              </div>
              <ul className="ul">
                <li>
                  <b>AICOMMS</b> — the guardrail operating system (governance + scoped
                  build enforcement)
                </li>
                <li>
                  <b>Pollsit</b> — proof deployment: sponsored insights engine
                </li>
                <li>
                  <b>QR Gear</b> — proof deployment: dynamic QR commerce + timed content
                </li>
                <li>
                  <b>Kingdom Connects</b> — proof deployment: role-governed community
                  commerce
                </li>
              </ul>
            </div>
          </GlassCard>

          <GlassCard>
            <div className="h3">Differentiator</div>
            <p className="p" style={{ marginTop: 8 }}>
              Most founders build features. This portfolio builds <b>governance IP</b>{" "}
              that reliably produces products. That’s defensible. That’s licensable.
            </p>
          </GlassCard>

          <GlassCard>
            <div className="h3">Next conversion step</div>
            <p className="p" style={{ marginTop: 8 }}>
              Use this page as the “why” behind the funnel. Then push visitors to{" "}
              <b>Pricing</b> → <b>Checkout</b> → <b>Intake</b>.
            </p>
            <div
              style={{
                display: "flex",
                gap: 10,
                flexWrap: "wrap",
                marginTop: 12
              }}
            >
              <CTAButton to="/pricing" label="Go to Pricing" />
              <CTAButton to="/intake" label="Start Intake" />
              <CTAButton to="/audit" label="Request Audit" variant="secondary" />
            </div>
          </GlassCard>
        </div>
      </Section>
    </>
  );
}