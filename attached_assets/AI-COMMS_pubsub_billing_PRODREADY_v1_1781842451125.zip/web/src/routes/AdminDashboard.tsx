import { useEffect, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";

export default function AdminDashboard() {
  const [metrics, setMetrics] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const fn = httpsCallable(functions, "adminMetrics");
        const res: any = await fn({});
        setMetrics(res.data);
      } catch (e: any) {
        setError(e?.message || "Failed to load metrics.");
      }
    }
    load();
  }, []);

  if (error) return <div style={{ padding: 20 }}>Error: {error}</div>;
  if (!metrics) return <div style={{ padding: 20 }}>Loading metrics…</div>;

  return (
    <div style={{ padding: 40 }}>
      <h1>Admin Command Center</h1>

      <div style={{ marginTop: 30 }}>
        <h3>Total Users</h3>
        <p>{metrics.totalUsers}</p>

        <h3>Active Subscriptions</h3>
        <p>{metrics.activeSubscriptions}</p>

        <h3>Grace Period</h3>
        <p>{metrics.graceSubscriptions}</p>

        <h3>Canceled</h3>
        <p>{metrics.canceledSubscriptions}</p>

        <h3>Total Protection Events Logged</h3>
        <p>{metrics.totalProtectionEvents}</p>
      </div>
    </div>
  );
}
