import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getProjectDetail } from "../lib/portalApi";

export default function ProjectDetail() {
  const { projectId } = useParams();
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    (async () => {
      if (!projectId) return;
      setLoading(true);
      setErr(null);
      const res = await getProjectDetail(projectId);
      if (!res.ok) {
        setErr(res.json?.error || `Request failed (${res.status})`);
        setLoading(false);
        return;
      }
      setData(res.json);
      setLoading(false);
    })();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="h1">Project Detail</h1>
          <p className="p">Project ID: <span className="mono">{projectId}</span></p>
        </div>
        <Link to="/portal/projects" className="btn btn-secondary">Back</Link>
      </div>

      {loading && <p className="p">Loading…</p>}
      {err && <div className="card"><p className="p text-red-300">{err}</p></div>}

      {!loading && !err && data && (
        <div className="grid md:grid-cols-2 gap-4">
          <div className="card space-y-2">
            <h2 className="h2">Project</h2>
            <pre className="pre">{JSON.stringify(data.project, null, 2)}</pre>
          </div>
          <div className="card space-y-2">
            <h2 className="h2">Job</h2>
            <pre className="pre">{JSON.stringify(data.job, null, 2)}</pre>
          </div>
          <div className="card space-y-2">
            <h2 className="h2">Packet</h2>
            <pre className="pre">{JSON.stringify(data.packet, null, 2)}</pre>
          </div>
          <div className="card space-y-2">
            <h2 className="h2">Deliverable</h2>
            <pre className="pre">{JSON.stringify(data.deliverable, null, 2)}</pre>
            {data.deliverable?.deliverablesUrl && (
              <a className="btn btn-primary" href={data.deliverable.deliverablesUrl} target="_blank" rel="noreferrer">Download Deliverables</a>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
