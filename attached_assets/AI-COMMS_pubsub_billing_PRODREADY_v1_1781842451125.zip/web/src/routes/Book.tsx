import { useState } from "react";

export default function Book() {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText("AICOMMS Governance Review Request");
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {}
  };

  return (
    <div className="min-h-screen bg-black text-white px-6 py-14">
      <div className="max-w-3xl mx-auto space-y-10">
        <header className="space-y-4">
          <div className="inline-flex items-center gap-2 text-xs tracking-widest uppercase text-gray-400">
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">AI-COMMS</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">Booking</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">Next Steps</span>
          </div>

          <h1 className="text-4xl font-bold tracking-tight">
            Book a Governance Review
          </h1>

          <p className="text-gray-300">
            You’ve submitted your Risk Scan. Next: schedule a short review and we’ll recommend the fastest path based on
            your score and workflow.
          </p>
        </header>

        <section className="rounded-2xl border border-gray-800 bg-gray-950 p-6 space-y-5">
          <h2 className="text-2xl font-semibold">What to send</h2>
          <ul className="text-gray-300 space-y-2 list-disc pl-5">
            <li>Your name + company</li>
            <li>Where AI touches your workflow</li>
            <li>Whether outputs go client-facing</li>
            <li>Any compliance constraints</li>
          </ul>

          <div className="pt-2">
            <button
              onClick={copy}
              className="inline-flex items-center justify-center bg-white text-black px-6 py-3 rounded-lg font-semibold hover:bg-gray-200 transition"
            >
              {copied ? "Copied" : "Copy Request Header"}
            </button>
            <div className="text-xs text-gray-500 pt-2">
              Copies: <span className="text-gray-300">AICOMMS Governance Review Request</span>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-gray-800 bg-black p-6 space-y-3">
          <h2 className="text-xl font-semibold">Reminder</h2>
          <p className="text-gray-300">
            AI-COMMS is governance infrastructure. We don’t “tune prompts.” We bind systems.
          </p>
        </section>
      </div>
    </div>
  );
}