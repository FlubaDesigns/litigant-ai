
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { collection, getDocs, orderBy, query, where } from "firebase/firestore";
import { db } from "../firebase";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";
import CTAButton from "../components/CTAButton";

type Mode = { id: string; label: string; description?: string; is_active: boolean; display_order: number; };
type Tier = any;
type Addon = any;

function fmtCents(cents: number) {
  const n = Number(cents || 0) / 100;
  return n.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

export default function Pricing() {
  const nav = useNavigate();
  const [modes, setModes] = useState<Mode[]>([]);
  const [tiers, setTiers] = useState<Tier[]>([]);
  const [addons, setAddons] = useState<Addon[]>([]);
  const [modeId, setModeId] = useState<"DFY"|"DYS">("DFY");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const qm = query(collection(db, "pricing_modes"), where("is_active", "==", true), orderBy("display_order", "asc"));
      const qt = query(collection(db, "pricing_tiers"), where("is_active", "==", true), orderBy("display_order", "asc"));
      const qa = query(collection(db, "pricing_addons"), where("is_active", "==", true), orderBy("name", "asc"));
      const [sm, st, sa] = await Promise.all([getDocs(qm), getDocs(qt), getDocs(qa)]);
      setModes(sm.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
      setTiers(st.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
      setAddons(sa.docs.map(d => ({ id: d.id, ...(d.data() as any) })));
      setLoading(false);
    })().catch(() => setLoading(false));
  }, []);

  const modeTiers = useMemo(() => tiers.filter(t => String(t.mode_id) === String(modeId)), [tiers, modeId]);

  function goCheckout(tierId: string) {
    nav(`/checkout?tierId=${encodeURIComponent(tierId)}`);
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <Section title="Pricing">
        <p style={{ opacity: 0.85 }}>
          Choose DFY (we install) or DYS (you install). Pricing is controlled from the Admin dashboard.
        </p>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }}>
          <button style={tab(modeId === "DFY")} onClick={() => setModeId("DFY")}>DFY</button>
          <button style={tab(modeId === "DYS")} onClick={() => setModeId("DYS")}>DYS</button>
        </div>
      </Section>

      {loading ? (
        <GlassCard>
          <div>Loading pricing…</div>
        </GlassCard>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 14 }}>
          {modeTiers.map((t) => (
            <GlassCard key={t.id}>
              <h3 style={{ marginTop: 0 }}>{t.name || t.id}</h3>
              <div style={{ opacity: 0.85 }}>
                <div><b>{fmtCents(t.monthly_fee_cents || 0)}</b> / month</div>
                {Number(t.onboarding_fee_cents || 0) > 0 ? (
                  <div>Onboarding: {fmtCents(t.onboarding_fee_cents)}</div>
                ) : (
                  <div>Onboarding: Included</div>
                )}
                <div style={{ marginTop: 8, fontSize: 12, opacity: 0.8 }}>
                  Defaults: A{t.defaults_autonomy_level} • {t.defaults_logging_depth} • {t.defaults_patch_mode}
                </div>
              </div>
              <div style={{ marginTop: 12 }}>
                <CTAButton onClick={() => goCheckout(t.id)}>Continue</CTAButton>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

function tab(active: boolean): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: active ? "1px solid rgba(255,255,255,0.35)" : "1px solid rgba(255,255,255,0.18)",
    background: active ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.18)",
    color: "white",
    cursor: "pointer",
  };
}
