import { useEffect, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { functions, auth } from "../firebase";
import GlassCard from "../components/GlassCard";

type Check = {
  ok: boolean;
  detail?: string;
  missing?: string[];
  missingStripeIds?: string[];
  lastSeenAt?: string;
};

export default function AdminLaunch() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<{ ok: boolean; checks: Record<string, Check> } | null>(null);

  useEffect(() => {
    async function run() {
      try {
        const u = auth.currentUser;
        if (!u) {
          setError("Login required. Go to /login.");
          setLoading(false);
          return;
        }
        const fn = httpsCallable(functions, "getLaunchStatus");
        const res: any = await fn({});
        setData(res.data);
      } catch (e: any) {
        setError(e?.message || "Failed to load launch status.");
      } finally {
        setLoading(false);
      }
    }
    run();
  }, []);

  const badge = (ok: boolean) => (
    <span style={{
      display: "inline-block",
      padding: "2px 8px",
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 700,
      background: ok ? "rgba(0,255,160,0.18)" : "rgba(255,80,80,0.18)",
      color: ok ? "#7CFFCF" : "#FF9C9C",
      border: ok ? "1px solid rgba(0,255,160,0.35)" : "1px solid rgba(255,80,80,0.35)"
    }}>
      {ok ? "READY" : "NEEDS WORK"}
    </span>
  );

  return (
    <div style={{ paddingTop: 28, maxWidth: 960, margin: "0 auto" }}>
      <h1 className="h1">Launch Wizard</h1>
      <p style={{ opacity: 0.85, maxWidth: 760 }}>
        This page checks the wiring that must be correct before production: admin bootstrap, pricing config, Stripe IDs, secrets presence, and webhook health.
      </p>

      {loading ? <div style={{ opacity: 0.8 }}>Checking…</div> : null}
      {error ? <div style={{ color: "#ffb3b3", marginTop: 12 }}>{error}</div> : null}

      {data ? (
        <div style={{ marginTop: 16, display: "grid", gap: 14 }}>
          <GlassCard>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 14, opacity: 0.8 }}>Overall</div>
                <div style={{ fontSize: 22, fontWeight: 800 }}>Production Readiness</div>
              </div>
              {badge(data.ok)}
            </div>
          </GlassCard>

          {Object.entries(data.checks || {}).map(([key, c]) => (
            <GlassCard key={key}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 800 }}>{key}</div>
                  <div style={{ opacity: 0.85, marginTop: 4 }}>{c.detail || ""}</div>

                  {c.lastSeenAt ? (
                    <div style={{ marginTop: 8, opacity: 0.85 }}>
                      Last seen: <code>{c.lastSeenAt}</code>
                    </div>
                  ) : null}

                  {c.missingStripeIds?.length ? (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontWeight: 700, marginBottom: 6 }}>Missing Stripe IDs:</div>
                      <ul style={{ margin: 0, paddingLeft: 18 }}>
                        {c.missingStripeIds.map((m) => (
                          <li key={m}><code>{m}</code></li>
                        ))}
                      </ul>
                    </div>
                  ) : null}

                  {c.missing?.length ? (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontWeight: 700, marginBottom: 6 }}>Missing / Notes:</div>
                      <ul style={{ margin: 0, paddingLeft: 18 }}>
                        {c.missing.map((m) => (
                          <li key={m}><code>{m}</code></li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                </div>
                {badge(!!c.ok)}
              </div>
            </GlassCard>
          ))}
        </div>
      ) : null}

      <div style={{ marginTop: 18, opacity: 0.85 }}>
        Tip: If this page fails with App Check errors during testing, confirm App Check is enabled and configured in the web app and Firebase Console.
      </div>
    </div>
  );
}
