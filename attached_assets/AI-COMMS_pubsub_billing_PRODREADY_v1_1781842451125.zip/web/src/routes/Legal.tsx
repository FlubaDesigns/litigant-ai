import GlassCard from "../components/GlassCard";
import Section from "../components/Section";

export default function Legal() {
  return (
    <div>
      <h1 className="h1">Legal</h1>
      <p className="p" style={{ maxWidth: 860 }}>
        Plain language. No fine-print games.
      </p>

      <div className="hr" />

      <Section title="Privacy" kicker="What we store">
        <GlassCard>
          <p className="p">
            Intake submissions are stored in Firestore as lead records. The site does not expose lead data publicly.
            We store only what you submit for the purpose of responding with a proposal.
          </p>
        </GlassCard>
      </Section>

      <Section title="Terms" kicker="Common sense boundaries">
        <GlassCard>
          <p className="p">
            AI-COMMS provides governance documents, workflows, and implementation guidance. Outcomes depend on your tools,
            data, and use. You remain responsible for how AI outputs are used in your business.
          </p>
        </GlassCard>
      </Section>

      <Section title="Proprietary notice" kicker="Respect the work">
        <GlassCard>
          <p className="p">
            AI-COMMS methodology, packs, and templates are proprietary. No redistribution or resale without a license.
          </p>
        </GlassCard>
      </Section>
    </div>
  );
}