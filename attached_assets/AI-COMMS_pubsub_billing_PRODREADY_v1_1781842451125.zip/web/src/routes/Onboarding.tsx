
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Onboarding() {
  const nav = useNavigate();
  const [provider, setProvider] = useState("OpenAI");
  const [sensitivity, setSensitivity] = useState("Balanced");

  const finish = () => {
    localStorage.setItem("provider", provider);
    localStorage.setItem("sensitivity", sensitivity);
    nav("/Dashboard");
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center px-6 text-center">
      <h1 className="text-4xl font-bold mb-8">Finish Wrapping Your AI</h1>

      <div className="mb-6">
        <label className="block mb-2">Primary AI Provider</label>
        <select
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
          className="bg-gray-800 px-4 py-2 rounded"
        >
          <option>OpenAI</option>
          <option>Anthropic</option>
          <option>Other</option>
        </select>
      </div>

      <div className="mb-8">
        <label className="block mb-2">Protection Sensitivity</label>
        <select
          value={sensitivity}
          onChange={(e) => setSensitivity(e.target.value)}
          className="bg-gray-800 px-4 py-2 rounded"
        >
          <option>Calm</option>
          <option>Balanced</option>
          <option>Strict</option>
        </select>
      </div>

      <button
        onClick={finish}
        className="bg-blue-600 px-8 py-4 rounded-xl hover:bg-blue-500 transition"
      >
        Activate Protection
      </button>
    </div>
  );
}
