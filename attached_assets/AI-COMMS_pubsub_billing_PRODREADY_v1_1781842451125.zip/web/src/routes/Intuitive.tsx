import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";
import Section from "../components/Section";

export default function Intuitive() {
  return (
    <div>
      <div className="badge">Product • Intuitive</div>
      <h1 className="h1" style={{ marginTop: 10 }}>Intuitive. Powered by AI-COMMS.</h1>
      <p className="p" style={{ maxWidth: 860 }}>
        Intuitive is the guardrail platform: it defines scope, roles, tool access, evidence rules, and how safe evolution happens
        without breaking your canon or your codebase.
      </p>

      <div className="hr" />

      <Section title="Core protocols" kicker="What it enforces">
        <div className="grid grid-2">
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Execution Honesty</div>
            <p className="p">Every claim declares REAL vs SIMULATED vs ASSUMED. No fake “verified” output.</p>
          </GlassCard>
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Safe Evolution</div>
            <p className="p">Amendments and supersession—append-only history with controlled upgrades.</p>
          </GlassCard>
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Tool Boundaries</div>
            <p className="p">Tool proxy containment: who can call what tool, when, and with what evidence.</p>
          </GlassCard>
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Consensus Before Touching Code</div>
            <p className="p">Agents can argue; implementation happens only after moderator-confirmed consensus.</p>
          </GlassCard>
        </div>
      </Section>

      <Section title="Ready when you are" kicker="Next step">
        <GlassCard>
          <p className="p">
            If your agents drift, rename, overwrite, or fabricate “success,” Intuitive is built to stop that behavior.
          </p>
          <div style={{ marginTop: 12 }}>
            <CTAButton to="/intake" label="Build My Guardrails" variant="primary" />
          </div>
        </GlassCard>
      </Section>
    </div>
  );
}