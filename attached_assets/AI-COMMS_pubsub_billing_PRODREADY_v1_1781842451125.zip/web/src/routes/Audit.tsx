import React from "react";

export default function Audit() {
  return (
    <div className="min-h-screen bg-black text-white px-6 py-16">
      <div className="max-w-4xl mx-auto space-y-12">

        <div className="space-y-6 text-center">
          <h1 className="text-4xl font-bold">AI Drift & Failure Audit</h1>
          <p className="text-lg text-gray-300">
            Identify hidden instability inside your AI systems before it costs you clients.
          </p>
        </div>

        <div className="space-y-8 text-gray-400">

          <p>
            Most businesses already use AI. Few control it.
          </p>

          <p>
            We analyze your workflows, prompts, escalation systems, and
            automation logic to identify:
          </p>

          <ul className="space-y-2">
            <li>• Hallucination risk</li>
            <li>• Tone inconsistency</li>
            <li>• Multi-agent conflict</li>
            <li>• Escalation failure</li>
            <li>• Data misrouting</li>
          </ul>

          <p>
            You receive a structured governance report plus a stabilization blueprint.
          </p>

          <div className="border border-gray-700 p-6 rounded-xl">
            <h2 className="text-xl font-semibold mb-4">Audit Deliverables</h2>
            <ul className="space-y-2">
              <li>• Risk map</li>
              <li>• Failure analysis</li>
              <li>• Guardrail blueprint</li>
              <li>• Implementation roadmap</li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  );
}