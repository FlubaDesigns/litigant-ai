import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";

type RiskLevel = "LOW" | "MODERATE" | "HIGH" | "CRITICAL";

type Inputs = {
  writesProduction: boolean;
  refactors: boolean;
  migrations: boolean;
  teamSize: "solo" | "small" | "medium" | "large";
  regulated: boolean;
  pastIncident: boolean;
};

function calcScore(i: Inputs): number {
  let score = 0;
  if (i.writesProduction) score += 15;
  if (i.refactors) score += 20;
  if (i.migrations) score += 25;
  if (i.teamSize === "small") score += 6;
  if (i.teamSize === "medium") score += 10;
  if (i.teamSize === "large") score += 14;
  if (i.regulated) score += 20;
  if (i.pastIncident) score += 15;
  return Math.min(score, 100);
}

function levelFor(score: number): RiskLevel {
  if (score >= 80) return "CRITICAL";
  if (score >= 55) return "HIGH";
  if (score >= 25) return "MODERATE";
  return "LOW";
}

function tierFor(level: RiskLevel): "explorer" | "audit" | "pro" | "enterprise" {
  if (level === "LOW") return "explorer";
  if (level === "MODERATE") return "audit";
  if (level === "HIGH") return "pro";
  return "enterprise";
}

export default function DriftScan() {
  const nav = useNavigate();

  const [inputs, setInputs] = useState<Inputs>({
    writesProduction: false,
    refactors: false,
    migrations: false,
    teamSize: "solo",
    regulated: false,
    pastIncident: false,
  });

  const score = useMemo(() => calcScore(inputs), [inputs]);
  const level = useMemo(() => levelFor(score), [score]);
  const recTier = useMemo(() => tierFor(level), [level]);

  const barPct = score;

  const helper = useMemo(() => {
    if (level === "LOW") return "Low structural drift risk today. As you scale, governance prevents silent breakage.";
    if (level === "MODERATE") return "Moderate drift exposure. You likely need basic approval + artifact discipline.";
    if (level === "HIGH") return "High drift exposure. Team-grade controls and auditability are recommended.";
    return "Critical exposure. You need enterprise governance posture before AI touches production.";
  }, [level]);

  function toggle<K extends keyof Inputs>(k: K) {
    setInputs((p) => ({ ...p, [k]: !p[k] }));
  }

  return (
    <Section title="Drift Scan">
      <GlassCard>
        <div className="space-y-4">
          <h1 className="h1">Real‑Time Drift Scan</h1>
          <p className="p">
            This is interactive and instant. No uploads required. When you’re ready, you can escalate to paste, file upload, or GitHub scan.
          </p>

          <div className="rounded-xl border border-white/10 bg-white/5 p-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-widest text-gray-400">Risk Score</div>
                <div className="text-3xl font-bold">{score}%</div>
                <div className="text-sm text-gray-300">
                  Level: <span className="font-semibold">{level}</span> • Recommended:{" "}
                  <span className="font-semibold">{recTier.toUpperCase()}</span>
                </div>
              </div>
              <div className="w-1/2">
                <div className="h-3 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-indigo-500" style={{ width: `${barPct}%` }} />
                </div>
                <div className="mt-2 text-xs text-gray-400">{helper}</div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-3">
            <label className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <input type="checkbox" checked={inputs.writesProduction} onChange={() => toggle("writesProduction")} />
              <span>AI writes or edits production code</span>
            </label>

            <label className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <input type="checkbox" checked={inputs.refactors} onChange={() => toggle("refactors")} />
              <span>AI refactors existing code</span>
            </label>

            <label className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <input type="checkbox" checked={inputs.migrations} onChange={() => toggle("migrations")} />
              <span>AI touches schema / migrations / rules</span>
            </label>

            <label className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <input type="checkbox" checked={inputs.regulated} onChange={() => toggle("regulated")} />
              <span>Regulated environment (HIPAA/FINRA/etc.)</span>
            </label>

            <label className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <input type="checkbox" checked={inputs.pastIncident} onChange={() => toggle("pastIncident")} />
              <span>AI has caused incidents before</span>
            </label>

            <div className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">
              <div className="text-xs uppercase tracking-widest text-gray-400 mb-1">Team size</div>
              <select
                value={inputs.teamSize}
                onChange={(e) => setInputs((p) => ({ ...p, teamSize: e.target.value as any }))}
                className="w-full rounded-lg bg-black/40 border border-white/10 px-3 py-2"
              >
                <option value="solo">Solo</option>
                <option value="small">2–5</option>
                <option value="medium">6–20</option>
                <option value="large">20+</option>
              </select>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-3 pt-2">
            <button
              className="rounded-xl px-4 py-3 font-semibold bg-white/10 hover:bg-white/15 border border-white/10"
              onClick={() => nav(`/checkout?tier=${recTier}`)}
            >
              Run Controlled Simulation (Checkout)
            </button>

            <Link to="/risk-scan" className="rounded-xl px-4 py-3 font-semibold bg-white/10 hover:bg-white/15 border border-white/10 text-center">
              Legacy Risk Scan (v23)
            </Link>

            <Link to="/pricing" className="rounded-xl px-4 py-3 font-semibold bg-indigo-600 hover:bg-indigo-500 text-center">
              View Plans
            </Link>
          </div>

          <div className="text-xs text-gray-500 pt-2">
            Next escalation (built in Socket layer): paste sample • file upload • GitHub OAuth scan.
            This page is the real-time front-door that keeps users in the funnel.
          </div>
        </div>
      </GlassCard>
    </Section>
  );
}
