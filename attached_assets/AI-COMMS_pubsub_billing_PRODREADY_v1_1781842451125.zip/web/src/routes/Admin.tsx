import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { auth } from "../firebase";
import { TierGate, useTier } from "../lib/tier";
import ConfigVaultPanel from "../components/ConfigVaultPanel";
import ProviderStatusPanel from "../components/ProviderStatusPanel";
import AIRoutingPanel from "../components/AIRoutingPanel";
import MetricsDashboardPanel from "../components/MetricsDashboardPanel";
import ObservabilityPanel from "../components/ObservabilityPanel";
import SelfEvolvePanel from "../components/SelfEvolvePanel";
import SeatLeaderboardPanel from "../components/SeatLeaderboardPanel";
import ReplayComparePanel from "../components/ReplayComparePanel";
import CanonGovernancePanel from "../components/CanonGovernancePanel";
import ProviderSwitchPanel from "../components/ProviderSwitchPanel";
import AnomalyThresholdsPanel from "../components/AnomalyThresholdsPanel";
import SeatCanaryConfigPanel from "../components/SeatCanaryConfigPanel";
import ApprovalQueuePanel from "../components/ApprovalQueuePanel";
import SeatLockPanel from "../components/SeatLockPanel";
import OwnerOverrideControlsPanel from "../components/OwnerOverrideControlsPanel";
import ArtifactVaultPanel from "../components/ArtifactVaultPanel";
import GovernanceHealthPanel from "../components/GovernanceHealthPanel";
import SystemStatePanel from "../components/SystemStatePanel";
import ActiveTaskPanel from "../components/ActiveTaskPanel";
import LeadsPanel from "../components/LeadsPanel";
import RiskScanDetailPanel from "../components/RiskScanDetailPanel";
import ReportsPanel from "../components/ReportsPanel";
import SecurityStatusPanel from "../components/SecurityStatusPanel";
import PricingControlPanelV2 from "../components/PricingControlPanelV2";
import ApprovalsPanelV2 from "../components/ApprovalsPanelV2";


export default function Admin() {
  const [uid, setUid] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"command"|"operations"|"governance"|"compliance"|"leads">("command");
  const [selectedLead, setSelectedLead] = useState<string | null>(null);
  const { tier, loading: tierLoading } = useTier();

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((u) => {
      setUid(u?.uid || null);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  if (loading || tierLoading) {
    return (
      <div style={container()}>
        <div>Loading…</div>
      </div>
    );
  }

  if (!uid) {
    return (
      <div style={container()}>
        <div style={card()}>
          <h2>Admin</h2>
          <p>You must be logged in.</p>
        </div>
      </div>
    );
  }
return (
    <div style={container()}>
      <div style={card()}>
        <h2 style={{ marginBottom: 4 }}>AI-COMMS Control Plane</h2>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ opacity: 0.7, fontSize: 12 }}>
          UID: <code>{uid}</code>
        </div>
        <div>
          <Link to="/admin/launch" style={{ fontSize: 12, opacity: 0.9, textDecoration: "underline" }}>Launch Wizard</Link>
        </div>
      </div>
        <div style={{ marginTop: 12, display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button style={tabBtn(tab === "command")} onClick={() => setTab("command")}>Command</button>
          <TierGate min="pro" tier={tier}>
            <button style={tabBtn(tab === "operations")} onClick={() => setTab("operations")}>Operations</button>
          </TierGate>
          <TierGate min="enterprise" tier={tier}>
            <button style={tabBtn(tab === "governance")} onClick={() => setTab("governance")}>Governance</button>
          </TierGate>
          <TierGate min="enterprise" tier={tier}>
            <button style={tabBtn(tab === "compliance")} onClick={() => setTab("compliance")}>Compliance</button>
          </TierGate>
          <button style={tabBtn(tab === "leads")} onClick={() => setTab("leads")}>Leads</button>
        </div>
      </div>

      {tab === "command" ? (
        <>
          <SystemStatePanel />
          <GovernanceHealthPanel />
          <ActiveTaskPanel />
          <ApprovalQueuePanel />
          <ApprovalsPanelV2 />
          <PricingControlPanelV2 />
          <OwnerOverrideControlsPanel />
        </>
      ) : null}

      {tab === "operations" ? (
        <>
          <TierGate min="pro" tier={tier}>
            <>
              <ObservabilityPanel />
              <MetricsDashboardPanel />
              <ProviderStatusPanel />
              <SeatLeaderboardPanel />
            </>
          </TierGate>
        </>
      ) : null}

      {tab === "leads" ? (
        <>
          <LeadsPanel onSelectLead={(id) => setSelectedLead(id)} />
          <RiskScanDetailPanel leadId={selectedLead} />
        </>
      ) : null}

      {tab === "governance" ? (
        <TierGate min="enterprise" tier={tier} fallback={<div style={{ opacity: 0.75 }}>Upgrade to Enterprise to access Governance controls.</div>}>
          <>
            <ArtifactVaultPanel />
            <CanonGovernancePanel />
            <ProviderSwitchPanel />
            <AIRoutingPanel />
            <SeatLockPanel />
            <SeatCanaryConfigPanel />
            <AnomalyThresholdsPanel />
            <ReplayComparePanel />
          </>
        </TierGate>
      ) : null}

      {tab === "compliance" ? (
        <TierGate min="enterprise" tier={tier} fallback={<div style={{ opacity: 0.75 }}>Upgrade to Enterprise to access Compliance controls.</div>}>
          <>
            <SecurityStatusPanel />
            <ReportsPanel />
            <ConfigVaultPanel />
          </>
        </TierGate>
      ) : null}
    </div>
  );



function container(): React.CSSProperties {
  return {
    padding: 24,
    display: "flex",
    flexDirection: "column",
    gap: 16,
  };
}

function tabBtn(active: boolean): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: active ? "1px solid rgba(255,255,255,0.35)" : "1px solid rgba(255,255,255,0.18)",
    background: active ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.18)",
    color: "white",
    cursor: "pointer",
  };
}

function card(): React.CSSProperties {
  return {
    padding: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.15)",
    background: "rgba(255,255,255,0.05)",
  };
}