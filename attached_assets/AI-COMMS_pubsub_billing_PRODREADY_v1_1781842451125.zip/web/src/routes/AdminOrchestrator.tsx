import { useState } from "react";
import Section from "../components/Section";
import GlassCard from "../components/GlassCard";
import { socketSubmit, socketGet, socketApply, socketRollback } from "../lib/socketApi";

export default function AdminOrchestrator() {
  const [repoUrl, setRepoUrl] = useState("");
  const [environment, setEnvironment] = useState("dev"); // dev | prod
  const [dryRun, setDryRun] = useState(true);
  const [autoApply, setAutoApply] = useState(false);
  const [autoDeploy, setAutoDeploy] = useState(false);
  const [requireOwnerApproval, setRequireOwnerApproval] = useState(true);
  const [autoRollback, setAutoRollback] = useState(true);

  const [jobId, setJobId] = useState("");
  const [out, setOut] = useState<any>(null);
  const [msg, setMsg] = useState("");

  async function submit() {
    setMsg("Submitting job…");
    const payload = {
      target: { type: "git", repoUrl },
      envelope: {
        environment,
        dryRun,
        autoApply,
        autoDeploy,
        requireOwnerApproval,
        autoRollback,
        applyTarget: "git_branch",
        deployTarget: "firebase",
        rollbackTarget: "git_revert"
      }
    };
    const r = await socketSubmit(payload);
    setOut(r.json);
    if (r.ok) {
      const id = r.json?.jobId || r.json?.job_id || r.json?.id || "";
      if (id) setJobId(id);
      setMsg("Submitted.");
    } else setMsg(`Error: ${JSON.stringify(r.json)}`);
  }

  async function refresh() {
    if (!jobId) return;
    setMsg("Loading…");
    const r = await socketGet(jobId);
    setOut(r.json);
    setMsg(r.ok ? "Loaded." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function apply() {
    if (!jobId) return;
    setMsg("Applying (requires Owner approval in prod)…");
    const r = await socketApply(jobId, {});
    setOut(r.json);
    setMsg(r.ok ? "Apply triggered." : `Error: ${JSON.stringify(r.json)}`);
  }

  async function rollback() {
    if (!jobId) return;
    setMsg("Rolling back…");
    const r = await socketRollback(jobId, {});
    setOut(r.json);
    setMsg(r.ok ? "Rollback triggered." : `Error: ${JSON.stringify(r.json)}`);
  }

  return (
    <Section title="Socket Console">
      <GlassCard>
        <div style={{ display: "grid", gap: 10 }}>
          <div style={{ opacity: 0.85 }}>
            AI-COMMS is the retail panel. Socket is the execution brain. This console submits and monitors Socket jobs.
          </div>

          <label>
            Repo URL (git):
            <input value={repoUrl} onChange={(e)=>setRepoUrl(e.target.value)} placeholder="https://github.com/org/repo.git" style={input()} />
          </label>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <label style={pill()}>
              Env:
              <select value={environment} onChange={(e)=>setEnvironment(e.target.value)} style={select()}>
                <option value="dev">dev</option>
                <option value="prod">prod</option>
              </select>
            </label>

            <label style={pill()}>
              <input type="checkbox" checked={dryRun} onChange={(e)=>setDryRun(e.target.checked)} /> dryRun
            </label>
            <label style={pill()}>
              <input type="checkbox" checked={autoApply} onChange={(e)=>setAutoApply(e.target.checked)} /> autoApply
            </label>
            <label style={pill()}>
              <input type="checkbox" checked={autoDeploy} onChange={(e)=>setAutoDeploy(e.target.checked)} /> autoDeploy
            </label>
            <label style={pill()}>
              <input type="checkbox" checked={requireOwnerApproval} onChange={(e)=>setRequireOwnerApproval(e.target.checked)} /> requireOwnerApproval
            </label>
            <label style={pill()}>
              <input type="checkbox" checked={autoRollback} onChange={(e)=>setAutoRollback(e.target.checked)} /> autoRollback
            </label>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button onClick={submit} style={btn()}>Submit Job</button>
            <button onClick={refresh} style={btnAlt()} disabled={!jobId}>Refresh</button>
            <button onClick={apply} style={btnAlt()} disabled={!jobId}>Apply</button>
            <button onClick={rollback} style={btnDanger()} disabled={!jobId}>Rollback</button>
          </div>

          <div style={{ fontSize: 12, opacity: 0.75 }}>{msg}</div>

          <div style={{ fontSize: 12, opacity: 0.85 }}>
            Job ID: <code>{jobId || "(none)"}</code>
          </div>

          <pre style={pre()}>{JSON.stringify(out, null, 2)}</pre>
        </div>
      </GlassCard>
    </Section>
  );
}

function input(): React.CSSProperties {
  return {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
    outline: "none",
    marginTop: 6,
  };
}
function select(): React.CSSProperties {
  return {
    marginLeft: 8,
    padding: "6px 10px",
    borderRadius: 10,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,0,0,0.25)",
    color: "white",
    outline: "none",
  };
}
function pre(): React.CSSProperties {
  return {
    marginTop: 10,
    background: "rgba(0,0,0,0.35)",
    padding: 12,
    borderRadius: 12,
    overflowX: "auto",
    maxHeight: 420,
  };
}
function pill(): React.CSSProperties {
  return {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    padding: "8px 10px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(0,0,0,0.20)",
    fontSize: 13,
  };
}
function btn(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,180,255,0.25)",
    color: "white",
    cursor: "pointer",
  };
}
function btnAlt(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,255,255,0.10)",
    color: "white",
    cursor: "pointer",
  };
}
function btnDanger(): React.CSSProperties {
  return {
    padding: "10px 12px",
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,0,80,0.18)",
    color: "white",
    cursor: "pointer",
  };
}
