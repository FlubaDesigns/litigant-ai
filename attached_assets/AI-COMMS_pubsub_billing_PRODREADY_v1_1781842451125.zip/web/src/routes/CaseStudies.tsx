import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";
import Section from "../components/Section";

export default function CaseStudies() {
  return (
    <div>
      <h1 className="h1">Case Studies</h1>
      <p className="p" style={{ maxWidth: 860 }}>
        Proof matters. These examples show the kind of discipline AI-COMMS enforces. No fluff.
      </p>

      <div className="hr" />

      <Section title="Examples" kicker="Real patterns">
        <div className="grid grid-3">
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Pollsit MVP Governance Build</div>
            <p className="p">
              Structured build pack + schema locks + security rules + Cloud Function integrity model. Single-zip enforcement.
            </p>
          </GlassCard>
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Email Workflow Stabilization</div>
            <p className="p">
              Guardrails for client intake, categorization, escalation rules, and “no hallucinated commitments” enforcement.
            </p>
          </GlassCard>
          <GlassCard>
            <div style={{ fontWeight: 900 }}>Multi-AI Consensus Gate</div>
            <p className="p">
              Agents debate solutions; moderator requires consensus before integrator touches code. Drift drops sharply.
            </p>
          </GlassCard>
        </div>

        <div style={{ marginTop: 14 }}>
          <CTAButton to="/intake" label="Request a Proposal" variant="primary" />
        </div>
      </Section>
    </div>
  );
}