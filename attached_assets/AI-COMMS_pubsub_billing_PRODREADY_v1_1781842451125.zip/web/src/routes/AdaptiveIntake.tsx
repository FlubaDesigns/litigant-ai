import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { httpsCallable } from "firebase/functions";
import { functions } from "../firebase";
import Section from "../components/Section";
import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";
import { classifyIntake, violatesIntakeGuardrails, type IntakeClassification, INTAKE_GUARDRAILS } from "../lib/intakeGuardrails";
import { buildGovernanceProfile, type GovernanceProfile, type OrgSize } from "../lib/governanceProfile";

type Stage = "A" | "B" | "C" | "DONE";

type Orientation = {
  entry: "audit" | "build";
  userRole: "owner" | "ops" | "tech";
  orgSize: OrgSize;
  problemDomain: string;
  aiMaturity: "new" | "some" | "advanced";
  riskAppetite: "low" | "medium" | "high";
  automationAppetite: "low" | "medium" | "high";
};

type Followup = { q: string; a: string };

function safeTrim(s: string) {
  return (s || "").trim();
}

export default function AdaptiveIntake() {
  const nav = useNavigate();
  const loc = useLocation();
  const params = useParams();

  const entry = useMemo<"audit" | "build">(() => {
    // /intake/:mode OR /intake?mode=
    const fromParam = (params as any)?.mode;
    const qs = new URLSearchParams(loc.search);
    const mode = String(fromParam || qs.get("mode") || "audit").toLowerCase();
    return mode === "build" ? "build" : "audit";
  }, [loc.search, params]);

  const [stage, setStage] = useState<Stage>("A");
  const [ori, setOri] = useState<Orientation>({
    entry,
    userRole: "owner",
    orgSize: "small",
    problemDomain: "",
    aiMaturity: "some",
    riskAppetite: "medium",
    automationAppetite: entry === "build" ? "high" : "medium",
  });

  const [classification, setClassification] = useState<IntakeClassification>("hybrid");
  const [govProfile, setGovProfile] = useState<GovernanceProfile | null>(null);
  const [followups, setFollowups] = useState<Followup[]>([]);
  const [err, setErr] = useState<string | null>(null);

  // Lead identity
  const [company, setCompany] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setOri((o) => ({ ...o, entry }));
  }, [entry]);

  const recommendedTier = useMemo(() => {
    // Website-layer mapping only (no canon/brain touched).
    if (classification === "governance_audit") return "audit";
    if (classification === "stack_build") return "pro";
    return "pro";
  }, [classification]);

  const followupBank = useMemo(() => {
    // Dynamic question selection — capped by guardrails.
    const common: string[] = [
      "Where would you like AI to help first? (sales, customer support, scheduling, invoices, marketing, internal ops)",
      "What would hurt the most if AI got it wrong? (money lost, angry customers, legal/compliance, reputation)",
    ];

    const gov: string[] = [
      "Do you have any rules today for AI use? (who can use it, what it can touch, approvals)",
      "Does AI touch sensitive info? (payments, health info, minors, legal matters)",
      "When AI takes an action, who must approve it?",
    ];

    const buildNonTech: string[] = [
      "What tools do you already use? (website platform, CRM, email, spreadsheets, accounting)",
      "Do you need approvals before AI sends messages, edits records, or moves money?",
      "Do you need a simple activity log you can show a partner/manager/client?",
    ];

    const buildTech: string[] = [
      "What stack are you running? (Firebase, Vite, Next, Stripe, etc.)",
      "Where should automation run? (server, cloud functions, CI/CD, backend)",
      "Do you need audit trails for automation actions?",
    ];

    const build: string[] = ori.userRole === "tech" ? buildTech : buildNonTech;

    const chosen =
      classification === "governance_audit" ? [...common, ...gov] :
      classification === "stack_build" ? [...common, ...build] :
      [...common, ...gov.slice(0, 2), ...build.slice(0, 2)];

    return chosen.slice(0, INTAKE_GUARDRAILS.maxFollowupQuestions);
  }, [classification, ori.userRole]);

  function setFollowupAnswer(idx: number, a: string) {
    setErr(null);
    const v = violatesIntakeGuardrails(a);
    if (v) {
      setErr(v);
      return;
    }
    setFollowups((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], a };
      return next;
    });
  }

  function nextFromA() {
    setErr(null);
    const v = violatesIntakeGuardrails(ori.problemDomain);
    if (v) {
      setErr(v);
      return;
    }
    const c = classifyIntake({
      problemDomain: ori.problemDomain,
      aiMaturity: ori.aiMaturity,
      riskAppetite: ori.riskAppetite,
      automationAppetite: ori.automationAppetite,
    });
    setClassification(c);

    // Formal governance profile object (website-layer). This becomes the enforceable "tree" selection.
    setGovProfile(
      buildGovernanceProfile({
        entry: ori.entry,
        userRole: ori.userRole,
        orgSize: ori.orgSize,
        classification: c,
        aiMaturity: ori.aiMaturity,
        riskAppetite: ori.riskAppetite,
        automationAppetite: ori.automationAppetite,
      })
    );
    setStage("B");
  }

  function nextFromB() {
    setErr(null);
    const qs = followupBank.map((q) => ({ q, a: "" }));
    setFollowups(qs);
    setStage("C");
  }

  async function submit() {
    setErr(null);

    // Guardrails: no secrets in any text fields.
    const fields = [
      ori.problemDomain,
      ...followups.map((f) => f.a),
      company,
      name,
      email,
    ];
    for (const f of fields) {
      const v = violatesIntakeGuardrails(f);
      if (v) { setErr(v); return; }
    }

    if (safeTrim(company).length < 2) { setErr("Company is required."); return; }
    if (!safeTrim(email).includes("@")) { setErr("Valid email is required."); return; }

    setBusy(true);
    try {
      const fn = httpsCallable(functions, "submitRiskScan");

      const profile =
        govProfile ||
        buildGovernanceProfile({
          entry: ori.entry,
          userRole: ori.userRole,
          orgSize: ori.orgSize,
          classification,
          aiMaturity: ori.aiMaturity,
          riskAppetite: ori.riskAppetite,
          automationAppetite: ori.automationAppetite,
        });

      // Server scoring expects an array of strings (or q1/q2...). Keep it clean.
      const scoringAnswers: string[] = [
        ori.entry,
        ori.userRole,
        ori.orgSize,
        ori.aiMaturity,
        ori.riskAppetite,
        ori.automationAppetite,
        classification,
        safeTrim(ori.problemDomain),
        ...followups.map((f) => safeTrim(f.a)),
        // Include explicit governance posture so server-side heuristics can evolve later.
        `governance_tier:${profile.tier}`,
        `autonomy_level:${profile.autonomyLevel}`,
        `logging_depth:${profile.loggingDepth}`,
        `patch_mode:${profile.patchMode}`,
      ].filter(Boolean);

      const payload = {
        name: safeTrim(name),
        email: safeTrim(email),
        company: safeTrim(company),
        notes: "",
        ai_goal: safeTrim(ori.problemDomain),
        tier: recommendedTier,
        score: 0,
        // IMPORTANT: backend scoring expects a string array.
        answers: scoringAnswers,

        // Optional structured payload for downstream (ignored by scoring):
        answers_kv: [
          { k: "entry", v: ori.entry },
          { k: "user_role", v: ori.userRole },
          { k: "org_size", v: ori.orgSize },
          { k: "ai_maturity", v: ori.aiMaturity },
          { k: "risk_appetite", v: ori.riskAppetite },
          { k: "automation_appetite", v: ori.automationAppetite },
          { k: "classification", v: classification },
          { k: "governance_profile", v: JSON.stringify(profile) },
          ...followups.map((f, i) => ({ k: `followup_${i + 1}`, v: safeTrim(f.a) })),
        ],

        governance_profile: profile,
        source: "adaptive_intake",
      };

      const res: any = await fn(payload);
      const leadId = res?.data?.leadId || safeTrim(email).toLowerCase();

      // Persist for Evidence Intake.
      localStorage.setItem("aicomms_leadId", String(leadId));
      localStorage.setItem("aicomms_email", safeTrim(email));
      localStorage.setItem("aicomms_plan", String(recommendedTier));
      localStorage.setItem("aicomms_company", safeTrim(company));
      localStorage.setItem("aicomms_governance_profile", JSON.stringify(profile));

      nav(`/checkout?leadId=${encodeURIComponent(leadId)}&tier=${encodeURIComponent(recommendedTier)}&email=${encodeURIComponent(safeTrim(email))}`);
    } catch (e: any) {
      setErr(e?.message || "Failed to submit intake.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Section title="Adaptive Intake">
      <GlassCard>
        <h1 className="h1">Adaptive Intake</h1>
        <p className="p">
          Quick questions so we can point you to the right path.
          We never ask for passwords, API keys, or anything sensitive.
        </p>

        {err && (
          <div className="mt-4 rounded-2xl border border-red-400/30 bg-red-500/10 p-4 text-sm text-red-200">
            {err}
          </div>
        )}

        {stage === "A" && (
          <div className="mt-6 grid gap-4">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-sm opacity-80">Entry path</div>
              <div className="text-lg font-semibold mt-1">
                {entry === "audit" ? "🔐 AI Safety Checkup" : "⚙️ Automate Safely"}
              </div>
            </div>

            <label className="text-sm">
              <div className="opacity-80 mb-1">Which best describes you?</div>
              <select
                value={ori.userRole}
                onChange={(e) => setOri((o) => ({ ...o, userRole: e.target.value as any }))}
                className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
              >
                <option value="owner">Business owner / founder</option>
                <option value="ops">Operations / manager</option>
                <option value="tech">Technical / developer</option>
              </select>
              <div className="text-xs opacity-70 mt-2">
                This only changes the wording of a few questions (plain-English vs. technical).
              </div>
            </label>

            <label className="text-sm">
              <div className="opacity-80 mb-1">Organization size</div>
              <select
                value={ori.orgSize}
                onChange={(e) => setOri((o) => ({ ...o, orgSize: e.target.value as any }))}
                className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
              >
                <option value="solo">Solo / one-person</option>
                <option value="small">Small business</option>
                <option value="mid">Mid-market</option>
                <option value="enterprise">Large enterprise</option>
                <option value="government">Government / public sector</option>
              </select>
              <div className="text-xs opacity-70 mt-2">
                This determines your governance posture (autonomy ceilings, logging, and approval gates).
              </div>
            </label>

            <label className="text-sm">
              <div className="opacity-80 mb-1">Problem domain</div>
              <input
                value={ori.problemDomain}
                onChange={(e) => setOri((o) => ({ ...o, problemDomain: e.target.value }))}
                className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                placeholder="Example: ‘respond to customers faster’, ‘reduce mistakes in invoices’, ‘automate scheduling’, ‘keep AI from saying the wrong thing’"
              />
              <div className="text-xs opacity-70 mt-2">
                Guardrails: describe at a high level — do not paste secrets, keys, or passwords.
              </div>
            </label>

            <div className="grid md:grid-cols-2 gap-4">
              <label className="text-sm">
                <div className="opacity-80 mb-1">AI usage maturity</div>
                <select
                  value={ori.aiMaturity}
                  onChange={(e) => setOri((o) => ({ ...o, aiMaturity: e.target.value as any }))}
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                >
                  <option value="new">New / experimenting</option>
                  <option value="some">Some production use</option>
                  <option value="advanced">Advanced / multiple agents</option>
                </select>
              </label>

              <label className="text-sm">
                <div className="opacity-80 mb-1">Risk appetite</div>
                <select
                  value={ori.riskAppetite}
                  onChange={(e) => setOri((o) => ({ ...o, riskAppetite: e.target.value as any }))}
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                >
                  <option value="low">Low (tight approvals)</option>
                  <option value="medium">Medium (balanced)</option>
                  <option value="high">High (move fast, still bounded)</option>
                </select>
              </label>

              <label className="text-sm">
                <div className="opacity-80 mb-1">Automation appetite</div>
                <select
                  value={ori.automationAppetite}
                  onChange={(e) => setOri((o) => ({ ...o, automationAppetite: e.target.value as any }))}
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>
            </div>

            <div className="flex justify-end">
              <CTAButton onClick={nextFromA}>Continue</CTAButton>
            </div>
          </div>
        )}

        {stage === "B" && (
          <div className="mt-6 grid gap-4">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-sm opacity-80">Stage B — Classification</div>
              <div className="text-2xl font-bold mt-1">
                {classification === "governance_audit" ? "Safety & Governance" : classification === "stack_build" ? "Automation Build" : "Safety + Automation"}
              </div>
              <div className="text-sm opacity-80 mt-2">
                Recommended plan: <span className="font-semibold">{recommendedTier.toUpperCase()}</span>
              </div>

              {govProfile && (
                <div className="mt-4 rounded-2xl border border-white/10 bg-black/20 p-4 text-sm">
                  <div className="font-semibold">Governance Profile</div>
                  <div className="mt-2 grid gap-1 opacity-90">
                    <div><span className="opacity-70">Tier:</span> <span className="font-semibold">{govProfile.tier}</span></div>
                    <div><span className="opacity-70">Autonomy ceiling:</span> <span className="font-semibold">L{govProfile.autonomyLevel}</span></div>
                    <div><span className="opacity-70">Logging:</span> <span className="font-semibold">{govProfile.loggingDepth}</span></div>
                    <div><span className="opacity-70">Patch mode:</span> <span className="font-semibold">{govProfile.patchMode}</span></div>
                    <div><span className="opacity-70">Escalation SLA:</span> <span className="font-semibold">{govProfile.escalationSla}</span></div>
                  </div>
                  <div className="mt-3 text-xs opacity-70">
                    This profile is enforced by the system. Higher-risk changes require explicit approval.
                  </div>
                </div>
              )}
            </div>

            <div className="text-sm opacity-80">
              Next, we ask only what’s required — and stop when we have sufficient evidence.
            </div>

            <div className="flex justify-between">
              <button
                className="rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm hover:bg-white/10"
                onClick={() => setStage("A")}
              >
                Back
              </button>
              <CTAButton onClick={nextFromB}>Continue</CTAButton>
            </div>
          </div>
        )}

        {stage === "C" && (
          <div className="mt-6 grid gap-4">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="text-sm opacity-80">Stage C — Targeted Follow-Ups</div>
              <div className="text-sm opacity-80 mt-1">
                Question depth limit: {INTAKE_GUARDRAILS.maxFollowupQuestions}
              </div>
            </div>

            {followupBank.map((q, idx) => (
              <label key={idx} className="text-sm">
                <div className="opacity-80 mb-1">{q}</div>
                <input
                  value={followups[idx]?.a || ""}
                  onChange={(e) => setFollowupAnswer(idx, e.target.value)}
                  className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3"
                  placeholder="Answer (no secrets)"
                />
              </label>
            ))}

            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <div className="font-semibold">Contact</div>
              <div className="grid md:grid-cols-2 gap-3 mt-3">
                <input value={company} onChange={(e) => setCompany(e.target.value)} className="rounded-xl bg-black/40 border border-white/10 px-4 py-3" placeholder="Company" />
                <input value={name} onChange={(e) => setName(e.target.value)} className="rounded-xl bg-black/40 border border-white/10 px-4 py-3" placeholder="Name (optional)" />
                <input value={email} onChange={(e) => setEmail(e.target.value)} className="md:col-span-2 rounded-xl bg-black/40 border border-white/10 px-4 py-3" placeholder="Email" />
              </div>
            </div>

            <div className="flex justify-between">
              <button
                className="rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm hover:bg-white/10"
                onClick={() => setStage("B")}
                disabled={busy}
              >
                Back
              </button>
              <CTAButton onClick={submit} disabled={busy}>
                {busy ? "Submitting…" : "Continue to Checkout"}
              </CTAButton>
            </div>
          </div>
        )}
      </GlassCard>
    </Section>
  );
}
