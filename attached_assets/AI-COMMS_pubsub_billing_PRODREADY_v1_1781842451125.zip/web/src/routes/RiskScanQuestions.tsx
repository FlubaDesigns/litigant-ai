import { useState } from "react";
import { useNavigate } from "react-router-dom";

const questions = [
  {
    id: "q1",
    text: "Do you use AI to generate or edit client-facing deliverables?",
    options: [
      { label: "No", score: 0 },
      { label: "Occasionally", score: 8 },
      { label: "Weekly", score: 12 },
      { label: "Daily / High Volume", score: 18 },
    ],
  },
  {
    id: "q2",
    text: "Do AI outputs ever go out without human review?",
    options: [
      { label: "Never", score: 0 },
      { label: "Rarely", score: 12 },
      { label: "Sometimes", score: 22 },
      { label: "Often / Automated", score: 35 },
    ],
  },
  {
    id: "q3",
    text: "Do you have written, enforced AI rules?",
    options: [
      { label: "Yes and enforced", score: 0 },
      { label: "Informal only", score: 10 },
      { label: "No", score: 20 },
    ],
  },
  {
    id: "q4",
    text: "Do you track who changed prompts/workflows and when?",
    options: [
      { label: "Yes (audit trail)", score: 0 },
      { label: "Partial", score: 10 },
      { label: "No", score: 20 },
    ],
  },
  {
    id: "q5",
    text: "Can you roll back AI behavior to a known-safe version quickly?",
    options: [
      { label: "Yes", score: 0 },
      { label: "Maybe", score: 10 },
      { label: "No", score: 20 },
    ],
  },
  {
    id: "q6",
    text: "Do you input sensitive client data into prompts?",
    options: [
      { label: "Never", score: 0 },
      { label: "Rarely", score: 12 },
      { label: "Sometimes", score: 22 },
      { label: "Often", score: 35 },
    ],
  },
  {
    id: "q7",
    text: "Do you use multiple AI tools in one workflow?",
    options: [
      { label: "No", score: 0 },
      { label: "2 tools", score: 8 },
      { label: "3+ tools", score: 15 },
    ],
  },
  {
    id: "q8",
    text: "Could you prove what rules your AI operated under last month?",
    options: [
      { label: "Yes", score: 0 },
      { label: "Not sure", score: 15 },
      { label: "No", score: 30 },
    ],
  },
];

export default function RiskScanQuestions() {
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<any[]>([]);

  const current = questions[index];

  const handleSelect = (score: number) => {
    const updated = [...answers];
    updated[index] = { questionId: current.id, score };
    setAnswers(updated);

    if (index < questions.length - 1) {
      setIndex(index + 1);
    } else {
      localStorage.setItem("riskScanAnswers", JSON.stringify(updated));
      navigate("/risk-scan/result");
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center px-6">
      <div className="max-w-xl w-full space-y-8">
        <div className="text-sm text-gray-400">
          Question {index + 1} of {questions.length}
        </div>

        <h2 className="text-2xl font-semibold">{current.text}</h2>

        <div className="space-y-4">
          {current.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleSelect(opt.score)}
              className="w-full bg-gray-900 border border-gray-700 px-6 py-4 rounded-lg hover:bg-gray-800 transition text-left"
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}