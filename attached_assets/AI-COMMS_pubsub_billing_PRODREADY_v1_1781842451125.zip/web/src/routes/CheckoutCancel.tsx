import GlassCard from "../components/GlassCard";
import Section from "../components/Section";
import CTAButton from "../components/CTAButton";

export default function CheckoutCancel() {
  return (
    <div>
      <h1 className="h1">Payment Canceled</h1>
      <p className="p" style={{ maxWidth: 900 }}>
        No problem. You can restart payment any time, or submit intake first and we’ll walk you through options.
      </p>

      <div className="hr" />

      <Section title="Next options" kicker="Choose">
        <GlassCard>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <CTAButton to="/checkout" label="Try Payment Again" variant="primary" />
            <CTAButton to="/intake" label="Start Intake" variant="secondary" />
            <CTAButton to="/services" label="Back to Services" variant="secondary" />
          </div>
        </GlassCard>
      </Section>
    </div>
  );
}