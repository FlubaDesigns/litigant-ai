import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";
import Section from "../components/Section";

function Step({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <GlassCard>
      <div className="badge">Step {n}</div>
      <div style={{ fontWeight: 900, fontSize: 16, marginTop: 8 }}>{title}</div>
      <p className="p">{body}</p>
    </GlassCard>
  );
}

export default function HowItWorks() {
  return (
    <div>
      <h1 className="h1">How It Works</h1>
      <p className="p" style={{ maxWidth: 860 }}>
        We don’t sell “prompt tricks.” We set up safe automation so you get repeatable outcomes — with approvals, logs, and clear limits.
      </p>

      <div className="hr" />

      <Section title="Process" kicker="Five steps">
        <div className="grid grid-2">
          <Step n="1" title="Find the risk" body="We identify where AI could cost you money: wrong messages, wrong invoices, policy mistakes, or silent automation." />
          <Step n="2" title="Set the rules" body="Who approves what. What AI can and can’t touch. What gets logged. What triggers an alert to you." />
          <Step n="3" title="Install safely" body="We deliver a structured packet you can implement — or we implement it for you — without asking for secrets." />
          <Step n="4" title="Test before trust" body="We validate the workflow with clear acceptance checks so you’re not betting your business on “it should work.”" />
          <Step n="5" title="Ongoing protection" body="Updates happen safely: drift checks, connector compatibility checks, and upgrades with a paper trail." />
        </div>
      </Section>

      <Section title="Start with an intake" kicker="Fastest path">
        <GlassCard>
          <p className="p">If you can describe the failure, we can constrain it. Intake takes 2–4 minutes.</p>
          <div style={{ marginTop: 12 }}>
            <CTAButton to="/intake" label="Start Intake" variant="primary" />
          </div>
        </GlassCard>
      </Section>
    </div>
  );
}