import { useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";

type ClientStatus = {
  ok: boolean;
  error?: string;
  company?: string;
  status?: string;
  audit?: { started: boolean; completed: boolean };
  proposal?: { sent: boolean };
  contract?: { sent: boolean };
};

export default function ClientPortal() {
  const { leadId } = useParams();
  const [sp] = useSearchParams();
  const token = sp.get("token") || "";

  const [data, setData] = useState<ClientStatus | null>(null);
  const [err, setErr] = useState("");

  const endpoint = useMemo(() => {
    return `/clientStatus?leadId=${encodeURIComponent(leadId || "")}&token=${encodeURIComponent(token)}`;
  }, [leadId, token]);

  useEffect(() => {
    async function run() {
      setErr("");
      setData(null);

      if (!leadId || !token) {
        setErr("Missing leadId or token.");
        return;
      }

      try {
        const r = await fetch(endpoint);
        const j = (await r.json()) as ClientStatus;
        if (!j.ok) {
          setErr(j.error || "Unable to load status.");
          return;
        }
        setData(j);
      } catch (e: any) {
        setErr(e?.message || "Network error.");
      }
    }
    run();
  }, [endpoint, leadId, token]);

  return (
    <div className="min-h-screen bg-black text-white px-6 py-16">
      <div className="max-w-3xl mx-auto space-y-10">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Client Portal</h1>
          <p className="text-gray-300">Status-only view. No internal notes.</p>
        </div>

        {err && (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className="font-semibold">Error</div>
            <div className="text-gray-300 mt-1">{err}</div>
          </div>
        )}

        {data && (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-6 space-y-2">
            <div><span className="text-gray-400">Company:</span> {data.company || "—"}</div>
            <div><span className="text-gray-400">Status:</span> {data.status || "—"}</div>
            <div><span className="text-gray-400">Audit started:</span> {data.audit?.started ? "Yes" : "No"}</div>
            <div><span className="text-gray-400">Audit completed:</span> {data.audit?.completed ? "Yes" : "No"}</div>
            <div><span className="text-gray-400">Proposal sent:</span> {data.proposal?.sent ? "Yes" : "No"}</div>
            <div><span className="text-gray-400">Contract sent:</span> {data.contract?.sent ? "Yes" : "No"}</div>
          </div>
        )}
      </div>
    </div>
  );
}