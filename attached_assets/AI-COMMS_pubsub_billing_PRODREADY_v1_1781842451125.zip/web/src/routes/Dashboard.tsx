import ProtectionFeed from "../components/ProtectionFeed";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { auth, db, functions } from "../firebase";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";
import CTAButton from "../components/CTAButton";

type UserDoc = {
  plan?: string | null;
  tier?: string | null;
  creditBalance?: number | null;
  lifetimeCreditsPurchased?: number | null;
  lifetimeCreditsUsed?: number | null;
  billing_status?: "active" | "grace" | "canceled" | string | null;
  grace_expires_at?: any;
  stripe_customer_id?: string | null;
  updated_at?: any;
};

function useQuery() {
  const { search } = useLocation();
  return useMemo(() => new URLSearchParams(search), [search]);
}

export default function Dashboard() {
  const nav = useNavigate();
  const q = useQuery();
  const [uid, setUid] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  const [data, setData] = useState<UserDoc | null>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [err, setErr] = useState<string | null>(null);

  // Optional redirect back after login
  const returnTo = useMemo(() => {
    const rt = q.get("returnTo");
    return rt ? decodeURIComponent(rt) : null;
  }, [q]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u) {
        const here = encodeURIComponent(window.location.pathname + window.location.search);
        nav(`/login?returnTo=${here}`, { replace: true });
        return;
      }
      setUid(u.uid);
      setEmail(u.email || null);
    });
    return () => unsub();
  }, [nav]);

  useEffect(() => {
    async function load() {
      if (!uid) return;
      setStatus("loading");
      setErr(null);

      try {
        const ref = doc(db, "users", uid);
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          setData({
            plan: "explorer",
            tier: "explorer",
            creditBalance: 0,
            lifetimeCreditsPurchased: 0,
            lifetimeCreditsUsed: 0,
            billing_status: null,
          });
          setStatus("idle");
          return;
        }
        setData(snap.data() as UserDoc);
        setStatus("idle");
      } catch (e: any) {
        setStatus("error");
        setErr(e?.message || "Failed to load dashboard.");
      }
    }
    load();
  }, [uid]);

  const planLabel = useMemo(() => {
    const p = String(data?.plan || data?.tier || "").toLowerCase();
    if (p === "enterprise") return "Enterprise";
    if (p === "pro") return "Pro";
    if (p === "builder") return "Builder";
    if (p === "explorer") return "Explorer (Governance Credit)";
    if (p === "audit") return "Audit";
    return p ? p : "Explorer";
  }, [data?.plan, data?.tier]);

  const credits = Math.max(0, Number(data?.creditBalance || 0));
  const billingStatus = String(data?.billing_status || "").toLowerCase();

  async function openBillingPortal() {
    try {
      const fn = httpsCallable(functions, "createBillingPortalSession");
      const res: any = await fn({});
      const url = res?.data?.url;
      if (url) window.location.href = url;
    } catch (e: any) {
      alert(e?.message || "Could not open billing portal.");
    }
  }

  return (
    <div>
      <h1 className="h1">Dashboard</h1>
      <p className="p" style={{ maxWidth: 980 }}>
        Your coverage, credits, and protection activity live here. Calm interface. Strong safeguards.
      </p>

      <div className="hr" />

      {status === "error" && (
        <div className="p" style={{ color: "#ffb4b4" }}>
          {err || "Error"}
        </div>
      )}

      {billingStatus === "grace" && (
        <div className="p" style={{ padding: 12, borderRadius: 12, background: "rgba(255, 200, 0, 0.12)", border: "1px solid rgba(255, 200, 0, 0.25)" }}>
          <b>Grace Period:</b> Payment issue detected. Coverage remains active temporarily while you update billing.
          {" "}
          <button onClick={openBillingPortal} style={{ textDecoration: "underline" }}>Manage billing</button>
        </div>
      )}

      {billingStatus === "canceled" && (
        <div className="p" style={{ padding: 12, borderRadius: 12, background: "rgba(255, 90, 90, 0.12)", border: "1px solid rgba(255, 90, 90, 0.25)" }}>
          <b>Coverage Downgraded:</b> Subscription is canceled. Upgrade to restore full protection.
        </div>
      )}

      <Section title="Account" kicker="Plan + credits">
        <div className="grid grid-2">
          <GlassCard>
            <div className="text-sm opacity-80">Signed in as</div>
            <div className="text-lg font-semibold" style={{ marginTop: 6 }}>
              {email || uid || "—"}
            </div>

            <div style={{ marginTop: 14 }} className="text-sm opacity-80">
              Plan
            </div>
            <div className="text-xl font-bold" style={{ marginTop: 4 }}>
              {planLabel}
            </div>

            <div style={{ marginTop: 14 }} className="text-sm opacity-80">
              Credits available
            </div>
{String(data?.plan || data?.tier || "").toLowerCase() === "minutes_hybrid" && (
  <div style={{ marginTop: 14, padding: 12, borderRadius: 12, background: "rgba(0, 140, 255, 0.10)", border: "1px solid rgba(0, 140, 255, 0.22)" }}>
    <div className="text-sm opacity-80">Minutes plan</div>
    <div style={{ marginTop: 6 }}>
      Included: <b>{Number((data as any)?.included_minutes_per_month || 60)}</b> / month • Used:{" "}
      <b>{Number((data as any)?.minutes_used_current_period || 0)}</b> • Remaining:{" "}
      <b>{Math.max(0, Number((data as any)?.included_minutes_per_month || 60) - Number((data as any)?.minutes_used_current_period || 0))}</b>
    </div>
    <div style={{ marginTop: 10, display: "flex", gap: 10, flexWrap: "wrap" }}>
      <button
        onClick={async () => {
          try {
            const fn = httpsCallable(functions, "reportUsageMinutes");
            await fn({ minutes: 5, source: "dashboard_test", detail: "Simulated usage" });
            window.location.reload();
          } catch (e: any) {
            alert(e?.message || "Failed to report usage.");
          }
        }}
        className="btn btn-secondary"
        style={{ padding: "10px 14px", borderRadius: 12 }}
      >
        Simulate 5 minutes usage
      </button>
    </div>
  </div>
)}

            <div className="text-3xl font-black" style={{ marginTop: 4 }}>
              ${credits}
            </div>

            <div style={{ marginTop: 14, display: "flex", gap: 12, flexWrap: "wrap" }}>
              <CTAButton to="/pricing" label="Upgrade plan" variant="primary" />
              <CTAButton to="/checkout?tier=explorer" label="Add $25 Governance Credit" variant="secondary" />
              <button
                onClick={openBillingPortal}
                className="btn btn-secondary"
                style={{ padding: "10px 14px", borderRadius: 12 }}
              >
                Manage billing
              </button>
            </div>
          </GlassCard>
        </div>
      </Section>

      <ProtectionFeed />
    </div>
  );
