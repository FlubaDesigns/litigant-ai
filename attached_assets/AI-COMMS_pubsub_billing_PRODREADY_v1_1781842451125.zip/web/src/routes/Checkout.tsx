
import { useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import { httpsCallable } from "firebase/functions";
import { auth, functions } from "../firebase";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";
import CTAButton from "../components/CTAButton";
import { parseGovernanceProfile } from "../lib/governanceProfile";

type Tier = "explorer" | "audit" | "pro" | "enterprise";
type Plan = "minutes" | "diy" | Tier;

function useQuery() {
  const { search } = useLocation();
  return useMemo(() => new URLSearchParams(search), [search]);
}

function normalizePlan(v: string | null): Plan {
  const s = String(v || "").trim().toLowerCase();
  if (s === "diy" || s === "self" || s === "self_implement") return "diy";
  if (s === "minutes" || s === "minutes_hybrid" || s === "hybrid") return "minutes";
  if (s === "basic") return "audit";
  if (s === "full") return "pro";
  if (s === "enterprise") return "enterprise";
  if (s === "pro") return "pro";
  if (s === "explorer") return "explorer";
  return "audit";
}

const LABEL: Record<Plan, string> = {
  minutes: "Minutes Plan ($25/mo + overage)",
  diy: "DIY Kit (Self Implement)",
  explorer: "Governance Credit ($25 one-time)",
  audit: "Audit (one-time deliverable)",
  pro: "Pro (one-time deliverable)",
  enterprise: "Enterprise (one-time deliverable)",
};

export default function Checkout() {
  const q = useQuery();
  const plan = normalizePlan(q.get("plan"));
  const tierId = q.get("tierId"); // NEW: tiered DFY/DYS flow
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  async function go() {
    setBusy(true);
    setMsg("");

    try {
      const gp = parseGovernanceProfile(localStorage.getItem("aicomms_governance_profile") || "");
      // Ensure authed if tiered flow (org binding)
      if (tierId) {
        if (!auth.currentUser) throw new Error("Please log in first (owner binding required).");
        const fn = httpsCallable(functions, "createTieredCheckoutSession");
        const res: any = await fn({
          orgId: auth.currentUser.uid,
          tierId,
          addonIds: [],
          returnUrl: window.location.origin + "/checkout/success",
        });
        const url = res?.data?.url;
        if (!url) throw new Error("No checkout URL returned.");
        window.location.href = url;
        return;
      }

      // Legacy flow
      const fn = httpsCallable(functions, "createCheckoutSession");
      const res: any = await fn({ plan, governanceProfile: gp || null });
      const url = res?.data?.url;
      if (!url) throw new Error("No checkout URL returned.");
      window.location.href = url;
    } catch (e: any) {
      setMsg(String(e?.message || e));
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <Section title="Checkout">
        <p style={{ opacity: 0.85 }}>
          {tierId ? `Selected tier: ${tierId}` : `Selected plan: ${LABEL[plan]}`}
        </p>
      </Section>

      <GlassCard>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <CTAButton onClick={go} disabled={busy}>
            {busy ? "Redirecting…" : "Proceed to secure checkout"}
          </CTAButton>
          {msg ? <div style={{ opacity: 0.8 }}>{msg}</div> : null}
          {tierId ? <div style={{ opacity: 0.7, fontSize: 12 }}>Note: Tiered plans require login (org binding).</div> : null}
        </div>
      </GlassCard>
    </div>
  );
}
