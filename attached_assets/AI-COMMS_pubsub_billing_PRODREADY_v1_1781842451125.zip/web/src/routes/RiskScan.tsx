import { Link } from "react-router-dom";

export default function RiskScan() {
  return (
    <div className="min-h-screen bg-black text-white px-6 py-14">
      <div className="max-w-4xl mx-auto space-y-10">
        <header className="space-y-4">
          <div className="inline-flex items-center gap-2 text-xs tracking-widest uppercase text-gray-400">
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">AI-COMMS</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">Risk Scan</span>
            <span className="px-2 py-1 rounded border border-gray-800 bg-gray-950">Governance Exposure</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
            AI Governance Risk Scan
          </h1>

          <p className="text-lg text-gray-300 max-w-3xl">
            8 questions. 60 seconds. Get a risk score (0–100) based on how AI touches your workflow,
            how review is handled, and whether you can prove and roll back AI behavior over time.
          </p>
        </header>

        <div className="rounded-2xl border border-gray-800 bg-gray-950 p-6 space-y-4">
          <h2 className="text-xl font-semibold">What you’ll get</h2>
          <ul className="text-gray-300 space-y-2 list-disc pl-5">
            <li>A normalized risk score (0–100)</li>
            <li>A severity band: LOW / MODERATE / HIGH / CRITICAL</li>
            <li>A recommended next step based on your risk</li>
            <li>Option to request a short governance review</li>
          </ul>

          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <Link
              to="/risk-scan/questions"
              className="inline-flex items-center justify-center bg-white text-black px-8 py-4 rounded-lg font-semibold hover:bg-gray-200 transition"
            >
              Start the Risk Scan
            </Link>

            <Link
              to="/pricing"
              className="inline-flex items-center justify-center border border-gray-700 px-8 py-4 rounded-lg hover:bg-gray-900 transition"
            >
              See Pricing
            </Link>
          </div>

          <div className="text-xs text-gray-500">
            This scan is informational. If AI touches client deliverables, contracts, pricing, compliance, or operations,
            governance matters.
          </div>
        </div>
      </div>
    </div>
  );
}