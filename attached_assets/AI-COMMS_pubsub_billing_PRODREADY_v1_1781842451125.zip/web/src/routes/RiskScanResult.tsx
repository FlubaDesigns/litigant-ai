
import { useNavigate } from "react-router-dom";

export default function RiskScanResult() {
  const nav = useNavigate();

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center px-6 text-center">
      <h1 className="text-4xl font-bold mb-6">
        Your Blanket Coverage Report
      </h1>

      <div className="bg-gray-900 p-6 rounded-xl shadow-lg mb-6 w-full max-w-md">
        <p className="text-3xl font-bold text-green-400 mb-2">72 / 100</p>
        <p className="text-gray-400">
          Coverage is partial. There are thin spots in monitoring,
          validation, and drift protection.
        </p>
      </div>

      <button
        onClick={() => nav("/Pricing")}
        className="bg-blue-600 px-8 py-4 rounded-xl text-lg hover:bg-blue-500 transition"
      >
        Wrap My AI in Protection
      </button>
    </div>
  );
}
