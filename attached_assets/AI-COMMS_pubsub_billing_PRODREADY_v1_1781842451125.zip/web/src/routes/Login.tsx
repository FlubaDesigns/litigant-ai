import { useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
} from "firebase/auth";
import { auth, googleProvider } from "../firebase";
import GlassCard from "../components/GlassCard";
import Section from "../components/Section";

export default function Login() {
  const nav = useNavigate();
  const loc = useLocation();
  const returnTo = useMemo(() => {
    const sp = new URLSearchParams(loc.search);
    const rt = sp.get("returnTo");
    return rt ? decodeURIComponent(rt) : null;
  }, [loc.search]);
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "working" | "error">("idle");
  const [error, setError] = useState("");

  const canSubmit = useMemo(() => {
    return email.trim().length >= 6 && password.length >= 6;
  }, [email, password]);

  async function handleEmailAuth() {
    if (!canSubmit || status === "working") return;
    setStatus("working");
    setError("");

    try {
      if (mode === "signin") {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      } else {
        await createUserWithEmailAndPassword(auth, email.trim(), password);
      }
      nav(returnTo || "/portal");
    } catch (e: any) {
      setStatus("error");
      setError(e?.message || "Login failed.");
    } finally {
      setStatus("idle");
    }
  }

  async function handleGoogle() {
    if (status === "working") return;
    setStatus("working");
    setError("");

    try {
      await signInWithPopup(auth, googleProvider);
      nav(returnTo || "/portal");
    } catch (e: any) {
      setStatus("error");
      setError(e?.message || "Google sign-in failed.");
    } finally {
      setStatus("idle");
    }
  }

  return (
    <div>
      <h1 className="h1">Sign in</h1>
      <p className="p" style={{ maxWidth: 900 }}>
        Sign in to access your dashboard and purchases. Admins can still use the admin panel.
      </p>

      <div className="hr" />

      <Section title="Sign in" kicker="Email or Google">
        <div className="grid grid-2">
          <GlassCard>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 10 }}>
              <button
                className={`btn ${mode === "signin" ? "btn-primary" : "btn-secondary"}`}
                type="button"
                onClick={() => setMode("signin")}
              >
                Sign In
              </button>
              <button
                className={`btn ${mode === "signup" ? "btn-primary" : "btn-secondary"}`}
                type="button"
                onClick={() => setMode("signup")}
              >
                Create Account
              </button>
            </div>

            <div className="label">Email</div>
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} />

            <div className="label" style={{ marginTop: 10 }}>
              Password (min 6 chars)
            </div>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            {error && (
              <div className="badge" style={{ marginTop: 10 }}>
                Error: {error}
              </div>
            )}

            <div style={{ marginTop: 12 }}>
              <button className="btn btn-primary" type="button" onClick={handleEmailAuth} disabled={!canSubmit}>
                {mode === "signin" ? "Sign In" : "Create Account"}
              </button>
            </div>

            <p className="p" style={{ marginTop: 10 }}>
              Note: Creating an account does not automatically grant admin access. Admin read access is controlled by
              Firestore rules.
            </p>
          </GlassCard>

          <GlassCard>
            <div style={{ fontWeight: 900 }}>Google Sign-In</div>
            <p className="p">
              Fastest option. Recommended for your workflow.
            </p>

            <button className="btn btn-secondary" type="button" onClick={handleGoogle}>
              Continue with Google