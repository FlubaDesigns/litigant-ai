import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Portal() {
  const nav = useNavigate();
  const [leadId, setLeadId] = useState("");

  const normalizedLead = useMemo(() => leadId.trim(), [leadId]);

  const card =
    "w-full rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8 hover:bg-white/10 transition cursor-pointer";
  const title = "text-xl md:text-2xl font-bold";
  const desc = "text-sm md:text-base text-gray-300 mt-2";

  return (
    <div className="min-h-screen bg-gray-950 text-white px-6 py-14">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold">Portal</h1>
        <p className="text-gray-300 mt-3 max-w-3xl">
          This is the operational doorway: paid evidence intake, client deliverables, and admin access.
          Public visitors should start with <span className="font-semibold">Risk Scan</span> or <span className="font-semibold">Pricing</span>.
        </p>

        <div className="grid md:grid-cols-3 gap-5 mt-10">
          <div className={card} onClick={() => nav("/evidence")} role="button" aria-label="Evidence Intake">
            <div className="text-3xl">📎</div>
            <div className={title + " mt-3"}>Evidence Intake</div>
            <div className={desc}>For paid customers. Provide project details and trigger DFY automation (or choose DIY).</div>
            <div className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">
              Continue <span aria-hidden>→</span>
            </div>
          </div>


          <div className={card} onClick={() => nav("/portal/projects")} role="button" aria-label="My Projects">
            <div className="text-3xl">🧾</div>
            <div className={title + " mt-3"}>My Projects</div>
            <div className={desc}>View lifecycle status, jobs, packets, and deliverables for your organization.</div>
            <div className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">
              Open <span aria-hidden>→</span>
            </div>
          </div>

          <div className={card} onClick={() => nav("/login")} role="button" aria-label="Admin Login">
            <div className="text-3xl">🛡️</div>
            <div className={title + " mt-3"}>Admin Login</div>
            <div className={desc}>Operator access for internal tools and command center.</div>
            <div className="mt-5 inline-flex items-center gap-2 text-sm font-semibold">
              Login <span aria-hidden>→</span>
            </div>
          </div>

          <div className={"w-full rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8"}>
            <div className="text-3xl">📦</div>
            <div className={title + " mt-3"}>Client Deliverables</div>
            <div className={desc}>Open your deliverables page using a Lead ID.</div>
            <div className="mt-4">
              <input
                value={leadId}
                onChange={(e) => setLeadId(e.target.value)}
                placeholder="Enter Lead ID"
                className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/10 focus:outline-none focus:ring-2 focus:ring-white/20"
              />
              <button
                className="mt-3 w-full px-4 py-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 font-semibold"
                disabled={!normalizedLead}
                onClick={() => nav(`/client/${encodeURIComponent(normalizedLead)}`)}
              >
                Open Client Portal
              </button>
            </div>
          </div>
        </div>

        <div className="mt-10 text-sm text-gray-400">
          DIY kit downloads live under <button className="underline" onClick={() => nav("/diy")}>DIY</button>.
        </div>
      </div>
    </div>
  );
}
