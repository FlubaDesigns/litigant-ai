import Section from "../components/Section";
import GlassCard from "../components/GlassCard";
import CTAButton from "../components/CTAButton";

export default function Services() {
  return (
    <div>
      <h1 className="h1">Services</h1>
      <p className="p" style={{ maxWidth: 900 }}>
        AI-COMMS helps professional organizations implement AI safely,
        structurally, and profitably. We do not sell “AI magic.”  
        We implement governance, guardrails, and execution discipline.
      </p>

      <div className="hr" />

      <Section title="Core Offering" kicker="Structured Implementation">
        <div className="grid grid-2">
          <GlassCard>
            <div style={{ fontWeight: 900, fontSize: 16 }}>
              AI Diagnostic & Governance Assessment
            </div>

            <p className="p">
              A structured evaluation of your current AI usage, failure
              points, workflow friction, and risk exposure.
            </p>

            <ul style={{ margin: "10px 0 0 18px", lineHeight: 1.7, color: "var(--muted)" }}>
              <li>Workflow breakdown & mapping</li>
              <li>Prompt & logic audit</li>
              <li>Guardrail design</li>
              <li>Role separation strategy</li>
              <li>Implementation blueprint</li>
            </ul>

            <div style={{ marginTop: 14 }}>
              <CTAButton
                to="/checkout"
                label="Pay Diagnostic Deposit"
                variant="primary"
              />
            </div>

            <p className="p" style={{ marginTop: 10 }}>
              Deposit reserves assessment time and begins structured onboarding.
            </p>
          </GlassCard>

          <GlassCard>
            <div style={{ fontWeight: 900, fontSize: 16 }}>
              Intuitive Guardrail Platform
            </div>

            <p className="p">
              Our structured governance model for managing multiple AI agents
              without drift, chaos, or hallucinated authority.
            </p>

            <ul style={{ margin: "10px 0 0 18px", lineHeight: 1.7, color: "var(--muted)" }}>
              <li>Tiered authority system</li>
              <li>Append-only canon enforcement</li>
              <li>Artifact supersession protocol</li>
              <li>Simulation transparency controls</li>
              <li>Operator override protection</li>
            </ul>

            <div style={{ marginTop: 14 }}>
              <CTAButton
                to="/intuitive"
                label="Learn About Intuitive"
                variant="secondary"
              />
            </div>
          </GlassCard>
        </div>
      </Section>

      <div className="hr" />

      <Section title="Implementation Services" kicker="Execution Layer">
        <div className="grid grid-2">
          <GlassCard>
            <div style={{ fontWeight: 900 }}>AI Workflow Structuring</div>
            <p className="p">
              We transform chaotic AI usage into structured, repeatable,
              accountable systems.
            </p>
          </GlassCard>

          <GlassCard>
            <div style={{ fontWeight: 900 }}>Multi-Agent Architecture</div>
            <p className="p">
              Controlled sandbox environments where agents stay in role and
              do not overwrite each other’s work.
            </p>
          </GlassCard>

          <GlassCard>
            <div style={{ fontWeight: 900 }}>Risk Mitigation</div>
            <p className="p">
              Prevent hallucinated authority, accidental data leakage,
              and structural drift.
            </p>
          </GlassCard>

          <GlassCard>
            <div style={{ fontWeight: 900 }}>Enterprise Scaling</div>
            <p className="p">
              Governance models that allow safe scaling across departments
              and teams.
            </p>
          </GlassCard>
        </div>
      </Section>

      <div className="hr" />

      <Section title="Next Step" kicker="Start Here">
        <GlassCard>
          <p className="p">
            If you are already using AI but it feels inconsistent, unreliable,
            or structurally fragile — start with the diagnostic.
          </p>

          <div style={{ marginTop: 14, display: "flex", gap: 12, flexWrap: "wrap" }}>
            <CTAButton to="/checkout" label="Reserve Diagnostic" variant="primary" />
            <CTAButton to="/intake" label="Submit Intake First" variant="secondary" />
          </div>
        </GlassCard>
      </Section>
    </div>
  );
}