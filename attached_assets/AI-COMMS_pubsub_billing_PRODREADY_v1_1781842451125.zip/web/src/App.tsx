import { Routes, Route, Navigate } from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

// Public marketing pages
import Home from "./routes/Home";
import Docs from "./routes/Docs";
import Services from "./routes/Services";
import Intuitive from "./routes/Intuitive";
import HowItWorks from "./routes/HowItWorks";
import CaseStudies from "./routes/CaseStudies";
import Legal from "./routes/Legal";

// Intake
import AdaptiveIntake from "./routes/AdaptiveIntake";
import EvidenceIntake from "./routes/EvidenceIntake";

// Monetization + flow pages
import Pricing from "./routes/Pricing";
import Checkout from "./routes/Checkout";
import CheckoutSuccess from "./routes/CheckoutSuccess";
import CheckoutCancel from "./routes/CheckoutCancel";

// Auth/admin pages
import Login from "./routes/Login";
import Admin from "./routes/Admin";
import AdminLaunch from "./routes/AdminLaunch";

// Delivery/workflow pages
import GuardrailPacks from "./routes/GuardrailPacks";
import Audit from "./routes/Audit";
import Implementation from "./routes/Implementation";

// Client portal
import ClientPortal from "./routes/ClientPortal";
import Portal from "./routes/Portal";
import DIY from "./routes/DIY";

// Admin command center (existing)
import AdminDashboard from "./routes/AdminDashboard";

function NotFound() {
  return (
    <div style={{ paddingTop: 40 }}>
      <h1 className="h1">404</h1>
      <p className="p">That page doesn’t exist.</p>
    </div>
  );
}

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container" style={{ paddingTop: 24, paddingBottom: 24 }}>
        <Routes>
          {/* Public */}
          <Route path="/" element={<Home />} />
          <Route path="/docs" element={<Docs />} />
          <Route path="/services" element={<Services />} />
          <Route path="/intuitive" element={<Intuitive />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/case-studies" element={<CaseStudies />} />
          <Route path="/legal" element={<Legal />} />

          <Route path="/portal" element={<Portal />} />
          <Route path="/diy" element={<DIY />} />

          {/* Intake */}
          <Route path="/intake" element={<Navigate to="/intake/audit" replace />} />
          <Route path="/intake/:mode" element={<AdaptiveIntake />} />
          <Route path="/evidence" element={<EvidenceIntake />} />

          {/* Pricing + Checkout */}
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/checkout/success" element={<CheckoutSuccess />} />
          <Route path="/checkout/cancel" element={<CheckoutCancel />} />

          {/* Auth + Admin */}
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin/launch" element={<AdminLaunch />} />
          <Route path="/admin/command" element={<AdminDashboard />} />

          {/* Delivery / Workflow */}
          <Route path="/packs" element={<GuardrailPacks />} />
          <Route path="/audit" element={<Audit />} />
          <Route path="/implementation" element={<Implementation />} />

          {/* Client portal */}
          <Route path="/client/:leadId" element={<ClientPortal />} />

          {/* Convenience redirects */}
          <Route path="/pack" element={<Navigate to="/packs" replace />} />
          <Route path="/pricing/" element={<Navigate to="/pricing" replace />} />
          <Route path="/RiskScan" element={<Navigate to="/intake/audit" replace />} />
          <Route path="/risk-scan" element={<Navigate to="/intake/audit" replace />} />

          {/* Catch-all */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}
