import versionJson from "./version.json";

export type AppVersion = {
  app: string;
  version: string;
  buildTimeUtc: string;
  webHash: string | null;
  canonHash: string | null;
  note?: string;
};

export const APP_VERSION = versionJson as AppVersion;