import { auth } from "../firebase";

async function call(path: string, method: string, body?: any) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const url = path.startsWith("/") ? path : `/${path}`;
  const res = await fetch(url, {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export function socketSubmit(payload: any) {
  return call("/socketSubmitJob", "POST", payload);
}

export function socketGet(jobId: string) {
  return call(`/socketGetJob?jobId=${encodeURIComponent(jobId)}`, "GET");
}

export function socketApply(jobId: string, body?: any) {
  return call(`/socketApplyJob?jobId=${encodeURIComponent(jobId)}`, "POST", body || {});
}

export function socketRollback(jobId: string, body?: any) {
  return call(`/socketRollbackJob?jobId=${encodeURIComponent(jobId)}`, "POST", body || {});
}
