import { auth } from "../firebase";

async function authedFetch(path: string) {
  const user = auth.currentUser;
  const token = user ? await user.getIdToken() : "";
  const res = await fetch(path, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  const json = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, json };
}

export function getMyProjects(limit = 50) {
  return authedFetch(`/apiMyProjects?limit=${encodeURIComponent(String(limit))}`);
}

export function getProjectDetail(projectId: string) {
  return authedFetch(`/apiProjectDetail?projectId=${encodeURIComponent(projectId)}`);
}
