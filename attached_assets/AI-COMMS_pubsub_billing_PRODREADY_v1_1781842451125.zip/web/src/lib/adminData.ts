import { db } from "../firebase";
import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
  type Unsubscribe,
} from "firebase/firestore";

export function watchLatestLeads(cb: (rows: any[]) => void, err?: (e: any) => void): Unsubscribe {
  // Sort by updated_at if present; fall back to created_at.
  const q = query(collection(db, "leads"), orderBy("updated_at", "desc"), limit(50));
  return onSnapshot(q, (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), err);
}

export function watchRiskScansForLead(leadId: string, cb: (rows: any[]) => void, err?: (e: any) => void): Unsubscribe {
  const q = query(collection(db, "risk_scans"), where("leadId", "==", leadId), orderBy("created_at", "desc"), limit(25));
  return onSnapshot(q, (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), err);
}

export function watchSpiderJobs(cb: (rows: any[]) => void, err?: (e: any) => void): Unsubscribe {
  const q = query(collection(db, "spider_jobs"), orderBy("created_at", "desc"), limit(50));
  return onSnapshot(q, (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), err);
}

export function watchApprovalQueue(cb: (rows: any[]) => void, err?: (e: any) => void): Unsubscribe {
  const q = query(collection(db, "orchestrator_requests"), where("status", "in", ["queued", "reviewing", "awaiting_architect"]), orderBy("reviewing_at", "desc"), limit(50));
  return onSnapshot(q, (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), err);
}

export function watchReports(cb: (rows: any[]) => void, err?: (e: any) => void): Unsubscribe {
  const q = query(collection(db, "reports"), orderBy("created_at", "desc"), limit(50));
  return onSnapshot(q, (snap) => cb(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), err);
}

export async function getSecurityConfig(): Promise<any | null> {
  const s = await getDoc(doc(db, "system_state", "security_config"));
  return s.exists() ? s.data() : null;
}
