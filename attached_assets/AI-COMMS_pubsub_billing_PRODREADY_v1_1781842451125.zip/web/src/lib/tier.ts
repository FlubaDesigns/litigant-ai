import { doc, onSnapshot } from "firebase/firestore";
import { useEffect, useState } from "react";
import { auth, db } from "../firebase";

export type Tier = "builder" | "pro" | "enterprise";

export function tierRank(t: Tier): number {
  if (t === "enterprise") return 3;
  if (t === "pro") return 2;
  return 1;
}

export function useTier(): { tier: Tier; loading: boolean } {
  const [tier, setTier] = useState<Tier>("builder");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const u = auth.currentUser;
    if (!u) { setTier("builder"); setLoading(false); return; }
    const ref = doc(db, "users", u.uid);
    const unsub = onSnapshot(ref, (snap) => {
      const data: any = snap.exists() ? snap.data() : {};
      const t = String(data?.tier || data?.plan || "builder").toLowerCase();
      setTier((t === "enterprise" || t === "pro" || t === "builder") ? (t as Tier) : "builder");
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, []);

  return { tier, loading };
}

export function TierGate(props: { min: Tier; tier: Tier; children: any; fallback?: any }) {
  return tierRank(props.tier) >= tierRank(props.min) ? props.children : (props.fallback ?? null);
}
