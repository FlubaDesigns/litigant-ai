export type OrgSize = "solo" | "small" | "mid" | "enterprise" | "government";

export type GovernanceTier = "SMB" | "MID_MARKET" | "REGULATED";

// 0 = advisory only … 4 = emergency intervention (logged + immediate notify)
export type AutonomyLevel = 0 | 1 | 2 | 3 | 4;

export type LoggingDepth = "basic" | "extended" | "immutable";
export type PatchMode = "proposal_only" | "approval_required" | "restricted_auto_minor";
export type EscalationSLA = "48h" | "24h" | "4h" | "1h";

export type GovernanceProfile = {
  tier: GovernanceTier;
  orgSize: OrgSize;
  autonomyLevel: AutonomyLevel;
  loggingDepth: LoggingDepth;
  patchMode: PatchMode;
  escalationSla: EscalationSLA;
  reasons: string[];
};

export type GovernanceInputs = {
  entry: "audit" | "build";
  userRole: "owner" | "ops" | "tech";
  orgSize: OrgSize;
  classification: "governance_audit" | "stack_build" | "hybrid";
  aiMaturity: "new" | "some" | "advanced";
  riskAppetite: "low" | "medium" | "high";
  automationAppetite: "low" | "medium" | "high";
};

function uniq(xs: string[]) {
  return Array.from(new Set(xs)).filter(Boolean);
}

/**
 * Website-layer profile builder.
 *
 * Goal:
 * - produce an explicit, enforceable profile object that can be passed to runtime
 * - keep it explainable (reasons)
 * - bias toward safety when signals conflict
 */
export function buildGovernanceProfile(i: GovernanceInputs): GovernanceProfile {
  const reasons: string[] = [];

  const regulatedSignal =
    i.orgSize === "government" ||
    i.orgSize === "enterprise" ||
    i.riskAppetite === "low";

  const midSignal = i.orgSize === "mid";

  // Tier
  const tier: GovernanceTier = regulatedSignal
    ? "REGULATED"
    : midSignal
    ? "MID_MARKET"
    : "SMB";

  if (tier === "REGULATED") {
    if (i.orgSize === "government") reasons.push("Government / public-sector scale selected.");
    if (i.orgSize === "enterprise") reasons.push("Enterprise scale selected.");
    if (i.riskAppetite === "low") reasons.push("Low risk appetite implies tighter approvals + stronger logs.");
  }
  if (tier === "MID_MARKET") reasons.push("Mid-market scale selected.");
  if (tier === "SMB") reasons.push("Small business scale selected.");

  // Autonomy ceiling (bias safety)
  let autonomyLevel: AutonomyLevel = 1;
  if (tier === "REGULATED") autonomyLevel = 1;
  else if (i.riskAppetite === "low") autonomyLevel = 1;
  else if (i.riskAppetite === "medium") autonomyLevel = 2;
  else autonomyLevel = 3;

  // Tech maturity can raise the ceiling, but never in regulated mode
  if (tier !== "REGULATED" && i.aiMaturity === "advanced" && i.riskAppetite !== "low") {
    autonomyLevel = Math.min(3, autonomyLevel + 1) as AutonomyLevel;
    reasons.push("Advanced AI maturity allows higher autonomy ceiling (still bounded).");
  }

  // Logging
  const loggingDepth: LoggingDepth =
    tier === "REGULATED" ? "immutable" : tier === "MID_MARKET" ? "extended" : "basic";
  if (loggingDepth === "immutable") reasons.push("Immutable logs required for regulated posture.");
  if (loggingDepth === "extended") reasons.push("Extended logs recommended for operational oversight.");

  // Patch mode
  const patchMode: PatchMode =
    tier === "REGULATED"
      ? "approval_required"
      : i.riskAppetite === "high" && i.automationAppetite === "high"
      ? "restricted_auto_minor"
      : "proposal_only";

  if (patchMode === "approval_required") reasons.push("Regulated posture requires approval for patches.");
  if (patchMode === "restricted_auto_minor") reasons.push("High automation appetite enables restricted auto-minor patches.");
  if (patchMode === "proposal_only") reasons.push("Patch proposals only (approval required before changes).");

  // Escalation SLA (contact you only when needed)
  const escalationSla: EscalationSLA =
    tier === "REGULATED" ? "1h" : tier === "MID_MARKET" ? "4h" : "24h";

  if (i.classification === "governance_audit") reasons.push("Governance-first classification detected.");
  if (i.classification === "stack_build") reasons.push("Automation build classification detected.");
  if (i.classification === "hybrid") reasons.push("Hybrid classification detected (governance + automation).");

  return {
    tier,
    orgSize: i.orgSize,
    autonomyLevel,
    loggingDepth,
    patchMode,
    escalationSla,
    reasons: uniq(reasons),
  };
}

export function parseGovernanceProfile(raw: string | null): GovernanceProfile | null {
  if (!raw) return null;
  try {
    const obj = JSON.parse(raw);
    if (!obj?.tier) return null;
    return obj as GovernanceProfile;
  } catch {
    return null;
  }
}
