export type IntakeClassification = "governance_audit" | "stack_build" | "hybrid";

export const INTAKE_GUARDRAILS = {
  // Hard rules
  forbidCredentials: true,
  forbidSecrets: true,
  forbidApiKeys: true,
  forbidCredentialUploads: true,

  // Scope rules
  forbidScopeExpansion: true,
  forbidMissionDrift: true,
  forbidPolicyMutation: true,

  // Interaction limits
  maxFollowupQuestions: 10,
  terminateWhenSufficientEvidence: true,
} as const;

const SECRET_PATTERNS: RegExp[] = [
  /api[-_ ]?key/i,
  /secret/i,
  /password/i,
  /token/i,
  /access[-_ ]?key/i,
  /private[-_ ]?key/i,
  /ssh[-_ ]?key/i,
  /credential/i,
];

export function violatesIntakeGuardrails(text: string): string | null {
  const t = String(text || "").trim();
  if (!t) return null;
  for (const rx of SECRET_PATTERNS) {
    if (rx.test(t)) {
      return "Guardrails: Do not provide secrets, credentials, API keys, tokens, passwords, or private keys. Use redacted examples or file references only.";
    }
  }
  return null;
}

export function classifyIntake(input: {
  problemDomain: string;
  aiMaturity: "new" | "some" | "advanced";
  riskAppetite: "low" | "medium" | "high";
  automationAppetite: "low" | "medium" | "high";
}): IntakeClassification {
  // Simple deterministic logic (website-layer only).
  const domain = (input.problemDomain || "").toLowerCase();

  const governanceHeavy =
    /compliance|legal|hr|finance|health|hipaa|pci|sox|gdpr|privacy|security|policy|risk/.test(domain) ||
    input.riskAppetite === "low";

  const buildHeavy =
    /build|deploy|pipeline|ci|cd|integrat|agent|automation|workflow|tooling|stack/.test(domain) ||
    input.automationAppetite === "high" ||
    input.aiMaturity === "advanced";

  if (governanceHeavy && buildHeavy) return "hybrid";
  if (governanceHeavy) return "governance_audit";
  if (buildHeavy) return "stack_build";
  return "hybrid";
}
