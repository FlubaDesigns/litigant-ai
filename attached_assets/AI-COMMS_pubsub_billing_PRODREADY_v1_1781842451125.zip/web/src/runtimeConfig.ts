import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase";

export type RuntimeConfig = {
  functionsRegion?: string;
  publicBaseUrl?: string;
  appCheckSiteKey?: string; // public key only
  featureFlags?: Record<string, any>;
};

const CACHE_KEY = "aicomms_site_runtime_config_cache_v1";

let inMemory: RuntimeConfig | null = null;

export async function loadRuntimeConfig(appId: "pollsit" | "aicomms_site" = "aicomms_site") {
  if (inMemory) return inMemory;

  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (cached) inMemory = JSON.parse(cached);
  } catch {}

  try {
    const snap = await getDoc(doc(db, "runtime_config", appId));
    if (snap.exists()) {
      const cfg = (snap.data() || {}) as RuntimeConfig;
      inMemory = cfg;
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify(cfg));
      } catch {}
      return cfg;
    }
  } catch {}

  return inMemory || {};
}

export function getRuntimeConfigCached(): RuntimeConfig {
  return inMemory || {};
}