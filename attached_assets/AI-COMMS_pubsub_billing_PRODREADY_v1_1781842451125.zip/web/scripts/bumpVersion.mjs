import fs from "node:fs";
import path from "node:path";

const here = path.dirname(new URL(import.meta.url).pathname);
const webRoot = path.resolve(here, "..");
const pkgPath = path.join(webRoot, "package.json");

const mode = (process.argv[2] || "patch").toLowerCase();

function parse(v) {
  const [a, b, c] = String(v).split(".").map((x) => Number(x));
  if ([a, b, c].some((n) => Number.isNaN(n))) throw new Error("Invalid version: " + v);
  return { a, b, c };
}

function format({ a, b, c }) {
  return `${a}.${b}.${c}`;
}

const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
const cur = parse(pkg.version || "0.0.0");

let next = { ...cur };
if (mode === "major") next = { a: cur.a + 1, b: 0, c: 0 };
else if (mode === "minor") next = { a: cur.a, b: cur.b + 1, c: 0 };
else next = { a: cur.a, b: cur.b, c: cur.c + 1 };

pkg.version = format(next);
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf8");

console.log(`[bumpVersion] ${cur.a}.${cur.b}.${cur.c} -> ${pkg.version}`);
console.log("[bumpVersion] Next: run `npm run build` to regenerate src/version.json");