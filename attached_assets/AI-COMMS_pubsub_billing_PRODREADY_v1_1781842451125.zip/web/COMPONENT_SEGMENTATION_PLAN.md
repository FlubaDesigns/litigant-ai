
# Frontend Component Segmentation Plan (Non-breaking)

Current: web/src/components/*

Future Suggested Structure:

components/
  admin/
  governance/
  dashboard/
  shared/
  analytics/

No files moved in v6.
This is structural planning only.
