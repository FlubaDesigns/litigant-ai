
// runtimeCanonValidator.ts
// Binds declared CANON_VERSION to runtime validation.
// Non-breaking. Logs warning if missing.

export function validateCanonVersion(packetHeader: any) {
  if (!packetHeader?.CANON_VERSION) {
    console.warn("CANON_VERSION missing. Defaulting to v1.");
    return "v1";
  }
  return packetHeader.CANON_VERSION;
}
