#!/usr/bin/env node
/**
 * Post-restore reconciliation (staging-safe).
 * This script DOES NOT modify billing state by default.
 * It is intended to:
 *  - sanity-check critical collections
 *  - print next actions (manual triggers)
 *
 * Usage:
 *   node scripts/post-restore-reconcile.mjs --project <PROJECT_ID>
 */
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

function getArg(name) {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

const projectId = getArg("--project");
if (!projectId) {
  console.error("Missing --project <PROJECT_ID>");
  process.exit(1);
}

initializeApp({ credential: applicationDefault(), projectId });
const db = getFirestore();

const critical = [
  "users",
  "orgs",
  "projects",
  "project_intake_packets",
  "approvals",
  "email_outbox",
  "ops_signals"
];

console.log("Post-restore sanity check for project:", projectId);
console.log("----");

for (const col of critical) {
  try {
    const snap = await db.collection(col).limit(5).get();
    console.log(`${col}: OK (sampleSize=${snap.size})`);
  } catch (e) {
    console.log(`${col}: FAIL`, e?.message || e);
  }
}

console.log("----");
console.log("Next actions (manual, best-effort):");
console.log("1) Verify admin access + claims for your admin user.");
console.log("2) Let scheduled safety nets run OR manually trigger in Cloud Console:");
console.log("   - reconcileStripeSubscriptions (daily)");
console.log("   - sweepGraceDowngrades (daily)");
console.log("   - systemAlerts (scheduled)");
console.log("3) If you need immediate rollups, re-run any metrics/rollup tasks (if present).");
console.log("");
console.log("Done.");
