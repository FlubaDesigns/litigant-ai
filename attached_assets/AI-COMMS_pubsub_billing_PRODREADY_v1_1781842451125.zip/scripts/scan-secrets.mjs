#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

const IGNORE_DIRS = new Set([
  "node_modules",
  ".git",
  "dist",
  "build",
  ".firebase",
  ".vite",
]);

const patterns = [
  { name: "Stripe live key", re: /sk_live_[0-9a-zA-Z]{10,}/g },
  { name: "Stripe test key", re: /sk_test_[0-9a-zA-Z]{10,}/g },
  { name: "Stripe webhook secret", re: /whsec_[0-9a-zA-Z]{10,}/g },
  { name: "GCP API key", re: /AIza[0-9A-Za-z\-_]{20,}/g },
  { name: "Private key block", re: /-----BEGIN PRIVATE KEY-----/g },
];

function* walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (IGNORE_DIRS.has(e.name)) continue;
      yield* walk(p);
    } else if (e.isFile()) {
      yield p;
    }
  }
}

let found = [];
for (const file of walk(root)) {
  // skip big files
  let stat;
  try { stat = fs.statSync(file); } catch { continue; }
  if (stat.size > 2_000_000) continue;

  let txt;
  try { txt = fs.readFileSync(file, "utf8"); } catch { continue; }

  for (const p of patterns) {
    const m = txt.match(p.re);
    if (m && m.length) {
      found.push({ file: path.relative(root, file), pattern: p.name, count: m.length });
    }
  }
}

if (found.length) {
  console.error("❌ Potential secrets detected:");
  for (const f of found) console.error(`- ${f.pattern} in ${f.file} (x${f.count})`);
  process.exit(2);
}

console.log("✅ Secret scan passed (no common secret patterns detected).");
