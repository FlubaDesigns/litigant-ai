import fs from "node:fs";
import path from "node:path";

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}
function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

const appRoot = process.cwd();
const cfgPath = path.join(appRoot, "governance", "governance.config.json");
if (!exists(cfgPath)) {
  console.error(`[verify-canon] Missing config: ${cfgPath}`);
  process.exit(2);
}
const cfg = readJson(cfgPath);

const repoRoot = path.resolve(appRoot, cfg.repo_root_from_app_root || ".");
const canonIndexPath = path.resolve(appRoot, cfg.paths?.canon_index || "../..//CANON_INDEX.md");
const canonDirPath = path.resolve(appRoot, cfg.paths?.canon_dir || "../..//CANON");

if (!exists(canonIndexPath)) {
  console.error(`[verify-canon] Missing CANON_INDEX: ${path.relative(repoRoot, canonIndexPath)}`);
  process.exit(1);
}
if (!exists(canonDirPath)) {
  console.error(`[verify-canon] Missing CANON dir: ${path.relative(repoRoot, canonDirPath)}`);
  process.exit(1);
}

const lines = fs.readFileSync(canonIndexPath, "utf8").split(/\r?\n/);
const refs = lines
  .map(l => l.trim())
  .filter(l => l.startsWith("CANON/") && (l.endsWith(".md") || l.endsWith(".txt") || l.endsWith(".docx") || l.includes(".md")));

const missing = [];
for (const r of refs) {
  const p = path.resolve(repoRoot, r);
  if (!exists(p)) missing.push(r);
}

if (missing.length) {
  console.error(`[verify-canon] Missing canon files referenced by CANON_INDEX: ${missing.length}`);
  for (const m of missing) console.error(`- ${m}`);
  process.exit(1);
}

console.log(`[verify-canon] OK — CANON_INDEX references exist (${refs.length} entries).`);