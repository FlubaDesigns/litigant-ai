#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${1:-}"
EXPORT_PATH="${2:-}"

if [[ -z "$PROJECT_ID" || -z "$EXPORT_PATH" ]]; then
  echo "Usage: bash scripts/firestore-import.sh <PROJECT_ID> <EXPORT_PATH>"
  echo "Example: bash scripts/firestore-import.sh my-staging gs://my-bucket/aicomms-firestore-exports/2026-03-02T18:00:00Z"
  exit 1
fi

echo "IMPORT WARNING: This will overwrite data in the target project."
echo "Target project: ${PROJECT_ID}"
echo "Import source: ${EXPORT_PATH}"
echo ""
echo "If you are NOT restoring STAGING, abort now."
echo "Continuing in 10 seconds..."
sleep 10

gcloud config set project "${PROJECT_ID}" >/dev/null
gcloud firestore import "${EXPORT_PATH}"

echo "Import complete."
