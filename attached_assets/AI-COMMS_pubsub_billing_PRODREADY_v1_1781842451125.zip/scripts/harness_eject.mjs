import fs from "node:fs";
import path from "node:path";

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}
function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}
function nowStamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth()+1)}${pad(d.getUTCDate())}_${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}`;
}

const args = new Set(process.argv.slice(2));
const dryRun = args.has("--dry-run") || (!args.has("--yes"));
const doBackup = args.has("--backup");
const forceYes = args.has("--yes");

const appRoot = process.cwd();
const manifestPath = path.join(appRoot, "governance", "harness_manifest.json");

if (!exists(manifestPath)) {
  console.error(`[harness-eject] Missing manifest: ${manifestPath}`);
  process.exit(2);
}

// guardrails: refuse to run if web/functions missing (prevents running in wrong folder)
const required = [path.join(appRoot, "web", "package.json"), path.join(appRoot, "functions", "package.json")];
for (const r of required) {
  if (!exists(r)) {
    console.error(`[harness-eject] Refusing to run. Missing expected signature file: ${r}`);
    process.exit(2);
  }
}

const mf = readJson(manifestPath);
const owned = (mf.harness_owned_paths || []).map(p => path.resolve(appRoot, p));
const never = new Set((mf.never_delete_paths || []).map(p => path.resolve(appRoot, p)));

const stamp = nowStamp();
const backupRoot = path.join(appRoot, ".harness_eject_backup", stamp);
const receiptPath = path.join(appRoot, "governance", `harness_eject_receipt_${stamp}.json`);

function isUnderAppRoot(p) {
  const rel = path.relative(appRoot, p);
  return rel && !rel.startsWith("..") && !path.isAbsolute(rel);
}

function copyRecursive(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      copyRecursive(path.join(src, name), path.join(dst, name));
    }
  } else {
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(src, dst);
  }
}

function rmRecursive(p) {
  if (!exists(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}

const actions = [];

for (const p of owned) {
  if (!isUnderAppRoot(p)) {
    actions.push({ path: p, action: "skip", reason: "outside_app_root" });
    continue;
  }
  if (never.has(p)) {
    actions.push({ path: p, action: "skip", reason: "in_never_delete_paths" });
    continue;
  }
  if (p === path.join(appRoot, "web") || p === path.join(appRoot, "functions")) {
    actions.push({ path: p, action: "skip", reason: "protected_core_folder" });
    continue;
  }
  actions.push({ path: p, action: "remove" });
}

const plan = {
  appRoot,
  dryRun,
  backup: doBackup,
  timestamp_utc: new Date().toISOString(),
  actions: actions.map(a => ({
    path: path.relative(appRoot, a.path),
    action: a.action,
    reason: a.reason || null
  }))
};

fs.mkdirSync(path.dirname(receiptPath), { recursive: true });
fs.writeFileSync(receiptPath, JSON.stringify(plan, null, 2) + "\n", "utf8");

console.log(`[harness-eject] Receipt: ${receiptPath}`);
console.log(`[harness-eject] Mode: ${dryRun ? "DRY-RUN" : "EXECUTE"}${doBackup ? " (with backup)" : ""}`);

if (dryRun && !forceYes) {
  console.log("[harness-eject] Dry-run complete. Re-run with --yes to execute, optionally --backup.");
  process.exit(0);
}

if (!dryRun && doBackup) {
  fs.mkdirSync(backupRoot, { recursive: true });
  for (const a of actions) {
    if (a.action !== "remove") continue;
    if (!exists(a.path)) continue;
    const dst = path.join(backupRoot, path.relative(appRoot, a.path));
    copyRecursive(a.path, dst);
  }
  console.log(`[harness-eject] Backup written: ${backupRoot}`);
}

for (const a of actions) {
  if (a.action !== "remove") continue;
  rmRecursive(a.path);
}

console.log("[harness-eject] Done. Harness layer removed. web/ and functions/ remain intact.");