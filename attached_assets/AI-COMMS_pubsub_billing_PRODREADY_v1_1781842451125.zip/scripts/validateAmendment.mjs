// validateAmendment.mjs
// Validates amendment proposal structure (CLI-friendly)
import fs from "fs";

const requiredFields = [
  "STATUS: CANON AMENDMENT PROPOSAL",
  "TARGET_CANON:",
  "CURRENT_VERSION:",
  "PROPOSED_VERSION:",
  "AMENDMENT_TYPE:",
  "RATIONALE:",
  "EVIDENCE:",
  "ROLLBACK_PLAN:",
  "OPERATOR_DECISION:",
];

export function validateAmendment(filePath) {
  const content = fs.readFileSync(filePath, "utf-8");
  return requiredFields.every((field) => content.includes(field));
}

// CLI usage: node scripts/validateAmendment.mjs LOGS/amendment_proposal_x.md
if (process.argv[2]) {
  const ok = validateAmendment(process.argv[2]);
  if (!ok) {
    console.error("AMENDMENT VALIDATION FAIL:", process.argv[2]);
    process.exit(1);
  } else {
    console.log("AMENDMENT VALIDATION PASS:", process.argv[2]);
  }
}
