import fs from "node:fs";
import path from "node:path";

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}
function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

const appRoot = process.cwd();
const cfgPath = path.join(appRoot, "governance", "governance.config.json");
if (!exists(cfgPath)) {
  console.error(`[verify-firestore] Missing config: ${cfgPath}`);
  process.exit(2);
}
const cfg = readJson(cfgPath);

const rulesPath = path.resolve(appRoot, cfg.paths?.firestore_rules || "./firestore.rules");
if (!exists(rulesPath)) {
  console.error(`[verify-firestore] Missing rules file: ${rulesPath}`);
  process.exit(1);
}

const txt = fs.readFileSync(rulesPath, "utf8");

// brace balance (rough but catches truncation)
let bal = 0;
for (const ch of txt) {
  if (ch === "{") bal++;
  if (ch === "}") bal--;
  if (bal < 0) break;
}
if (bal !== 0) {
  console.error(`[verify-firestore] Brace imbalance detected (likely truncated). Balance=${bal}`);
  process.exit(1);
}

// default deny check (recommended posture)
const hasDefaultDeny =
  txt.includes("match /{document=**}") &&
  (txt.includes("allow read, write: if false") || txt.includes("allow read, write: if false;"));

if (!hasDefaultDeny) {
  console.warn("[verify-firestore] WARNING: default deny block not detected. This may be intentional, but is uncommon for production.");
}

console.log("[verify-firestore] OK — rules file present and structurally sane.");