
// ci-verify.mjs
// Master structural verification runner

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';


try {
  execSync('node scripts/verify-canon.mjs', { stdio: 'inherit' });
  execSync('node scripts/verify-firestore.mjs', { stdio: 'inherit' });
  execSync('node scripts/verify-links.mjs', { stdio: 'inherit' });
  // Amendment proposal validation (if LOGS exists)
  const logsDir = path.join(process.cwd(), 'LOGS');
  if (fs.existsSync(logsDir)) {
    const files = fs.readdirSync(logsDir).filter(f => f.startsWith('amendment_proposal_') && f.endsWith('.md'));
    for (const f of files) {
      execSync(`node scripts/validateAmendment.mjs ${path.join('LOGS', f)}`, { stdio: 'inherit' });
    }
  }

  console.log("CI STRUCTURAL VERIFY: PASS");
} catch (err) {
  console.error("CI STRUCTURAL VERIFY: FAIL");
  process.exit(1);
}
