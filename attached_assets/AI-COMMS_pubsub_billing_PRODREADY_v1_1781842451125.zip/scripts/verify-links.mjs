import fs from "node:fs";
import path from "node:path";

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}
function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

const appRoot = process.cwd();
const configPath = path.join(appRoot, "governance", "governance.config.json");
if (!exists(configPath)) {
  console.error(`[verify-links] Missing config: ${configPath}`);
  process.exit(2);
}
const cfg = readJson(configPath);

const repoRoot = path.resolve(appRoot, cfg.repo_root_from_app_root || ".");
const roots = (cfg.verify?.scan_markdown_roots || []).map(r => path.resolve(appRoot, r));

const mdFiles = [];
function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules" || e.name === ".git" || e.name === "dist" || e.name === "lib") continue;
      walk(p);
    } else if (e.isFile()) {
      if (/\.(md|txt)$/i.test(e.name)) mdFiles.push(p);
    }
  }
}

for (const r of roots) {
  if (exists(r)) walk(r);
}

const linkRe = /\[[^\]]+\]\(([^)]+)\)/g;
const broken = [];

for (const f of mdFiles) {
  const txt = fs.readFileSync(f, "utf8");
  let m;
  while ((m = linkRe.exec(txt)) !== null) {
    const raw = m[1].trim();

    // ignore web/absolute urls and mailto
    if (/^(https?:)?\/\//i.test(raw) || raw.startsWith("mailto:")) continue;

    // strip anchors
    const target = raw.split("#")[0].trim();
    if (!target) continue;

    // if it starts with / treat as repo-root relative (common in docs)
    const resolved = target.startsWith("/")
      ? path.resolve(repoRoot, "." + target)
      : path.resolve(path.dirname(f), target);

    if (!exists(resolved)) {
      broken.push({
        file: path.relative(repoRoot, f),
        link: raw,
        resolved: path.relative(repoRoot, resolved)
      });
    }
  }
}

if (broken.length) {
  console.error(`[verify-links] Broken markdown links: ${broken.length}`);
  for (const b of broken) {
    console.error(`- ${b.file} -> (${b.link}) missing: ${b.resolved}`);
  }
  process.exit(1);
}

console.log(`[verify-links] OK — scanned ${mdFiles.length} docs, no broken markdown links found.`);