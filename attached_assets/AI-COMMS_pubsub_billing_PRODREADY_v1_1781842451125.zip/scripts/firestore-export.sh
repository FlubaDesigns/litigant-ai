#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${1:-}"
BUCKET_PREFIX="${2:-}"

if [[ -z "$PROJECT_ID" || -z "$BUCKET_PREFIX" ]]; then
  echo "Usage: bash scripts/firestore-export.sh <PROJECT_ID> <GCS_BUCKET_PREFIX>"
  echo "Example: bash scripts/firestore-export.sh my-staging gs://my-bucket/aicomms-firestore-exports"
  exit 1
fi

TS="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
OUTPUT="${BUCKET_PREFIX%/}/${TS}"

echo "Exporting Firestore for project: ${PROJECT_ID}"
echo "Destination: ${OUTPUT}"

# Requires gcloud SDK
gcloud config set project "${PROJECT_ID}" >/dev/null
gcloud firestore export "${OUTPUT}"

echo "Export complete: ${OUTPUT}"
