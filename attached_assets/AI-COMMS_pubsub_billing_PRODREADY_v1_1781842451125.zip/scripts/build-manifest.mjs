import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}
function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}
function sha256File(filePath) {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

const appRoot = process.cwd();
const cfgPath = path.join(appRoot, "governance", "governance.config.json");
if (!exists(cfgPath)) {
  console.error(`[build-manifest] Missing config: ${cfgPath}`);
  process.exit(2);
}
const cfg = readJson(cfgPath);

const manifestOut = path.resolve(appRoot, cfg.paths?.build_manifest_out || "./governance/build_manifest.json");
const toolboxPath = path.resolve(appRoot, cfg.paths?.toolbox_manifest || "./governance/toolbox.manifest.json");
const rulesPath = path.resolve(appRoot, cfg.paths?.firestore_rules || "./firestore.rules");
const canonIndexPath = path.resolve(appRoot, cfg.paths?.canon_index || "../..//CANON_INDEX.md");

const buildManifest = {
  site: cfg.site_name || "unknown-site",
  generated_utc: new Date().toISOString(),
  hashes: {
    toolbox_manifest: exists(toolboxPath) ? sha256File(toolboxPath) : null,
    firestore_rules: exists(rulesPath) ? sha256File(rulesPath) : null,
    canon_index: exists(canonIndexPath) ? sha256File(canonIndexPath) : null
  }
};

fs.mkdirSync(path.dirname(manifestOut), { recursive: true });
fs.writeFileSync(manifestOut, JSON.stringify(buildManifest, null, 2) + "\n", "utf8");
console.log(`[build-manifest] Wrote: ${manifestOut}`);

const webCopy = cfg.paths?.web_build_manifest_copy ? path.resolve(appRoot, cfg.paths.web_build_manifest_copy) : null;
if (webCopy) {
  try {
    fs.mkdirSync(path.dirname(webCopy), { recursive: true });
    fs.writeFileSync(webCopy, JSON.stringify(buildManifest, null, 2) + "\n", "utf8");
    console.log(`[build-manifest] Copied to web: ${webCopy}`);
  } catch (e) {
    console.warn(`[build-manifest] Could not copy to web path: ${webCopy}`);
  }
}