import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";
import {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} from "@firebase/rules-unit-testing";

const PROJECT_ID = "demo-aicomms-tests";

let testEnv;

beforeAll(async () => {
  const rules = readFileSync(path.resolve("./firestore.rules"), "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules },
  });
});

afterAll(async () => {
  await testEnv.cleanup();
});

describe("Firestore Rules - core access controls", () => {
  it("unauthenticated can read public pricing_version but cannot write it", async () => {
    const anonDb = testEnv.unauthenticatedContext().firestore();

    // Seed pricing_version doc via admin context (bypass rules)
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const adminDb = ctx.firestore();
      await adminDb.collection("pricing_version").doc("active").set({ version: 1 });
    });

    await assertSucceeds(anonDb.collection("pricing_version").doc("active").get());
    await assertFails(anonDb.collection("pricing_version").doc("active").set({ version: 2 }));
  });

  it("signed-in user can read their own user profile doc", async () => {
    const uid = "user_1";
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection("users").doc(uid).set({ orgId: "org_1", lastActiveAt: new Date() });
    });

    const userDb = testEnv.authenticatedContext(uid).firestore();
    await assertSucceeds(userDb.collection("users").doc(uid).get());

    const otherDb = testEnv.authenticatedContext("user_2").firestore();
    await assertFails(otherDb.collection("users").doc(uid).get());
  });

  it("user can only update lastActiveAt on their own doc (no other fields)", async () => {
    const uid = "user_3";
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection("users").doc(uid).set({ orgId: "org_3", lastActiveAt: new Date() });
    });

    const userDb = testEnv.authenticatedContext(uid).firestore();

    // Allowed: update lastActiveAt to timestamp
    await assertSucceeds(
      userDb.collection("users").doc(uid).update({ lastActiveAt: new Date() })
    );

    // Denied: change orgId
    await assertFails(
      userDb.collection("users").doc(uid).update({ orgId: "org_hijack" })
    );
  });

  it("non-admin cannot read runtime_config", async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      await ctx.firestore().collection("runtime_config").doc("web").set({ safe: true });
    });

    const userDb = testEnv.authenticatedContext("user_4").firestore();
    await assertFails(userDb.collection("runtime_config").doc("web").get());

    const anonDb = testEnv.unauthenticatedContext().firestore();
    await assertFails(anonDb.collection("runtime_config").doc("web").get());
  });

  it("admin can read runtime_config (admins/{uid} exists)", async () => {
    const adminUid = "admin_1";

    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      await db.collection("admins").doc(adminUid).set({ createdAt: new Date() });
      await db.collection("runtime_config").doc("web").set({ safe: true });
    });

    const adminDb = testEnv.authenticatedContext(adminUid).firestore();
    await assertSucceeds(adminDb.collection("runtime_config").doc("web").get());
  });
});
