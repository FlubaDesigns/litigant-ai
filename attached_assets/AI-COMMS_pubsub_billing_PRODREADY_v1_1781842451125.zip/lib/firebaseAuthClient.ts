// FILE: AICOMMS/APPS/aicomms-site/lib/firebaseAuthClient.ts
import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";

/**
 * v17 FIX:
 * - Works in Vite (import.meta.env.VITE_*)
 * - Works in Next-style env (process.env.NEXT_PUBLIC_*)
 */
function readClientEnv(viteKey: string, nextKey: string): string {
  const metaEnv = (import.meta as any)?.env ?? {};
  const procEnv = (globalThis as any)?.process?.env ?? {};

  const val =
    metaEnv[viteKey] ??
    procEnv[viteKey] ??
    procEnv[nextKey] ??
    metaEnv[nextKey];

  if (!val) {
    throw new Error(
      `Missing Firebase client env: expected ${viteKey} (Vite) or ${nextKey} (Next).`
    );
  }
  return String(val);
}

const firebaseConfig = {
  apiKey: readClientEnv("VITE_FIREBASE_API_KEY", "NEXT_PUBLIC_FIREBASE_API_KEY"),
  authDomain: readClientEnv(
    "VITE_FIREBASE_AUTH_DOMAIN",
    "NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN"
  ),
  projectId: readClientEnv(
    "VITE_FIREBASE_PROJECT_ID",
    "NEXT_PUBLIC_FIREBASE_PROJECT_ID"
  ),
  storageBucket: readClientEnv(
    "VITE_FIREBASE_STORAGE_BUCKET",
    "NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET"
  ),
  messagingSenderId: readClientEnv(
    "VITE_FIREBASE_MESSAGING_SENDER_ID",
    "NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID"
  ),
  appId: readClientEnv("VITE_FIREBASE_APP_ID", "NEXT_PUBLIC_FIREBASE_APP_ID"),
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

export const auth = getAuth(app);