AI-COMMS (Extracted App)
Generated: 2026-02-26T07:44:57

Contents:
- This zip contains ONLY the marketable AI-COMMS app folder extracted from the original AICOMMS bundle.
- Root is AI-COMMS/ with the original app contents (firebase.json, web/, functions/, etc).

Next steps (you said you'll do the rest):
1) Unzip.
2) Treat AI-COMMS/ as its own repository root (or move contents up one level if you prefer).
3) Later, point this app to consume the AI-Guardrails repo as a dependency.

