import type { CourtConfig } from "@/data/templates";

const API_BASE = (import.meta.env.VITE_API_URL as string | undefined) ?? "/api-server/api";

function getApiUrl(path: string): string {
  return `${API_BASE}${path}`;
}

export type PauseReason = "credit_cap" | "iteration_limit";

export interface RebuttalContext {
  challenge: string;
  originalVerdict: string;
  rebuttalRound: number;
  parentSessionId?: string;
}

export interface CaseFileItem {
  id: string;
  type: "url" | "file";
  name: string;
  content: string;
  url?: string;
}

export interface BrainRunRequest {
  question: string;
  config: CourtConfig;
  templateId?: string;
  sessionId?: string;
  idToken?: string;
  /** Raw transcript lines from a paused session — resumes debate from this point. */
  continueFromTranscript?: string[];
  /** Present when the user challenges a verdict — triggers a rebuttal run. */
  rebuttalContext?: RebuttalContext;
  /** Pre-briefing documents or URLs entered before the session run. */
  caseFile?: CaseFileItem[];
  /**
   * Skip debate entirely and run only the fixed pipeline (Mod→Arch→Builder→Aud→Verdict).
   * Used when resuming a session that was paused before the pipeline due to hitting the
   * credit cap during debate. Must be combined with `continueFromTranscript`.
   */
  resumeWithFixedPipeline?: boolean;
  /** User confirmed continuation on credit (overdraft). */
  overdraft?: boolean;
  /**
   * When a previous turn's provider failed over, the client sends back the
   * backup provider name so the new run is pinned to it from the start.
   */
  failoverProvider?: string;
  /**
   * Relay context — user is supplying the missing information flagged by the
   * Auditor's NOT_ENOUGH decision. Moderator receives the original transcript
   * plus the new info and decides SUBSTANTIVE: yes/no.
   */
  relayContext?: RelayContext;
}

export interface CourtroomOutcome {
  reason:
    | "approved"
    | "not_enough"
    | "convergence_failure"
    | "credit_cap"
    | "iteration_limit"
    | "aborted";
  confidenceAtExit: number;
  round: number;
}

export interface RelayContext {
  missingInfo: string;
  relayRound: number;
  originalTranscript: string[];
  parentSessionId?: string;
}

export type SSEEventType =
  | "start"
  | "role_start"
  | "content"
  | "role_end"
  | "confidence_update"
  | "round_start"
  | "round_end"
  | "paused_post_moderator"
  | "courtroom_outcome"
  | "done"
  | "error"
  | "provider_failover";

export interface SSEEvent {
  type: SSEEventType;
  role?: string;
  roleIndex?: number;
  round?: number;
  content?: string;
  fullContent?: string;
  confidence?: number;
  creditsUsed?: number;
  sessionId?: string;
  estimatedCredits?: number;
  finalAnswer?: string;
  debateNotes?: string;
  transcript?: string;
  transcriptLines?: string[];
  caveats?: string;
  artifacts?: string;
  message?: string;
  guestLimitReached?: boolean;
  provider?: string;
  /** Present when the session hit a stopping condition before the confidence target. */
  pauseReason?: PauseReason;
  /**
   * For Builder and Auditor stages: 1 = initial pass, 2+ = revision/re-review.
   * Absent on all other roles.
   */
  attempt?: number;
  /**
   * Debate transcript lines sent with `paused_post_moderator` events so the frontend
   * can store them and pass back as `continueFromTranscript` on the resume call.
   */
  debateTranscriptLines?: string[];
  /** Which pipeline branch was taken — emitted on `courtroom_outcome` and `done`. */
  artifactPath?: "artifact" | "no-artifact";
  /** Structured termination metadata — emitted on `courtroom_outcome` and `done`. */
  courtroomOutcome?: CourtroomOutcome;
  /** Number of relay rounds completed — emitted on `done`. */
  relayCount?: number;
  /** When Auditor (no-artifact) returned NOT_ENOUGH — what the user must supply. */
  relayQuestion?: string;
  /** True when the session needs a user relay answer before it can complete. */
  needsRelay?: boolean;
  /** End-of-job tap — null until user taps; only present when relayCount >= 1. */
  endOfJobTap?: "worth_it" | "not_worth_it" | null;
  /** Whether convergence failed after 3 artifact cycles. */
  convergenceFailure?: boolean;
}

export function runBrainSession(
  request: BrainRunRequest,
  onEvent: (event: SSEEvent) => void,
  signal?: AbortSignal
): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (request.idToken) {
        headers["Authorization"] = `Bearer ${request.idToken}`;
      }

      const response = await fetch(getApiUrl("/run-brain"), {
        method: "POST",
        headers,
        body: JSON.stringify({
          question: request.question,
          config: request.config,
          templateId: request.templateId,
          sessionId: request.sessionId,
          continueFromTranscript: request.continueFromTranscript,
          rebuttalContext: request.rebuttalContext,
          relayContext: request.relayContext,
          parentSessionId: request.rebuttalContext?.parentSessionId ?? request.relayContext?.parentSessionId,
          caseFile: request.caseFile,
          resumeWithFixedPipeline: request.resumeWithFixedPipeline,
          failoverProvider: request.failoverProvider,
          overdraft: request.overdraft,
        }),
        signal,
      });

      if (!response.ok) {
        const err = await response.json().catch(() => ({ message: "Request failed" }));
        reject(new Error((err as any).message || `HTTP ${response.status}`));
        return;
      }

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const raw = line.slice(6).trim();
            if (!raw || raw === "[DONE]") continue;
            try {
              const event = JSON.parse(raw) as SSEEvent;
              onEvent(event);
              if (event.type === "done" || event.type === "error" || event.type === "paused_post_moderator") {
                resolve();
                return;
              }
            } catch {
              // skip malformed
            }
          }
        }
      }

      resolve();
    } catch (err) {
      if ((err as any)?.name === "AbortError") {
        resolve();
      } else {
        reject(err);
      }
    }
  });
}

export interface SavedSession {
  id: string;
  title: string;
  question: string;
  templateId: string | null;
  confidence: number;
  creditsUsed: number;
  inputTokens?: number;
  outputTokens?: number;
  costUSD?: number;
  model?: string;
  status: "complete" | "incomplete" | "error" | "paused_credit_cap" | "relay_needed";
  starred?: boolean;
  archived?: boolean;
  shared?: boolean;
  shareId?: string;
  createdAt: string;
  updatedAt: string;
  finalAnswer?: string;
  debateNotes?: string;
  transcript?: string;
  caveats?: string;
  artifacts?: string;
  /** Set when Auditor returned NOT_ENOUGH — the specific missing info the user must supply. */
  relayQuestion?: string | null;
  relayCount?: number;
  artifactPath?: "artifact" | "no-artifact" | null;
}

export interface SessionsPage {
  sessions: SavedSession[];
  hasMore: boolean;
  nextCursor: string | null;
}

export async function getSessions(
  idToken?: string,
  opts: { limit?: number; cursor?: string | null; starred?: boolean; archived?: boolean } = {}
): Promise<SessionsPage> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const params = new URLSearchParams();
  if (opts.limit) params.set("limit", String(opts.limit));
  if (opts.cursor) params.set("cursor", opts.cursor);
  if (opts.starred) params.set("starred", "true");
  if (opts.archived) params.set("archived", "true");
  const qs = params.toString() ? `?${params.toString()}` : "";
  const res = await fetch(getApiUrl(`/sessions${qs}`), { headers });
  if (!res.ok) throw new Error("Failed to fetch sessions");
  // Handle both new paginated format {sessions,hasMore,nextCursor} and legacy plain array
  const data = await res.json();
  if (Array.isArray(data)) {
    return { sessions: data, hasMore: false, nextCursor: null };
  }
  return data as SessionsPage;
}

export async function deleteAccount(idToken?: string): Promise<void> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(getApiUrl("/account"), { method: "DELETE", headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as any).message || `Delete account failed (${res.status})`);
  }
}

export async function getSession(id: string, idToken?: string): Promise<SavedSession> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(getApiUrl(`/sessions/${id}`), { headers });
  if (!res.ok) throw new Error("Session not found");
  return res.json();
}

export async function updateSession(
  id: string,
  data: { title?: string; starred?: boolean; archived?: boolean; shared?: boolean; shareId?: string },
  idToken?: string
): Promise<void> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(getApiUrl(`/sessions/${id}`), {
    method: "PATCH",
    headers,
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as any).message || `Update session failed (${res.status})`);
  }
}

export async function deleteSession(id: string, idToken?: string): Promise<void> {
  const headers: Record<string, string> = {};
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(getApiUrl(`/sessions/${id}`), { method: "DELETE", headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as any).message || `Delete session failed (${res.status})`);
  }
}

/** Fetch every session page by cursor until exhausted. Use for exports. */
export async function getAllSessions(idToken?: string): Promise<SavedSession[]> {
  const all: SavedSession[] = [];
  let cursor: string | null = null;
  do {
    const page = await getSessions(idToken, { limit: 100, cursor });
    all.push(...page.sessions);
    cursor = page.hasMore ? page.nextCursor : null;
  } while (cursor);
  return all;
}

export async function generateShareLink(id: string, idToken?: string): Promise<string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (idToken) headers["Authorization"] = `Bearer ${idToken}`;
  const res = await fetch(getApiUrl(`/sessions/${id}/share`), { method: "POST", headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err as any).message || `Share failed (${res.status})`);
  }
  const { shareId } = await res.json();
  return `${window.location.origin}/report/${shareId}`;
}

export function exportSessionAsMarkdown(session: SavedSession): string {
  const lines = [
    `# Litigant AI Session — ${session.title}`,
    ``,
    `**Question:** ${session.question}`,
    session.templateId ? `**Template:** ${session.templateId}` : null,
    `**Confidence:** ${session.confidence}%`,
    `**Credits Used:** ${session.creditsUsed}`,
    `**Date:** ${new Date(session.createdAt).toLocaleDateString()}`,
    `**Status:** ${session.status}`,
    ``,
    `---`,
    ``,
    `## Final Answer`,
    ``,
    session.finalAnswer || "_No final answer generated._",
    ``,
    session.artifacts
      ? [`---`, ``, `## Artifacts`, ``, session.artifacts, ``].join("\n")
      : null,
    `---`,
    ``,
    `## Debate Notes`,
    ``,
    session.debateNotes || "_No debate notes._",
    ``,
    `---`,
    ``,
    `## Sources & Caveats`,
    ``,
    session.caveats || "_No caveats._",
    ``,
    `---`,
    ``,
    `_Generated by Litigant AI — Don't just ask AI. Put the question on trial._`,
  ];
  return lines.filter((l) => l !== null).join("\n");
}
