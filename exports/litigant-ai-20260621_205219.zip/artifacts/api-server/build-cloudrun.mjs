import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import esbuildPluginPino from "esbuild-plugin-pino";

globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(artifactDir, "../../firebase-functions/lib");

const external = [
  "*.node","sharp","better-sqlite3","sqlite3","canvas","bcrypt","argon2",
  "fsevents","re2","farmhash","xxhash-addon","bufferutil","utf-8-validate",
  "ssh2","cpu-features","dtrace-provider","isolated-vm","lightningcss",
  "pg-native","oracledb","mongodb-client-encryption","nodemailer","handlebars",
  "knex","typeorm","protobufjs","onnxruntime-node","@tensorflow/*",
  "@prisma/client","@mikro-orm/*","@grpc/*","@swc/*","@aws-sdk/*","@azure/*",
  "@opentelemetry/*","@google-cloud/*","@google/*","googleapis",
  "firebase-admin","@parcel/watcher","@sentry/profiling-node","@tree-sitter/*",
  "aws-sdk","classic-level","dd-trace","ffi-napi","grpc","hiredis","kerberos",
  "leveldown","miniflare","mysql2","newrelic","odbc","piscina","realm",
  "ref-napi","rocksdb","sass-embedded","sequelize","serialport","snappy",
  "tinypool","usb","workerd","wrangler","zeromq","zeromq-prebuilt",
  "playwright","puppeteer","puppeteer-core","electron",
];

await esbuild({
  entryPoints: [path.resolve(artifactDir, "src/server-cloudrun.ts")],
  platform: "node",
  bundle: true,
  format: "esm",
  outdir: outDir,
  outExtension: { ".js": ".mjs" },
  logLevel: "info",
  external,
  sourcemap: false,
  plugins: [esbuildPluginPino({ transports: ["pino-pretty"] })],
  banner: {
    js: `import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';
globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
    `,
  },
});

// Rename server-cloudrun.mjs → server.mjs (Dockerfile expects server.mjs)
import { rename } from "node:fs/promises";
const src = path.join(outDir, "server-cloudrun.mjs");
const dst = path.join(outDir, "server.mjs");
await rename(src, dst);
console.log("✅ Cloud Run bundle written to firebase-functions/lib/server.mjs");
