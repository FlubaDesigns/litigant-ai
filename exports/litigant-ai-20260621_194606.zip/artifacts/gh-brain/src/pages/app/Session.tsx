import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Brain, Briefcase, Globe, TrendingUp, Code2, FileText, BookOpen,
  Stethoscope, Scale, Search, FlaskConical, Settings2, Play, Square,
  ThumbsUp, ThumbsDown, AlertTriangle, Copy, Download,
  Zap, Target, RotateCcw, CheckCircle2, Sparkles, MessageSquare, X,
  Printer, Package, ShoppingCart, Cpu, LayoutTemplate, Shuffle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useBrainSession, type FeedItem } from "@/hooks/useBrainSession";
import { TEMPLATES, TEMPLATE_CATEGORIES, type Template } from "@/data/templates";
import type { CourtConfig, ProviderName } from "@/data/templates";
import { submitFeedback } from "@/services/feedbackService";
import { saveUserConfig } from "@/services/firestoreService";
import { useAuth } from "@/contexts/AuthContext";
import { useUserProfile } from "@/hooks/useUserProfile";
import { useLocation } from "wouter";
import {
  getProviders, PROVIDER_LABELS, PROVIDER_ICONS, estimateCredits,
  type ProviderInfo, type ModelInfo, type ModelCreditInfo,
} from "@/services/providerService";
import { Input } from "@/components/ui/input";
import { CourtDiagram } from "@/components/CourtDiagram";
import { SeatInspector } from "@/components/SeatInspector";
import { makeDefaultSeatMap } from "@/data/seatTypes";
import type { SeatAssignment } from "@/data/seatTypes";

// ── Icon map ──────────────────────────────────────────────────────────────────
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Briefcase, Globe, TrendingUp, Code2, FileText, BookOpen,
  Stethoscope, Scale, Search, FlaskConical,
};

// ── Role colours ──────────────────────────────────────────────────────────────
const ROLE_COLORS: Record<string, string> = {
  Orchestrator: "text-yellow-400 border-yellow-400/30 bg-yellow-400/5",
  Verdict: "text-primary border-primary/30 bg-primary/5",
  Advocate: "text-blue-400 border-blue-400/30 bg-blue-400/5",
  Skeptic: "text-red-400 border-red-400/30 bg-red-400/5",
  "Devil's Advocate": "text-orange-400 border-orange-400/30 bg-orange-400/5",
  Empiricist: "text-purple-400 border-purple-400/30 bg-purple-400/5",
  Questioner: "text-cyan-400 border-cyan-400/30 bg-cyan-400/5",
  Defender: "text-green-400 border-green-400/30 bg-green-400/5",
  Synthesizer: "text-primary border-primary/30 bg-primary/5",
  Logician: "text-indigo-400 border-indigo-400/30 bg-indigo-400/5",
  Analyst: "text-blue-400 border-blue-400/30 bg-blue-400/5",
  Contrarian: "text-orange-400 border-orange-400/30 bg-orange-400/5",
  Realist: "text-gray-400 border-gray-400/30 bg-gray-400/5",
  Futurist: "text-violet-400 border-violet-400/30 bg-violet-400/5",
  Critic: "text-red-400 border-red-400/30 bg-red-400/5",
  "Balanced Reviewer": "text-teal-400 border-teal-400/30 bg-teal-400/5",
  "Standards Expert": "text-amber-400 border-amber-400/30 bg-amber-400/5",
};

function getRoleStyle(role: string) {
  return ROLE_COLORS[role] ?? "text-muted-foreground border-border/50 bg-muted/10";
}

// ── TemplateCard ──────────────────────────────────────────────────────────────
function TemplateCard({ template, onClick }: { template: Template; onClick: () => void }) {
  const Icon = ICON_MAP[template.icon] ?? Briefcase;
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="group text-left w-full rounded-xl border border-border/60 bg-card/50 hover:border-primary/40 hover:bg-primary/5 p-4 transition-all duration-200"
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm font-semibold truncate">{template.title}</span>
            <span className="ml-auto text-xs font-mono text-muted-foreground shrink-0">
              ~{template.estimatedCredits}cr
            </span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
            {template.description}
          </p>
        </div>
      </div>
    </motion.button>
  );
}

// ── V29 field wrapper ─────────────────────────────────────────────────────────
function V29Field({
  label, desc, children,
}: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <div className="text-[10px] font-bold tracking-widest uppercase text-primary/60">{label}</div>
      {children}
      {desc && <p className="text-[11px] text-muted-foreground/70 leading-relaxed">{desc}</p>}
    </div>
  );
}

const V29_SELECT = "bg-[#0d1a0d] border border-primary/30 text-sm text-foreground hover:border-primary/60 focus:border-primary h-10";

// ── ConfigPanel ───────────────────────────────────────────────────────────────
function ConfigPanel({
  open, onClose, config, onChange, uid, onboardingComplete,
}: {
  open: boolean;
  onClose: () => void;
  config: CourtConfig;
  onChange: (c: Partial<CourtConfig>) => void;
  uid?: string;
  onboardingComplete?: boolean;
}) {
  const [availableProviders, setAvailableProviders] = useState<ProviderInfo[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      getProviders().then((p) => setAvailableProviders(p.providers));
    }
  }, [open]);

  const selectedProvider = availableProviders.find((p) => p.name === config.provider)
    ?? availableProviders[0];

  const selectedModel: ModelInfo | undefined = selectedProvider?.models.find(
    (m) => m.id === (config.model ?? selectedProvider.defaultModel)
  ) ?? selectedProvider?.models[0];

  const credBase = selectedModel?.creditInfo
    ? estimateCredits(selectedModel.creditInfo, config.litigantCount, config.maxIterations, config.responseMode)
    : config.litigantCount * config.maxIterations * 3 + 6;
  const credLow = credBase;
  const credHigh = credBase + (config.conscience ? 1 : 0) + Math.ceil(credBase * 0.4);

  const confidenceLabel = {
    80: "80% Fast", 90: "90% Standard", 95: "95% Deep", 99: "99% Maximum",
  }[config.confidenceTarget as 80 | 90 | 95 | 99] ?? `${config.confidenceTarget}%`;

  async function handleSave() {
    onClose();
    if (!uid || !onboardingComplete) return;
    setSaving(true);
    try {
      await saveUserConfig(uid, {
        conscience: config.conscience,
        outputScope: config.outputScope,
        debateMode: config.debateMode,
        aiReasoning: config.aiReasoning,
        outputStrategy: config.outputStrategy,
        outputPreference: config.outputPreference,
        format: config.format,
        confidenceTarget: config.confidenceTarget,
        maxIterations: config.maxIterations,
        maxCredits: config.maxCredits,
        litigantCount: config.litigantCount,
        courtMode: config.courtMode,
        responseMode: config.responseMode,
        outputFormat: config.outputFormat,
        provider: config.provider,
        model: config.model,
      });
      toast.success("Configuration saved");
    } catch {
      toast.error("Could not save configuration");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent
        side="right"
        className="w-full max-w-sm bg-[#060e06] border-l-2 border-primary/40 overflow-y-auto p-0"
      >
        <div className="px-5 py-5 space-y-5">
          {/* Header */}
          <SheetHeader className="pb-0">
            <SheetTitle className="text-xl font-bold text-primary tracking-tight">
              Mission Briefing
            </SheetTitle>
          </SheetHeader>

          {/* SAFETY FILTER */}
          <V29Field label="Safety Filter" desc="ON: self-checks for bias, harm, and gaps. OFF: raw output.">
            <Select value={config.conscience ? "on" : "off"} onValueChange={(v) => onChange({ conscience: v === "on" })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="on">Conscience ON</SelectItem>
                <SelectItem value="off">Conscience OFF</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* RESPONSE MODE */}
          <V29Field label="Response Mode" desc="Consensus Only: one clean answer. All Voices: each AI's response shown.">
            <Select value={config.outputScope} onValueChange={(v) => onChange({ outputScope: v as CourtConfig["outputScope"] })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="consensus">Consensus Only</SelectItem>
                <SelectItem value="all-voices">All Voices</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* DEBATE MODE */}
          <V29Field label="Debate Mode" desc="Adversarial: AIs challenge each other. Collaborative: AIs build on each other.">
            <Select value={config.debateMode} onValueChange={(v) => onChange({ debateMode: v as CourtConfig["debateMode"], courtMode: v === "adversarial" ? "adversarial" : "analysis" })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="adversarial">Adversarial</SelectItem>
                <SelectItem value="collaborative">Collaborative</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* AI REASONING */}
          <V29Field label="AI Reasoning">
            <div className="flex flex-col gap-1.5">
              {(["independent", "chain"] as const).map((mode) => {
                const isSelected = config.aiReasoning === mode;
                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => onChange({ aiReasoning: mode })}
                    className={cn(
                      "text-left px-3 py-2.5 rounded border text-xs transition-colors",
                      isSelected
                        ? "border-primary bg-primary/10 text-foreground"
                        : "border-border/50 bg-background text-muted-foreground hover:border-border hover:text-foreground"
                    )}
                  >
                    <div className="font-semibold capitalize mb-0.5">{mode}</div>
                    {mode === "independent" ? (
                      <div className="text-[11px] leading-snug opacity-80">
                        Each AI builds on its own prior arguments only — other seats are not heard. Lower credit cost.
                      </div>
                    ) : (
                      <div className="text-[11px] leading-snug opacity-80">
                        Each AI reads the full debate before responding. Richer cross-examination —{" "}
                        <span className={isSelected ? "text-yellow-400" : "text-yellow-500"}>uses significantly more credits</span>{" "}
                        because all agents re-read the entire transcript each turn.
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </V29Field>

          {/* OUTPUT STRATEGY */}
          <V29Field label="Output Strategy">
            <Select value={config.outputStrategy} onValueChange={(v) => onChange({ outputStrategy: v as CourtConfig["outputStrategy"] })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="moderator-consensus">Moderator Consensus</SelectItem>
                <SelectItem value="individual">Individual Responses</SelectItem>
                <SelectItem value="consensus+individual">Consensus + Individual</SelectItem>
                <SelectItem value="transcript">Court Transcript</SelectItem>
                <SelectItem value="artifact">Artifact Only</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* OUTPUT PREFERENCE */}
          <V29Field label="Output Preference">
            <Select value={config.outputPreference} onValueChange={(v) => onChange({ outputPreference: v as CourtConfig["outputPreference"] })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="chat">Display in chat</SelectItem>
                <SelectItem value="download">Download only</SelectItem>
                <SelectItem value="both">Display + download</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* FORMAT */}
          <V29Field label="Format">
            <Select value={config.format} onValueChange={(v) => onChange({ format: v as CourtConfig["format"] })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="markdown">Markdown</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* CONFIDENCE TARGET */}
          <V29Field label="Confidence Target">
            <Select value={String(config.confidenceTarget)} onValueChange={(v) => onChange({ confidenceTarget: Number(v) })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="80">80% Fast</SelectItem>
                <SelectItem value="90">90% Standard</SelectItem>
                <SelectItem value="95">95% Deep</SelectItem>
                <SelectItem value="99">99% Maximum</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* MAXIMUM ITERATIONS */}
          <V29Field label="Maximum Iterations">
            <Select value={String(config.maxIterations)} onValueChange={(v) => onChange({ maxIterations: Number(v) })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1</SelectItem>
                <SelectItem value="3">3</SelectItem>
                <SelectItem value="5">5</SelectItem>
                <SelectItem value="10">10</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* MAXIMUM CREDITS */}
          <V29Field label="Maximum Credits">
            <Select value={String(config.maxCredits)} onValueChange={(v) => onChange({ maxCredits: Number(v) })}>
              <SelectTrigger className={V29_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="15">15</SelectItem>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
              </SelectContent>
            </Select>
          </V29Field>

          {/* AI PROVIDER */}
          {availableProviders.length > 0 && (
            <div className="space-y-2 pt-1 border-t border-primary/10">
              <div className="text-[10px] font-bold tracking-widest uppercase text-primary/60">AI Provider</div>
              <div className="grid grid-cols-2 gap-1.5">
                {availableProviders.map((p) => (
                  <button
                    key={p.name}
                    onClick={() => onChange({ provider: p.name as ProviderName, model: p.defaultModel })}
                    className={cn(
                      "flex items-center gap-1.5 px-2.5 py-2 rounded-lg border text-xs font-medium transition-all",
                      config.provider === p.name || (!config.provider && p === availableProviders[0])
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border/40 bg-transparent text-muted-foreground hover:border-primary/30"
                    )}
                  >
                    <span>{PROVIDER_ICONS[p.name as ProviderName]}</span>
                    {PROVIDER_LABELS[p.name as ProviderName]}
                  </button>
                ))}
              </div>
              {selectedProvider && selectedProvider.models.length > 0 && (
                <Select value={config.model ?? selectedProvider.defaultModel} onValueChange={(v) => onChange({ model: v })}>
                  <SelectTrigger className={V29_SELECT + " text-xs h-8"}><SelectValue placeholder="Select model" /></SelectTrigger>
                  <SelectContent>
                    {selectedProvider.models.map((m) => (
                      <SelectItem key={m.id} value={m.id} className="text-xs">{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          )}

          {/* ESTIMATED RUN COST */}
          <div className="rounded-lg border border-primary/25 bg-primary/5 p-4 space-y-1">
            <div className="text-[10px] font-bold tracking-widest uppercase text-primary/60">Estimated Run Cost</div>
            <div className="text-2xl font-bold text-primary">{credLow}–{credHigh} Credits</div>
            <div className="text-xs text-muted-foreground leading-relaxed">
              Based on {config.litigantCount} litigants, {config.debateMode} mode,{" "}
              {confidenceLabel}{config.conscience ? " + conscience gate (+1 Cr)" : ""}.
            </div>
          </div>

          {/* BUTTONS */}
          <div className="flex gap-2 pb-2">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 bg-white text-black hover:bg-white/90 font-semibold"
            >
              {saving ? "Saving…" : "Save Configuration"}
            </Button>
            <Button onClick={onClose} variant="outline" className="flex-1 border-primary/30 text-foreground">
              Close
            </Button>
          </div>
          {!onboardingComplete && uid && (
            <p className="text-[11px] text-muted-foreground/60 text-center -mt-2">
              Complete onboarding to save as default
            </p>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ── RuntimeControl ────────────────────────────────────────────────────────────
const COURT_MODE_LABELS: Record<string, string> = {
  adversarial: "Adversarial",
  socratic: "Socratic",
  analysis: "Analysis",
  critique: "Critique",
};

function RuntimeControl({
  starting, current, used, round, maxRound, cap, mode,
}: {
  starting: number; current: number; used: number;
  round: number; maxRound: number; cap: number; mode: string;
}) {
  const cells = [
    { label: "STARTING", value: String(starting), color: "text-white" },
    { label: "CURRENT",  value: String(current),  color: current < 10 ? "text-red-400" : current < 30 ? "text-yellow-400" : "text-primary" },
    { label: "USED",     value: String(used),      color: "text-white" },
    { label: "ROUND",    value: `${round} / ${maxRound}`, color: "text-white" },
    { label: "CREDIT CAP", value: cap > 0 ? `~${cap}` : "—", color: "text-muted-foreground" },
    { label: "MODE",     value: COURT_MODE_LABELS[mode] ?? mode, color: "text-primary/80" },
  ];
  return (
    <div className="rounded-lg border border-primary/20 overflow-hidden">
      <div className="px-3 py-1.5 border-b border-primary/10 bg-primary/5">
        <span className="text-[9px] font-black uppercase tracking-[0.2em] text-primary">Runtime Control</span>
      </div>
      <div className="grid grid-cols-2 gap-px bg-primary/10">
        {cells.map(({ label, value, color }) => (
          <div key={label} className="bg-[#070f07] px-3 py-2">
            <div className="text-[8px] font-bold uppercase tracking-widest text-muted-foreground/50 mb-0.5">{label}</div>
            <div className={cn("text-[15px] font-bold font-mono leading-none", color)}>{value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── V29 Conversation helpers ──────────────────────────────────────────────────

const PROVIDER_SHORT: Record<string, string> = {
  anthropic: "Claude", openai: "GPT", grok: "Grok", gemini: "Gemini",
};

function isLitigantRole(role: string) {
  return role.toLowerCase().startsWith("litigant");
}
function isOrchestratorRole(role: string) {
  return role === "Orchestrator" || role === "Verdict" || role === "Moderator";
}

// A single dialog line — matches V29 .dialog-line exactly
function DialogLine({ item, adversarial }: { item: FeedItem; adversarial?: boolean }) {
  const isYou = item.role === "You";
  const isLit = isLitigantRole(item.role);

  // Determine colors
  let borderColor: string;
  let speakerColor: string;
  let bgStyle: React.CSSProperties;

  if (isYou) {
    borderColor = "#4a9eff";
    speakerColor = "#4a9eff";
    bgStyle = { background: "rgba(0,120,255,.08)" };
  } else if (isLit) {
    borderColor = adversarial ? "#c84040" : "#7ab87a";
    speakerColor = adversarial ? "#ff9a9a" : "#7ab87a";
    bgStyle = { background: "rgba(0,0,0,.12)" };
  } else {
    // Orchestrator / Moderator / Verdict
    borderColor = "#7ab87a";
    speakerColor = "#7ab87a";
    bgStyle = { background: "rgba(0,0,0,.15)" };
  }

  // Extract disclosure header from "[Seat | Model | …]\n" pattern
  let disclosure = "";
  let body = item.content;
  if (!isYou && !isLit && body.startsWith("[")) {
    const nl = body.indexOf("\n");
    if (nl > -1) { disclosure = body.slice(0, nl + 1); body = body.slice(nl + 1); }
  }

  const providerShort = item.provider ? (PROVIDER_SHORT[item.provider] ?? null) : null;
  const speakerLabel = `${item.role}${isLit && adversarial ? " ⚔" : ""}${providerShort ? ` · ${providerShort}` : ""}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.16 }}
      style={{ ...bgStyle, borderLeft: `3px solid ${borderColor}`, borderRadius: 8, marginBottom: 8, padding: "6px 8px", lineHeight: 1.5, fontSize: 14 }}
    >
      <span style={{ fontWeight: 800, fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", display: "block", marginBottom: 2, color: speakerColor }}>
        {speakerLabel}
        {item.round > 0 && item.round < 99 && (
          <span style={{ fontWeight: 400, color: "#4a6a4a", marginLeft: 6, fontSize: 10 }}>R{item.round}</span>
        )}
        {!item.isComplete && (
          <span style={{ marginLeft: 6, display: "inline-flex", gap: 2, verticalAlign: "middle" }}>
            {[0, 130, 260].map((d) => (
              <span key={d} className="w-1 h-1 rounded-full bg-primary animate-bounce inline-block" style={{ animationDelay: `${d}ms` }} />
            ))}
          </span>
        )}
      </span>
      {disclosure && (
        <span style={{ fontSize: 11, color: "#3a5a3a", fontStyle: "italic", display: "block", marginBottom: 4, lineHeight: 1.3 }}>
          {disclosure.trim()}
        </span>
      )}
      {body || (!item.isComplete ? "" : <span style={{ color: "#4a6a4a", fontStyle: "italic" }}>No content.</span>)}
    </motion.div>
  );
}

// Litigant Voices box — collapsible, shown only in All Voices mode
function LitigantVoicesBox({
  items, adversarial, scrollRef,
}: { items: FeedItem[]; adversarial: boolean; scrollRef?: React.RefObject<HTMLDivElement> }) {
  const [open, setOpen] = useState(true);

  function handleSave() {
    const lines = items.filter(f => f.content).map(f =>
      `${f.role.toUpperCase()}\n${f.content}\n`
    ).join("\n---\n\n");
    if (!lines) return;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["Litigant Voices Export\n\n" + lines], { type: "text/plain" }));
    a.download = `LitigantVoices_${Date.now()}.txt`;
    a.click();
  }

  return (
    <div style={{ border: "1px solid #7ab87a", borderRadius: 12, overflow: "hidden", marginBottom: 8 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 8px", background: "rgba(122,184,122,.07)", borderBottom: "1px solid #1d331d", gap: 6 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, minWidth: 0, overflow: "hidden" }}>
          <span style={{ fontSize: 11, color: "#7ab87a", letterSpacing: "0.07em", textTransform: "uppercase", fontWeight: 800, whiteSpace: "nowrap" }}>Litigant Voices</span>
          {adversarial && (
            <span style={{ fontSize: 9, fontWeight: 900, color: "#ff6b6b", border: "1px solid #c84040", borderRadius: 999, padding: "1px 6px", letterSpacing: "0.05em", whiteSpace: "nowrap" }}>⚔ ADV</span>
          )}
        </div>
        <div style={{ display: "flex", gap: 4, alignItems: "center", flexShrink: 0 }}>
          <button onClick={handleSave} title="Export" style={{ fontSize: 12, padding: "3px 7px", minHeight: 26, background: "transparent", border: "1px solid #7ab87a", borderRadius: 6, cursor: "pointer", color: "#eef7ee" }}>⬇</button>
          <button onClick={() => setOpen(v => !v)} style={{ fontSize: 11, padding: "3px 8px", minHeight: 26, background: "transparent", border: "1px solid #7ab87a", borderRadius: 6, color: "#7ab87a", cursor: "pointer", whiteSpace: "nowrap" }}>
            {open ? "▼" : "▶"}
          </button>
        </div>
      </div>
      {/* Body */}
      {open && (
        <div ref={scrollRef} style={{ minHeight: 80, maxHeight: "clamp(120px,22vh,280px)", overflowY: "auto", padding: 10, background: "rgba(0,0,0,.12)" }}>
          {items.length === 0 ? (
            <div style={{ fontSize: 12, color: "#3a5a3a", fontStyle: "italic" }}>Waiting for litigant debate…</div>
          ) : (
            items.map(item => <DialogLine key={item.id} item={item} adversarial={adversarial} />)
          )}
        </div>
      )}
    </div>
  );
}

// Orchestrator / Consensus box — always open
function OrchestratorBox({
  question, items, scrollRef,
}: { question: string; items: FeedItem[]; scrollRef?: React.RefObject<HTMLDivElement> }) {
  function handleSave() {
    const youLine = `YOU\n${question}\n`;
    const lines = items.filter(f => f.content).map(f =>
      `${f.role.toUpperCase()}\n${f.content}\n`
    ).join("\n---\n\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["Litigant AI — Conversation Export\n\n" + youLine + "\n---\n\n" + lines], { type: "text/plain" }));
    a.download = `LitigantAI_${Date.now()}.txt`;
    a.click();
  }

  function handlePrint() { window.print(); }

  const youItem: FeedItem = { id: "you", role: "You", provider: "", content: question, round: 0, timestamp: 0, isComplete: true };

  return (
    <div style={{ border: "1px solid #00c853", borderRadius: 12, overflow: "hidden" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 8px", background: "rgba(0,200,83,.07)", borderBottom: "1px solid #1d331d", gap: 6 }}>
        <span style={{ fontSize: 11, color: "#00c853", letterSpacing: "0.07em", textTransform: "uppercase", fontWeight: 800, whiteSpace: "nowrap", minWidth: 0, overflow: "hidden", textOverflow: "ellipsis" }}>Orchestrator / Consensus</span>
        <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
          <button onClick={handleSave} title="Save" style={{ fontSize: 12, padding: "3px 7px", minHeight: 26, background: "transparent", border: "1px solid #00c853", borderRadius: 6, cursor: "pointer", color: "#eef7ee" }}>⬇</button>
          <button onClick={handlePrint} title="Print" style={{ fontSize: 12, padding: "3px 7px", minHeight: 26, background: "transparent", border: "1px solid #00c853", borderRadius: 6, cursor: "pointer", color: "#eef7ee" }}>🖨</button>
        </div>
      </div>
      {/* Body */}
      <div ref={scrollRef} style={{ minHeight: 80, maxHeight: "clamp(160px,32vh,360px)", overflowY: "auto", padding: "10px 10px 6px", fontSize: 14, lineHeight: 1.6, background: "rgba(0,0,0,.12)" }}>
        {question && <DialogLine key="you" item={youItem} />}
        {items.map(item => <DialogLine key={item.id} item={item} />)}
        {items.length === 0 && question && (
          <div style={{ fontSize: 12, color: "#3a5a3a", fontStyle: "italic", marginTop: 6 }}>Courtroom assembling…</div>
        )}
      </div>
    </div>
  );
}

// ── Export helpers ─────────────────────────────────────────────────────────────
function buildMarkdown(state: ReturnType<typeof useBrainSession>["state"]): string {
  return [
    `# Litigant AI Session Report`,
    ``,
    `**Question:** ${state.question}`,
    state.template ? `**Template:** ${state.template.title}` : null,
    `**Confidence:** ${state.confidence}%`,
    `**Credits Used:** ${state.creditsUsed}`,
    `**Date:** ${new Date().toLocaleDateString()}`,
    ``,
    `---`,
    ``,
    `## Final Answer`,
    ``,
    state.finalAnswer || "_No final answer generated._",
    ``,
    `---`,
    ``,
    `## Artifacts`,
    ``,
    state.artifacts || "_No artifacts generated._",
    ``,
    `---`,
    ``,
    `## Debate Notes`,
    ``,
    state.debateNotes || "_No debate notes._",
    ``,
    `---`,
    ``,
    `## Sources & Caveats`,
    ``,
    state.caveats,
    ``,
    `---`,
    `*Generated by Litigant AI — Don't just ask AI. Put the question on trial.*`,
  ].filter(Boolean).join("\n");
}

function exportPDF(state: ReturnType<typeof useBrainSession>["state"], w: Window): void {
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Litigant AI Session — ${state.question.slice(0, 60)}</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 800px; margin: 40px auto; color: #111; line-height: 1.6; }
    h1 { font-size: 1.5rem; margin-bottom: 0.25rem; }
    h2 { font-size: 1.1rem; margin-top: 2rem; border-bottom: 1px solid #ddd; padding-bottom: 0.25rem; }
    .meta { color: #666; font-size: 0.85rem; margin-bottom: 1.5rem; }
    pre { background: #f5f5f5; padding: 1rem; border-radius: 6px; white-space: pre-wrap; font-size: 0.8rem; }
    .badge { display: inline-block; background: #00c853; color: #000; font-size: 0.75rem; padding: 2px 8px; border-radius: 4px; font-weight: 600; }
    @media print { body { margin: 20px; } }
  </style>
</head>
<body>
  <h1>Litigant AI Session Report</h1>
  <div class="meta">
    <strong>Question:</strong> ${state.question}<br/>
    ${state.template ? `<strong>Template:</strong> ${state.template.title}<br/>` : ""}
    <strong>Confidence:</strong> <span class="badge">${state.confidence}%</span>
    &nbsp; <strong>Credits:</strong> ${state.creditsUsed}
    &nbsp; <strong>Date:</strong> ${new Date().toLocaleDateString()}
  </div>
  <h2>Final Answer</h2>
  <pre>${state.finalAnswer || "No final answer generated."}</pre>
  ${state.artifacts ? `<h2>Artifacts</h2><pre>${state.artifacts}</pre>` : ""}
  <h2>Debate Notes</h2>
  <pre>${state.debateNotes || "No debate notes."}</pre>
  <h2>Sources &amp; Caveats</h2>
  <pre>${state.caveats}</pre>
  <p style="margin-top:2rem;color:#999;font-size:0.75rem;">Generated by Litigant AI — Don't just ask AI. Put the question on trial.</p>
</body>
</html>`;

  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 400);
}

// ── Main page ──────────────────────────────────────────────────────────────────
export default function SessionPage() {
  const { user, userProfile } = useAuth();
  const { credits, plan } = useUserProfile();
  const savedConfig = userProfile?.defaultSettings
    ? {
        // Core settings
        courtMode:        (userProfile.defaultSettings.courtMode as CourtConfig["courtMode"]) ?? "adversarial",
        litigantCount:    userProfile.defaultSettings.litigantCount ?? 3,
        confidenceTarget: userProfile.defaultSettings.confidenceTarget ?? 80,
        maxIterations:    userProfile.defaultSettings.maxIterations ?? 2,
        responseMode:     (userProfile.defaultSettings.responseMode as CourtConfig["responseMode"]) ?? "balanced",
        outputFormat:     (userProfile.defaultSettings.outputFormat as CourtConfig["outputFormat"]) ?? "report",
        provider:         (userProfile.defaultSettings.provider as CourtConfig["provider"]) ?? undefined,
        model:            userProfile.defaultSettings.model ?? undefined,
        // V29 Mission Briefing fields
        conscience:       userProfile.defaultSettings.conscience ?? true,
        aiReasoning:      (userProfile.defaultSettings.aiReasoning as CourtConfig["aiReasoning"]) ?? "chain",
        debateMode:       (userProfile.defaultSettings.debateMode as CourtConfig["debateMode"]) ?? "adversarial",
        maxCredits:       userProfile.defaultSettings.maxCredits ?? undefined,
        outputScope:      (userProfile.defaultSettings.outputScope as CourtConfig["outputScope"]) ?? undefined,
        outputStrategy:   (userProfile.defaultSettings.outputStrategy as CourtConfig["outputStrategy"]) ?? undefined,
        outputPreference: (userProfile.defaultSettings.outputPreference as CourtConfig["outputPreference"]) ?? undefined,
        format:           (userProfile.defaultSettings.format as CourtConfig["format"]) ?? undefined,
      }
    : undefined;
  const { state, run, stop, reset, acceptPartial, continueSession, setQuestion, setTemplate, setConfig, setSeatAI, applyFeedbackGrades } = useBrainSession(savedConfig);
  const [, navigate] = useLocation();

  const [configOpen, setConfigOpen] = useState(false);
  const [templateSheetOpen, setTemplateSheetOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [feedbackGiven, setFeedbackGiven] = useState<"good" | "bad" | "warn" | null>(null);
  const [inspectorSeat, setInspectorSeat] = useState<{ seatId: string; litIndex?: number } | null>(null);
  const [fieldValues, setFieldValues] = useState<Record<string, string>>({});
  const [selectedCreditInfo, setSelectedCreditInfo] = useState<ModelCreditInfo | null>(null);
  const [activityLogOpen, setActivityLogOpen] = useState(false);
  const feedRef = useRef<HTMLDivElement>(null);
  const activityLogRef = useRef<HTMLDivElement>(null);

  // Load provider credit info for accurate session cost estimate
  useEffect(() => {
    getProviders().then((data) => {
      const prov = data.providers.find((p) => p.name === state.config.provider) ?? data.providers[0];
      const model = prov?.models.find((m) => m.id === (state.config.model ?? prov?.defaultModel)) ?? prov?.models[0];
      setSelectedCreditInfo(model?.creditInfo ?? null);
    }).catch(() => {});
  }, [state.config.provider, state.config.model]);

  // Reset field values when template changes
  useEffect(() => {
    setFieldValues({});
  }, [state.template?.id]);

  // Pre-select template from ?templateId= URL param
  const [toolBanner, setToolBanner] = useState<string | null>(null);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tid = params.get("templateId");
    if (tid && state.phase === "idle" && !state.template) {
      const template = TEMPLATES.find((t) => t.id === tid);
      if (template) {
        setTemplate(template);
        setConfig(template.defaultConfig);
        setToolBanner(template.title);
      }
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-scroll runtime feed
  useEffect(() => {
    if (feedRef.current && state.phase === "running") {
      feedRef.current.scrollTop = feedRef.current.scrollHeight;
    }
  }, [state.runtimeFeed, state.phase]);

  // Auto-scroll activity log
  useEffect(() => {
    if (activityLogRef.current && activityLogOpen) {
      activityLogRef.current.scrollTop = activityLogRef.current.scrollHeight;
    }
  }, [state.activityLog, activityLogOpen]);

  /** Assemble a structured question from template input field values */
  function assembleFieldQuestion(): string {
    if (!state.template || state.template.inputFields.length === 0) return state.question;
    return state.template.inputFields
      .map((f) => (fieldValues[f.id]?.trim() ? `${f.label}: ${fieldValues[f.id].trim()}` : null))
      .filter(Boolean)
      .join("\n");
  }

  async function handleRun() {
    const hasFields = state.template && state.template.inputFields.length > 0;
    let effectiveQuestion = hasFields ? assembleFieldQuestion() : state.question;

    if (hasFields) {
      const missing = state.template!.inputFields.filter((f) => f.required && !fieldValues[f.id]?.trim());
      if (missing.length > 0) {
        toast.error(`Please fill in: ${missing.map((f) => f.label).join(", ")}`);
        return;
      }
    }

    if (!effectiveQuestion.trim()) {
      toast.error("Please enter a question first.");
      return;
    }
    if (userProfile && userProfile.creditBalance < estimatedCredits) {
      toast.error(`You need at least ${estimatedCredits} credits to run this session.`, {
        action: { label: "Buy Credits", onClick: () => navigate("/billing") },
      });
      return;
    }
    setFeedbackGiven(null);
    await run(effectiveQuestion !== state.question ? effectiveQuestion : undefined);
  }

  function handleReset() {
    reset();
    setFeedbackGiven(null);
  }

  function handleCopyMarkdown() {
    navigator.clipboard.writeText(buildMarkdown(state));
    toast.success("Copied to clipboard.");
  }

  function handleDownloadMarkdown() {
    const blob = new Blob([buildMarkdown(state)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `brain-session-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded.");
  }

  function handleExportPDF() {
    const w = window.open("", "_blank");
    if (!w) {
      toast.error("Popup blocked — allow popups for this site to print/save as PDF.");
      return;
    }
    exportPDF(state, w);
  }

  function handleStop() {
    stop();
    toast.info("Session stopped. Partial results are shown below.");
  }

  async function handleFeedback(rating: "good" | "bad" | "warn") {
    setFeedbackGiven(rating);
    if (rating === "good" || rating === "bad") {
      applyFeedbackGrades(rating, state.courtHappened ? "answer" : "answer");
    }
    try {
      await submitFeedback({
        userId: user?.uid ?? null,
        sessionId: state.sessionId,
        turnId: state.sessionId ?? `anon-${Date.now()}`,
        role: "Verdict",
        rating,
      });
      toast.success("Feedback recorded — grades updated.");
    } catch {
      toast.error("Failed to save feedback.");
    }
  }

  function handleSeatClick(seatId: string, litIndex?: number) {
    setInspectorSeat({ seatId, litIndex });
  }

  function handleSeatUpdate(seatId: string, assignment: SeatAssignment, litIndex?: number) {
    setSeatAI(seatId, assignment, litIndex);
  }

  function handleAddLitigant() {
    const next = Math.min(state.config.litigantCount + 1, 8);
    setConfig({ litigantCount: next });
  }

  function handleRemoveLitigant() {
    const next = Math.max(state.config.litigantCount - 1, 2);
    setConfig({ litigantCount: next });
  }

  const isRunning = state.phase === "running";
  const isPaused = state.phase === "paused";
  const isComplete = state.phase === "complete";
  const isError = state.phase === "error";
  const isIdle = state.phase === "idle";

  const estimatedCredits = selectedCreditInfo
    ? estimateCredits(selectedCreditInfo, state.config.litigantCount, state.config.maxIterations, state.config.responseMode)
    : state.config.litigantCount * state.config.maxIterations * 3 + 6;

  // Live credit health — from Firestore via useUserProfile (updates as backend deducts)
  const creditsCritical = credits < 10;
  const creditsLow = credits < 50 && !creditsCritical;
  const insufficientCredits = credits < estimatedCredits;
  const sessionsLeft = estimatedCredits > 0 ? Math.floor(credits / estimatedCredits) : 0;

  const filteredTemplates =
    activeCategory === "all" ? TEMPLATES : TEMPLATES.filter((t) => t.category === activeCategory);

  // Activity log renderer (shared across idle/running/complete)
  function ActivityLogSection() {
    return (
      <div style={{ border: "1px solid rgba(0,200,83,.2)", borderRadius: 9, overflow: "hidden" }}>
        <button
          onClick={() => setActivityLogOpen((v) => !v)}
          style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 12px", background: "rgba(0,200,83,.05)", cursor: "pointer", border: "none", color: "#eef7ee" }}
        >
          <span style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.08em", color: "#7ab87a" }}>
            Activity Log
            {isRunning && [0, 120, 240].map((d) => (
              <span key={d} className="w-1 h-1 rounded-full bg-primary animate-bounce inline-block" style={{ animationDelay: `${d}ms` }} />
            ))}
          </span>
          <span style={{ fontSize: 12, color: "#7ab87a" }}>{activityLogOpen ? "▼" : "▶"}</span>
        </button>
        {activityLogOpen && (
          <div ref={activityLogRef} style={{ padding: "8px 12px", maxHeight: 160, overflowY: "auto", background: "rgba(0,0,0,.3)" }}>
            {state.activityLog.map((entry, i) => {
              const col = entry.startsWith("[Courtroom]") ? "#7ab87a"
                : entry.startsWith("[Orchestrator]") ? "#d4b75a"
                : entry.startsWith("[Moderator]") ? "#6ab4c0"
                : entry.startsWith("[System]") ? "#5a5a5a"
                : "#7ab87a";
              return <div key={i} style={{ fontSize: 11, fontFamily: "monospace", lineHeight: 1.5, color: col }}>{entry}</div>;
            })}
            {state.activityLog.length === 0 && <div style={{ fontSize: 11, fontFamily: "monospace", color: "#3a5a3a" }}>Waiting…</div>}
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className="flex flex-col overflow-y-auto min-h-[calc(100vh-3.5rem)]"
      style={{ background: "radial-gradient(circle at top, #102010, #070f07 56%, #020402)" }}
    >
      <ConfigPanel
        open={configOpen}
        onClose={() => setConfigOpen(false)}
        config={state.config}
        onChange={setConfig}
        uid={user?.uid}
        onboardingComplete={userProfile?.onboardingComplete}
      />

      {/* ── HEADER NAV — Configure | Sessions | state controls ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, padding: "7px 8px", borderBottom: "1px solid #1d331d", background: "rgba(4,8,4,.96)", flexShrink: 0 }}>
        <button
          onClick={() => setConfigOpen(true)}
          style={{ background: "#0d1a0d", color: "#eef7ee", border: "1px solid #1d331d", borderRadius: 9, fontSize: 15, minHeight: 40, cursor: "pointer", fontWeight: 600 }}
        >
          ⚙ Configure
        </button>
        <button
          onClick={() => navigate("/sessions")}
          style={{ background: "#0d1a0d", color: "#eef7ee", border: "1px solid #1d331d", borderRadius: 9, fontSize: 15, minHeight: 40, cursor: "pointer", fontWeight: 600 }}
        >
          📂 Sessions
        </button>
        {isRunning && (
          <button
            onClick={handleStop}
            style={{ gridColumn: "1 / -1", background: "rgba(200,64,64,.12)", color: "#ff6b6b", border: "1px solid #c8404055", borderRadius: 9, fontSize: 14, minHeight: 36, cursor: "pointer", fontWeight: 700 }}
          >
            ⏹ Stop Trial
          </button>
        )}
        {(isComplete || isError) && (
          <button
            onClick={handleReset}
            style={{ gridColumn: "1 / -1", background: "rgba(0,200,83,.1)", color: "#00c853", border: "1px solid #00c85355", borderRadius: 9, fontSize: 14, minHeight: 36, cursor: "pointer", fontWeight: 700 }}
          >
            ↺ New Trial
          </button>
        )}
      </div>

      {/* ── CONVERSATION PANEL ── */}
      <div style={{ border: "1px solid #1d331d", borderRadius: 12, margin: "8px", padding: 8, background: "linear-gradient(160deg,rgba(14,26,14,.95),rgba(7,16,7,.95))", display: "flex", flexDirection: "column", gap: 6 }}>
        <div style={{ fontSize: 10, color: "#00c853", letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 800, marginBottom: 2 }}>Conversation</div>

        {/* Tool page pre-load banner */}
        {toolBanner && isIdle && (
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 10px", background: "rgba(0,200,83,.07)", border: "1px solid rgba(0,200,83,.2)", borderRadius: 8 }}>
            <LayoutTemplate style={{ width: 13, height: 13, color: "#7ab87a", flexShrink: 0 }} />
            <span style={{ fontSize: 12, color: "#7ab87a", flex: 1 }}>
              Pre-loaded: <strong>{toolBanner}</strong>
            </span>
            <button
              onClick={() => { setTemplate(null); setToolBanner(null); }}
              style={{ background: "transparent", border: "none", color: "#3a5a3a", cursor: "pointer", fontSize: 14, lineHeight: 1, padding: "0 2px" }}
              title="Start fresh instead"
            >✕</button>
          </div>
        )}

        {/* Confidence + Credits bars — always visible */}
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#7ab87a", marginBottom: 3 }}>
              <span>Confidence</span>
              <span style={{ fontFamily: "monospace", color: state.confidence >= state.config.confidenceTarget ? "#00c853" : "#7ab87a" }}>
                {state.confidence}% / {state.config.confidenceTarget}%
              </span>
            </div>
            <div style={{ height: 6, borderRadius: 3, background: "rgba(0,0,0,.4)", overflow: "hidden" }}>
              <div style={{ height: "100%", borderRadius: 3, background: state.confidence >= state.config.confidenceTarget ? "#00c853" : "rgba(0,200,83,.55)", width: `${Math.min(100, (state.confidence / state.config.confidenceTarget) * 100)}%`, transition: "width .5s" }} />
            </div>
          </div>
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#7ab87a", marginBottom: 3 }}>
              <span>Credits Used</span>
              <span style={{ fontFamily: "monospace" }}>{state.creditsUsed} / ~{estimatedCredits} est</span>
            </div>
            <div style={{ height: 6, borderRadius: 3, background: "rgba(0,0,0,.4)", overflow: "hidden" }}>
              <div style={{ height: "100%", borderRadius: 3, background: "rgba(0,200,83,.4)", width: `${Math.min(100, (state.creditsUsed / Math.max(estimatedCredits, 1)) * 100)}%`, transition: "width .5s" }} />
            </div>
          </div>
        </div>

        {/* Running/paused status badge */}
        {isRunning && (
          <div style={{ background: "rgba(0,200,83,.12)", border: "1px solid #00c853", borderRadius: 8, padding: "6px 10px", fontSize: 12, color: "#b6ff6a", fontWeight: 700, display: "flex", alignItems: "center", gap: 8 }}>
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse inline-block" />
            ⚡ Brain is thinking…
            {state.currentRound > 0 && state.currentRound < 99 && (
              <span style={{ marginLeft: "auto", fontFamily: "monospace", fontSize: 11, color: "#7ab87a" }}>
                Revolution {state.currentRound} / {state.config.maxIterations}
              </span>
            )}
          </div>
        )}

        {/* Paused decision card */}
        {isPaused && state.pauseReason && (
          <div style={{ background: "rgba(243,210,106,.07)", border: "1px solid rgba(243,210,106,.35)", borderRadius: 9, padding: "10px 12px" }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#f3d26a", marginBottom: 6 }}>
              ⏸ {state.pauseReason === "credit_cap" ? `Credit cap reached — ${Math.round(state.confidence)}% confidence` : `${state.config.maxIterations} rounds done — ${Math.round(state.confidence)}% (target ${state.config.confidenceTarget}%)`}
            </div>
            <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
              {credits === 0 ? (
                <button onClick={() => navigate("/billing")} style={{ flex: 1, padding: "8px 0", borderRadius: 8, background: "#00c853", color: "#000", fontSize: 13, fontWeight: 800, border: "none", cursor: "pointer" }}>Top Up Wallet</button>
              ) : (
                <button onClick={() => { void continueSession(); }} style={{ flex: 1, padding: "8px 0", borderRadius: 8, background: "#00c853", color: "#000", fontSize: 13, fontWeight: 800, border: "none", cursor: "pointer" }}>Continue — {credits} cr</button>
              )}
              <button onClick={acceptPartial} style={{ flex: 1, padding: "8px 0", borderRadius: 8, background: "transparent", color: "#7ab87a", fontSize: 13, border: "1px solid #1d331d", cursor: "pointer" }}>Accept answer</button>
            </div>
          </div>
        )}

        {/* Error state */}
        {isError && (
          <div style={{ background: "rgba(200,64,64,.08)", border: "1px solid rgba(200,64,64,.3)", borderRadius: 9, padding: "16px", textAlign: "center" }}>
            <div style={{ fontSize: 14, color: "#ff6b6b", fontWeight: 700, marginBottom: 6 }}>Session Error</div>
            <div style={{ fontSize: 12, color: "#9a5a5a", marginBottom: 10 }}>{state.errorMessage}</div>
            <button onClick={handleReset} style={{ background: "transparent", border: "1px solid #c84040", borderRadius: 8, color: "#ff6b6b", padding: "6px 16px", cursor: "pointer", fontSize: 13 }}>Try Again</button>
          </div>
        )}

        {/* V29 conversation boxes — shown when there's a question */}
        {state.question && !isIdle && (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {state.runtimeFeed.some((f) => isLitigantRole(f.role)) && (
              <LitigantVoicesBox
                items={state.runtimeFeed.filter((f) => isLitigantRole(f.role))}
                adversarial={state.config.courtMode === "adversarial"}
              />
            )}
            <OrchestratorBox
              question={state.question}
              items={state.runtimeFeed.filter((f) => isOrchestratorRole(f.role))}
            />
          </div>
        )}

        {/* Complete: feedback + export + output tabs */}
        {isComplete && (
          <>
            {/* Feedback + export */}
            <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", padding: "6px 0" }}>
              <span style={{ fontSize: 12, color: "#7ab87a" }}>Helpful?</span>
              {(["good", "bad", "warn"] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => handleFeedback(r)}
                  disabled={feedbackGiven !== null}
                  style={{
                    width: 34, height: 34, borderRadius: 8, fontSize: 16,
                    background: feedbackGiven === r ? "rgba(0,200,83,.15)" : "transparent",
                    border: feedbackGiven === r ? "1px solid #00c853" : "1px solid #1d331d",
                    cursor: feedbackGiven !== null ? "default" : "pointer", color: "#eef7ee",
                  }}
                >
                  {r === "good" ? "👍" : r === "bad" ? "👎" : "⚠️"}
                </button>
              ))}
              <div style={{ marginLeft: "auto", display: "flex", gap: 4 }}>
                <button onClick={handleCopyMarkdown} style={{ fontSize: 12, padding: "4px 8px", background: "transparent", border: "1px solid #1d331d", borderRadius: 7, color: "#eef7ee", cursor: "pointer" }}>Copy</button>
                <button onClick={handleDownloadMarkdown} style={{ fontSize: 12, padding: "4px 8px", background: "transparent", border: "1px solid #1d331d", borderRadius: 7, color: "#eef7ee", cursor: "pointer" }}>MD</button>
                <button onClick={handleExportPDF} style={{ fontSize: 12, padding: "4px 8px", background: "transparent", border: "1px solid #1d331d", borderRadius: 7, color: "#eef7ee", cursor: "pointer" }}>Print</button>
              </div>
            </div>

            {/* Output tabs */}
            <Tabs defaultValue="answer">
              <TabsList className="bg-black/30 border border-white/8 mb-2 flex-wrap h-auto gap-y-1">
                <TabsTrigger value="answer" className="text-xs">Final Answer</TabsTrigger>
                <TabsTrigger value="debate" className="text-xs">Debate</TabsTrigger>
                <TabsTrigger value="transcript" className="text-xs">Transcript</TabsTrigger>
                <TabsTrigger value="caveats" className="text-xs">Caveats</TabsTrigger>
              </TabsList>
              <TabsContent value="answer">
                <div style={{ border: "1px solid rgba(0,200,83,.2)", borderRadius: 10, background: "rgba(0,200,83,.05)", padding: "14px" }}>
                  <div style={{ fontSize: 11, color: "#00c853", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>
                    Verdict — {state.confidence}% confidence
                  </div>
                  <div style={{ fontSize: 14, lineHeight: 1.65, color: "#eef7ee", whiteSpace: "pre-wrap" }}>
                    {state.finalAnswer || "No final answer generated."}
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="debate">
                <div style={{ border: "1px solid #1d331d", borderRadius: 10, padding: "14px", background: "rgba(0,0,0,.12)" }}>
                  <div style={{ fontSize: 11, color: "#7ab87a", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Debate Notes</div>
                  <div style={{ fontSize: 13, lineHeight: 1.6, color: "#9aaa9a", whiteSpace: "pre-wrap", fontFamily: "monospace" }}>
                    {state.debateNotes || "No debate notes recorded."}
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="transcript">
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {state.runtimeFeed.some((f) => isLitigantRole(f.role)) && (
                    <LitigantVoicesBox items={state.runtimeFeed.filter((f) => isLitigantRole(f.role))} adversarial={state.config.courtMode === "adversarial"} />
                  )}
                  <OrchestratorBox question={state.question} items={state.runtimeFeed.filter((f) => isOrchestratorRole(f.role))} />
                </div>
              </TabsContent>
              <TabsContent value="caveats">
                <div style={{ border: "1px solid rgba(243,210,106,.2)", borderRadius: 10, background: "rgba(243,210,106,.04)", padding: "14px" }}>
                  <div style={{ fontSize: 11, color: "#f3d26a", fontWeight: 800, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 8 }}>Sources & Caveats</div>
                  <div style={{ fontSize: 14, lineHeight: 1.65, color: "#eef7ee", whiteSpace: "pre-wrap", marginBottom: 10 }}>{state.caveats}</div>
                  <div style={{ fontSize: 12, color: "#5a5a3a", borderTop: "1px solid rgba(243,210,106,.1)", paddingTop: 10 }}>
                    Litigant AI provides AI-generated reasoning. Not legal, medical, financial, or professional advice.
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}

        {/* Idle state — credit info + single template entry point */}
        {isIdle && (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <div style={{ fontSize: 12, color: "#3a5a3a", textAlign: "center" }}>
              {credits} credits available · {plan}
              {insufficientCredits && (
                <span> · <span style={{ color: "#ff6b6b", cursor: "pointer", textDecoration: "underline" }} onClick={() => navigate("/billing")}>top up</span></span>
              )}
            </div>
            <button
              onClick={() => setTemplateSheetOpen(true)}
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "rgba(0,200,83,.04)", border: "1px solid rgba(0,200,83,.15)", borderRadius: 9, cursor: "pointer", textAlign: "left", width: "100%", transition: "border-color .15s" }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(0,200,83,.35)")}
              onMouseLeave={e => (e.currentTarget.style.borderColor = "rgba(0,200,83,.15)")}
            >
              <LayoutTemplate style={{ width: 15, height: 15, color: "#7ab87a", flexShrink: 0 }} />
              <span style={{ fontSize: 12, color: "#7ab87a", fontWeight: 600 }}>Use a template</span>
              <span style={{ fontSize: 11, color: "#3a5a3a", marginLeft: "auto" }}>{TEMPLATES.length} available →</span>
            </button>
          </div>
        )}

        {/* ── INPUT: BIG TEXTAREA + BIG GREEN ▶ BUTTON ── */}
        {(isIdle || isComplete) && (
          <>
            {state.template && state.template.inputFields.length > 0 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ fontSize: 11, color: "#7ab87a", fontWeight: 700 }}>{state.template.title}</span>
                  <button onClick={() => setTemplate(null)} style={{ background: "transparent", border: "none", color: "#5a5a5a", cursor: "pointer", fontSize: 14, lineHeight: 1 }}>✕</button>
                </div>
                {state.template.inputFields.map((field) => (
                  <div key={field.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 11, color: "#7ab87a", whiteSpace: "nowrap", width: 80, flexShrink: 0 }}>{field.label}</span>
                    <Input
                      type={field.type === "url" ? "url" : "text"}
                      placeholder={field.placeholder}
                      value={fieldValues[field.id] ?? ""}
                      onChange={(e) => setFieldValues((prev) => ({ ...prev, [field.id]: e.target.value }))}
                      onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleRun(); }}
                      className="h-9 text-sm flex-1"
                      style={{ background: "#0d1a0d", border: "1px solid #1d331d", color: "#eef7ee" }}
                    />
                  </div>
                ))}
                <div style={{ display: "flex", gap: 6 }}>
                  <button
                    onClick={handleRun}
                    disabled={insufficientCredits}
                    style={{ flex: 1, minHeight: 48, borderRadius: 9, background: "#00c853", color: "#000", fontSize: 22, fontWeight: 900, border: "none", cursor: insufficientCredits ? "not-allowed" : "pointer", opacity: insufficientCredits ? 0.4 : 1 }}
                  >▶</button>
                </div>
              </div>
            ) : (
              <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
                <Textarea
                  placeholder={isComplete ? "Ask a follow-up question…" : "Ask a question or follow up…"}
                  value={state.question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); if (!isRunning) handleRun(); } }}
                  style={{ flex: 1, minHeight: 90, resize: "none", fontSize: 16, background: "#0d1a0d", border: "1px solid #1d331d", borderRadius: 9, color: "#eef7ee", padding: "10px 12px", lineHeight: 1.5 }}
                  className="focus-visible:ring-1 focus-visible:ring-primary/60"
                />
                <button
                  onClick={handleRun}
                  disabled={!state.question.trim() || insufficientCredits}
                  style={{ minWidth: 64, alignSelf: "stretch", borderRadius: 9, background: "#00c853", color: "#000", fontSize: 28, fontWeight: 900, border: "none", cursor: (!state.question.trim() || insufficientCredits) ? "not-allowed" : "pointer", opacity: (!state.question.trim() || insufficientCredits) ? 0.35 : 1 }}
                >▶</button>
              </div>
            )}
            <div style={{ fontSize: 11, color: "#2a4a2a", textAlign: "right" }}>Shift+Enter for new line</div>
          </>
        )}
      </div>

      {/* ── RUNTIME CONTROL PANEL ── */}
      {!isIdle && (
        <div style={{ border: "1px solid #1d331d", borderRadius: 12, margin: "0 8px 8px", padding: 8, background: "linear-gradient(160deg,rgba(14,26,14,.92),rgba(7,16,7,.92))", display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ fontSize: 10, color: "#00c853", letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 800, marginBottom: 2 }}>Runtime Control</div>
          <RuntimeControl
            starting={credits + state.creditsUsed}
            current={credits}
            used={state.creditsUsed}
            round={state.currentRound}
            maxRound={state.config.maxIterations}
            cap={state.estimatedCredits}
            mode={state.config.courtMode}
          />
          <ActivityLogSection />
        </div>
      )}

      {/* ── COURT DIAGRAM — at the bottom ── */}
      <div className="shrink-0 relative" style={{ height: "clamp(200px, 60vw, 480px)" }}>
        <CourtDiagram
          activeRole={state.activeRole}
          litigantCount={state.config.litigantCount}
          running={isRunning}
          confidence={state.confidence}
          creditsUsed={state.creditsUsed}
          estimatedCredits={state.estimatedCredits}
          complete={isComplete}
          seatMap={state.config.seatMap ?? makeDefaultSeatMap(state.config.litigantCount)}
          grades={state.grades}
          onSeatClick={handleSeatClick}
          onAddLitigant={!isRunning ? handleAddLitigant : undefined}
          onRemoveLitigant={!isRunning ? handleRemoveLitigant : undefined}
        />
        {(isRunning || isComplete) && state.currentRound > 0 && state.currentRound < 99 && (
          <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/70 border border-primary/25 text-[10px] font-mono text-primary/80 pointer-events-none">
            <span className={cn("w-1.5 h-1.5 rounded-full bg-primary", isRunning && "animate-pulse")} />
            Revolution {state.currentRound} / {state.config.maxIterations}
          </div>
        )}
        <div className={cn(
          "absolute top-2 right-2 flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/70 border text-[10px] font-mono pointer-events-none",
          creditsCritical ? "border-red-500/40 text-red-400"
          : creditsLow ? "border-yellow-500/40 text-yellow-400"
          : "border-primary/25 text-primary/70"
        )}>
          <Zap className="w-2.5 h-2.5" />
          {credits} cr
        </div>
      </div>

      {/* ── SEAT INSPECTOR ── */}
      {inspectorSeat && (
        <SeatInspector
          seatId={inspectorSeat.seatId}
          litIndex={inspectorSeat.litIndex}
          litigantCount={state.config.litigantCount}
          seatMap={state.config.seatMap ?? makeDefaultSeatMap(state.config.litigantCount)}
          grades={state.grades}
          onClose={() => setInspectorSeat(null)}
          onUpdate={(seatId, assignment, li) => handleSeatUpdate(seatId, assignment, li)}
        />
      )}

      <Sheet open={templateSheetOpen} onOpenChange={(o) => !o && setTemplateSheetOpen(false)}>
        <SheetContent side="bottom" className="h-[65vh] flex flex-col bg-[#0a160a] border-t border-white/8">
          <SheetHeader className="shrink-0 pb-3 border-b border-white/5">
            <SheetTitle className="text-sm flex items-center gap-2">
              <LayoutTemplate className="w-4 h-4 text-primary" />
              Templates
            </SheetTitle>
          </SheetHeader>
          <div className="flex items-center gap-2 py-2 overflow-x-auto shrink-0 scrollbar-none">
            <button
              onClick={() => setActiveCategory("all")}
              className={cn(
                "text-[10px] px-2.5 py-1 rounded-full border transition-colors shrink-0",
                activeCategory === "all"
                  ? "border-primary/40 bg-primary/10 text-primary"
                  : "border-white/10 text-muted-foreground hover:text-foreground"
              )}
            >
              All
            </button>
            {TEMPLATE_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={cn(
                  "text-[10px] px-2.5 py-1 rounded-full border transition-colors shrink-0",
                  activeCategory === cat.id
                    ? "border-primary/40 bg-primary/10 text-primary"
                    : "border-white/10 text-muted-foreground hover:text-foreground"
                )}
              >
                {cat.label}
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pb-4">
              {filteredTemplates.map((template) => (
                <TemplateCard
                  key={template.id}
                  template={template}
                  onClick={() => {
                    setTemplate(template);
                    setConfig(template.defaultConfig);
                    setTemplateSheetOpen(false);
                  }}
                />
              ))}
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
