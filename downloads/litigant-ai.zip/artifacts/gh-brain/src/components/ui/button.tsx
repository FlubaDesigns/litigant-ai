import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground border border-primary/50 hover:brightness-110 hover:-translate-y-0.5 hover:shadow-[0_4px_16px_hsl(var(--primary)/0.45)] active:translate-y-0 active:brightness-95 active:shadow-none",
        destructive:
          "bg-destructive text-destructive-foreground shadow-sm border border-destructive/50 hover:brightness-110 hover:-translate-y-0.5 active:translate-y-0 active:brightness-95 active:shadow-none",
        outline:
          "border border-border/60 shadow-xs hover:border-primary hover:text-primary hover:bg-primary/5 active:bg-primary/10 active:shadow-none",
        secondary:
          "border bg-secondary text-secondary-foreground border-secondary/50 hover:bg-secondary/70 hover:-translate-y-0.5 active:translate-y-0 active:bg-secondary/50",
        ghost: "border border-transparent hover:border-border/50 hover:bg-accent hover:text-accent-foreground active:bg-accent/60",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        // @replit changed sizes
        default: "min-h-9 px-4 py-2",
        sm: "min-h-8 rounded-md px-3 text-xs",
        lg: "min-h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
