import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowRight, Loader2 } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { safeNext } from "@/lib/authUtils";

const signInSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

export default function SignInPage() {
  const [location, setLocation] = useLocation();
  const { signIn, signInGoogle } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const next = safeNext(new URLSearchParams(location.split("?")[1] ?? "").get("next"));

  const form = useForm<z.infer<typeof signInSchema>>({
    resolver: zodResolver(signInSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(values: z.infer<typeof signInSchema>) {
    setIsLoading(true);
    try {
      await signIn(values.email, values.password);
      toast.success("Authentication successful. Session initiated.");
      setLocation(next);
    } catch (error: any) {
      toast.error(error.message || "Failed to authenticate.");
    } finally {
      setIsLoading(false);
    }
  }

  async function handleGoogleSignIn() {
    try {
      await signInGoogle();
      toast.success("Google authentication successful. Session initiated.");
      setLocation(next);
    } catch (error: any) {
      toast.error(error.message || "Failed to authenticate with Google.");
    }
  }

  return (
    <main className="auth-main">
      <div className="auth-glow" />

      <div className="row"><div className="layout__center">
        <div className="flex flex-col items-center mb-8">
          <Link href="/" className="flex items-center gap-2 mb-8 hover:opacity-80 transition-opacity">
            <img src="/logo.png" alt="Litigant AI" className="w-9 h-9" />
            <span className="text-xl font-extrabold uppercase tracking-wider">
              <span className="text-brand-green">LITIGANT-</span><span className="text-brand-amber">AI</span>
            </span>
          </Link>
          <h1 className="text-4xl font-semibold font-serif tracking-tight mb-3">Initiate Session</h1>
          <p className="text-muted-foreground text-center">
            Authenticate to access the adversarial reasoning engine.
          </p>
        </div>

        <div className="bg-card border border-border p-8 rounded-lg shadow-2xl">
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email">Operator Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="analyst@domain.com"
                className="bg-background border-border/50 focus:border-primary-glow font-mono text-sm"
                {...form.register("email")}
              />
              {form.formState.errors.email && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Passkey</Label>
                <Link href="/forgot-password" className="text-xs text-primary hover:text-primary-glow transition-all">
                  Forgot passkey?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                className="bg-background border-border/50 focus:border-primary-glow font-mono text-sm"
                {...form.register("password")}
              />
              {form.formState.errors.password && (
                <p className="text-destructive text-sm mt-1">{form.formState.errors.password.message}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                  Authenticating...
                </>
              ) : (
                <>
                  Authorize Access
                  <ArrowRight className="ml-2 w-4 h-4" />
                </>
              )}
            </Button>
          </form>

          <div className="my-6 flex items-center">
            <div className="flex-1 border-t border-border/50"></div>
            <span className="px-4 text-xs text-muted-foreground font-mono uppercase tracking-widest">or</span>
            <div className="flex-1 border-t border-border/50"></div>
          </div>

          <Button
            type="button"
            variant="outline"
            className="w-full bg-transparent border-border hover:bg-secondary/50 transition-colors"
            onClick={handleGoogleSignIn}
          >
            <FcGoogle className="mr-2 w-5 h-5" />
            Authenticate with Google
          </Button>
        </div>

        <p className="text-center mt-8 text-sm text-muted-foreground">
          No clearance yet?{" "}
          <Link href="/register" className="text-primary hover:text-primary-glow transition-all font-medium">
            Request Access
          </Link>
        </p>
      </div></div>
    </main>
  );
}
