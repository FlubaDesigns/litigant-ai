import type { ProviderName } from "@/data/templates";

const API_BASE = (import.meta.env.VITE_API_URL as string | undefined) ?? "/api-server/api";

export interface PlatformLimits {
  maxLitigants: number;
  overdraftLimit: number;
}

export async function getLimits(): Promise<PlatformLimits> {
  try {
    const res = await fetch(`${API_BASE}/limits`);
    if (!res.ok) return { maxLitigants: 10, overdraftLimit: 500 };
    const data = await res.json();
    return {
      maxLitigants: data.limits?.maxLitigants ?? 10,
      overdraftLimit: data.limits?.overdraftLimit ?? 500,
    };
  } catch {
    return { maxLitigants: 10, overdraftLimit: 500 };
  }
}

export interface ModelCreditInfo {
  model: string;
  multiplier: number;
  inputRatePer1k: number;
  outputRatePer1k: number;
  creditValueUsd: number;
  exampleSessionCredits: number;
  // Formula constants shipped from the server (creditEngine.ts is the source of truth).
  // The frontend uses these so it never needs its own hardcoded copies.
  fixedStagePrior: { input: number; output: number };
  historyFillRate: number;
  tokensPerTurnByMode: Record<"concise" | "balanced" | "thorough", number>;
  orchestratorOutputTokens: number;
  systemPromptInputTokens: number;
}

export interface ModelInfo {
  id: string;
  label: string;
  /** 0–100 quality score used by the intelligence slider. Admin-configurable. */
  qualityScore: number;
  creditInfo: ModelCreditInfo;
}

/**
 * Resolve the best-matching { provider, model } for a given intelligence level (0–100).
 * When providerPreference is "auto", searches across all enabled providers.
 * Picks the model whose qualityScore is closest to the requested level.
 */
export function resolveModelByIntelligence(
  intelligenceLevel: number,
  providerPreference: string,
  providers: ProviderInfo[]
): { provider: string; model: string; label: string } | null {
  const candidates =
    providerPreference === "auto"
      ? providers.flatMap((p) => p.models.map((m) => ({ ...m, providerName: p.name })))
      : (providers.find((p) => p.name === providerPreference)?.models ?? []).map((m) => ({
          ...m,
          providerName: providerPreference,
        }));

  if (candidates.length === 0) return null;

  const best = candidates.reduce((b, m) =>
    Math.abs((m.qualityScore ?? 50) - intelligenceLevel) <
    Math.abs((b.qualityScore ?? 50) - intelligenceLevel)
      ? m
      : b
  );

  return { provider: best.providerName, model: best.id, label: best.label };
}

export interface ProviderInfo {
  name: ProviderName;
  displayName: string;
  defaultModel: string;
  models: ModelInfo[];
}

export interface ProvidersResponse {
  configured: ProviderName[];
  creditValueUsd: number;
  providers: ProviderInfo[];
}

let _cache: ProvidersResponse | null = null;

export async function getProviders(): Promise<ProvidersResponse> {
  if (_cache) return _cache;
  try {
    const res = await fetch(`${API_BASE}/providers`);
    if (!res.ok) throw new Error("Failed to fetch providers");
    _cache = await res.json();
    return _cache!;
  } catch {
    return { configured: ["openai"], creditValueUsd: 0.01, providers: [] };
  }
}

export const PROVIDER_LABELS: Record<ProviderName, string> = {
  openai: "OpenAI",
  anthropic: "Anthropic",
  grok: "xAI Grok",
  gemini: "Google Gemini",
};

export const PROVIDER_ICONS: Record<ProviderName, string> = {
  openai: "🤖",
  anthropic: "🔮",
  grok: "⚡",
  gemini: "✨",
};

export type ResponseMode = "concise" | "balanced" | "thorough";

export interface CalibrationStats {
  fixedStage: { input: number; output: number };
  sessionCount: number;
  isCalibrated: boolean;
  minSessions: number;
}

/**
 * Fetches the user's personal calibration stats — averaged fixed-stage token
 * usage from their own session history.  Returns null on any error.
 */
export async function getCalibration(idToken: string): Promise<CalibrationStats | null> {
  try {
    const res = await fetch(`${API_BASE}/calibration`, {
      headers: { Authorization: `Bearer ${idToken}` },
    });
    if (!res.ok) return null;
    return res.json() as Promise<CalibrationStats>;
  } catch {
    return null;
  }
}

/**
 * Estimate credit cost client-side.
 *
 * All formula constants come from creditInfo, which is shipped by the server
 * (creditEngine.ts is the single source of truth). No magic numbers here.
 */
export function estimateCredits(
  creditInfo: ModelCreditInfo,
  litigantCount: number,
  maxIterations: number,
  responseMode: ResponseMode
): number {
  // tokensPerTurnByMode may be absent on older API server deployments — fall back gracefully.
  const tokensPerTurn = creditInfo.tokensPerTurnByMode?.[responseMode] ?? 2000;
  const litigants     = Math.min(litigantCount, 10);
  const rounds        = maxIterations;

  const historyFillRate        = creditInfo.historyFillRate ?? 0.6;
  const systemPromptInputTokens = creditInfo.systemPromptInputTokens ?? 1500;
  const orchestratorOutputTokens = creditInfo.orchestratorOutputTokens ?? 500;
  const fixedInput  = creditInfo.fixedStagePrior?.input  ?? 2000;
  const fixedOutput = creditInfo.fixedStagePrior?.output ?? 500;

  const historyPerRound = tokensPerTurn * litigants * historyFillRate;
  const avgInputPerTurn = systemPromptInputTokens + historyPerRound * (rounds / 2);

  const outputTokens = orchestratorOutputTokens
    + litigants * rounds * tokensPerTurn
    + fixedOutput;

  const inputTokens = litigants * rounds * avgInputPerTurn
    + fixedInput;

  const costUSD =
    (inputTokens  / 1000) * creditInfo.inputRatePer1k +
    (outputTokens / 1000) * creditInfo.outputRatePer1k;

  return Math.max(1, Math.ceil((costUSD * creditInfo.multiplier) / creditInfo.creditValueUsd));
}
